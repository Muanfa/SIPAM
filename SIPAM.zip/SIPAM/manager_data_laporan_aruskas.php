<?php
  require "koneksi/koneksi.php";

  session_start();

  if (!isset($_SESSION['manager'])) {
    header("location:login.php?ok=loncat");
  }
 ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Nama Title -->
    <title>Berkah Madani</title>
    <!-- Ikon Gambar Title -->
    <link rel="icon" href="gambar/logo_BM.png" type="png">
    <!-- CSS Andi -->
    <link href="css/andi.css" rel="stylesheet">

    <!-- Untuk Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/jquery.min.js"></script>

    <!-- Untuk DataTables -->
    <link rel="stylesheet" href="DataTables/datatables.min.css">
    <script src="DataTables/datatables.min.js" type="text/javascript"></script>

    <!-- Untuk DatePicker -->
    <script src="js/bootstrap2.min.js"></script>
    <!-- Kalau mau menggunakan datatabel harap matikan JS dibawah ini -->
    <!-- <script src="js/jquery2.min.js"></script> -->
    <script src="js/moment.js"></script>
    <link href="css/bootstrap-datetimepicker.min.css" rel="stylesheet">
    <script src="js/bootstrap-datetimepicker.min.js"></script>

    <!-- Include javascript sweetalert -->
    <script type="text/javascript" src="js/sweetalert.min.js"></script>

    <style media="screen">
      @font-face {
        font-family: Supercell-Magic;
        src: url(Supercell.magic.webfont.ttf);
      }
    </style>

  </head>
  <body>

    <!-- ============================= Header ============================== x -->
    <?php
      include "manager_header.php";
     ?>

    <!-- ====================== Navigasi (Horizontal) ====================== x -->
    <?php
      include "manager_nav_horizontal_no_klik.php";
     ?>

    <!-- ===================== Navigasi (Veritakal)  ======================  -->
    <div id="myNavbar2" class="atur-link collapse navbar-collapse navbar-inverse" data-spy="affix" data-offset-top="197" style="height:900px;">
      <div class="scroll-link" id="accordion" style="height:600px;">
        <!-- Gambar Admin -->
        <div class="panel" style="margin:2%;background-color:#706fd3;" >
          <div class="panel-heading" onmouseover="this.style='text-decoration:none;background-color:#574b90;'" onmouseout="this.style='color:white;background-color:#706fd3;'">
            <div class="" style="height:50px;" >
              <div class="gambar-profil">
                <img src="gambar/Logo_BM1.png" class="img-circle img-responsive" alt="gambar berkah madani" width="50" height="50" style="margin-top:8px;">
              </div>
              <div class="profil">
                <div class="nama-profil responsive">
                  BMT Berkah Madani
                </div>
                <div class="drop-status">
                  <div class="status-bullet">
                    <b><span>&bull;</span></b>
                  </div>
                  <div class="status-online">
                    <b>Online</b>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Alur Akad Pembiayaan Murabahah -->
        <div class="panel panel-info" style="margin-left:2%;margin-bottom:2%;margin-right:2%;">
          <div class="panel-heading">
            <ul class="nav nav-pills nav-stacked panel panel-default" style="margin-left:-4%;margin-top:-2%;margin-right:-4%;margin-bottom:-2%;">
              <li><a href="manager_alur_akad.php" tabindex="-1"><span class="glyphicon glyphicon-bookmark" style="font-size:15px;color:#9c88ff;"></span><b style="font-size:13px;"> Alur Pembiayaan Akad Murabahah</b></a></li>
            </ul>
          </div>
        </div>
        <!-- Pegawai -->
        <div class="panel panel-info" style="margin-left:2%;margin-bottom:2%;margin-right:2%;">
          <div class="panel-heading">
            <ul class="nav nav-stacked panel panel-default" style="margin-left:-4%;margin-top:-2%;margin-right:-4%;margin-bottom:-2%;">
              <li><a tabindex="-1" class="huruf-link" data-toggle="collapse" data-parent="#accordion" data-target="#collapse-0"><span class="glyphicon glyphicon-user" style="font-size:15px;color:black;"></span><b> Pegawai</b><span class="glyphicon glyphicon-chevron-down" style="float:right;font-size:17px;margin-top:1.5%;"></span></a></li>
            </ul>
          </div>
          <div id="collapse-0" class="panel-collapse collapse">
            <div class="panel-body">
              <ul class="nav nav-pills nav-stacked">
                <!-- <li><a href="manager_tambah_pegawai.php" tabindex="-1"><span class="glyphicon glyphicon-triangle-right"></span> <b>Daftar Pegawai</b> <span class="panel panel-default" style="padding:2px;background-color:#fffa65;color:red;">Baru</span></a></li> -->
                <li><a href="manager_data_pegawai.php" tabindex="-1" ><span class="glyphicon glyphicon-triangle-right"></span> <b>Data Pegawai</b></a></li>
              </ul>
            </div>
          </div>
        </div>
        <!-- Nasabah -->
        <div class="panel panel-info" style="margin-left:2%;margin-bottom:2%;margin-right:2%;">
          <div class="panel-heading">
            <ul class="nav nav-stacked panel panel-default" style="margin-left:-4%;margin-top:-2%;margin-right:-4%;margin-bottom:-2%;">
              <li><a tabindex="-1" class="huruf-link" data-toggle="collapse" data-parent="#accordion" data-target="#collapse-1"><span class="glyphicon glyphicon-user" style="font-size:15px;color:#6ab04c;"></span><b> Nasabah</b><span class="glyphicon glyphicon-chevron-down" style="float:right;font-size:17px;margin-top:1.5%;"></span></a></li>
            </ul>
          </div>
          <div id="collapse-1" class="panel-collapse collapse">
            <div class="panel-body">
              <ul class="nav nav-pills nav-stacked">
                <!-- <li><a href="manager_tambah_nasabah.php" tabindex="-1" ><span class="glyphicon glyphicon-triangle-right"></span>
                  <b>Daftar Nasabah</b> <span class="panel panel-default" style="padding:2px;background-color:#fffa65;color:red;">Baru</span></a></li> -->
                <li><a href="manager_data_nasabah.php" tabindex="-1"><span class="glyphicon glyphicon-triangle-right"></span> <b>Data Nasabah</b></a></li>
                <li><a href="manager_lihat_reknasabah.php" tabindex="-1"><span class="glyphicon glyphicon-triangle-right"></span> <b>Data Rekening</b></a></li>
              </ul>
            </div>
          </div>
        </div>
        <!-- Pembiayaan Akad Murabahah -->
        <div class="panel panel-info" style="margin-left:2%;margin-bottom:2%;margin-right:2%;">
          <div class="panel-heading">
            <ul class="nav nav-stacked panel panel-default" style="margin-left:-4%;margin-top:-2%;margin-right:-4%;margin-bottom:-2%;">
              <li><a tabindex="-1"  data-toggle="collapse" data-parent="#accordion" data-target="#collapse-2"><span class="glyphicon glyphicon-duplicate" style="font-size:15px;color:#01a3a4;"></span><b> Pembiayaan Akad Murabahah</b><span class="glyphicon glyphicon-chevron-down" style="float:right;font-size:17px;margin-top:1%;"></span></a></li>
            </ul>
          </div>
          <div id="collapse-2" class="panel-collapse collapse">
            <div class="panel-body">
              <ul class="nav nav-pills nav-stacked">
                <!-- <li><a href="manager_data_tambah_pembiayaan.php" tabindex="-1"><span class="glyphicon glyphicon-triangle-right"></span>
                  <b>Daftar Pembiayaan</b> <span class="panel panel-default" style="padding:2px;background-color:#fffa65;color:red;">Baru</span></a></li> -->
                <li><a href="manager_data_pembiayaan.php" tabindex="-1"><span class="glyphicon glyphicon-triangle-right"></span> <b>Data Pembiayaan</b></a></li>
                <li><a href="manager_data_jaminan.php" tabindex="-1"><span class="glyphicon glyphicon-triangle-right"></span> <b>Data Jaminan Nasabah</b></a></li>
                <li><a href="manager_cetak_akad.php" tabindex="-1"><span class="glyphicon glyphicon-triangle-right"></span> <b>Cetak Akad Murabahah</b></a></li>
              </ul>
            </div>
          </div>
        </div>
        <!-- Transaksi -->
        <div class="panel panel-info" style="margin-left:2%;margin-bottom:2%;margin-right:2%;">
          <div class="panel-heading">
            <ul class="nav nav-stacked panel panel-default" style="margin-left:-4%;margin-top:-2%;margin-right:-4%;margin-bottom:-2%;">
              <li><a tabindex="-1" class="huruf-link" data-toggle="collapse" data-parent="#accordion" data-target="#collapse-3"><span class="glyphicon glyphicon-briefcase" style="font-size:15px;color:red;"></span><b> Transaksi Setoran</b><span class="glyphicon glyphicon-chevron-down" style="float:right;font-size:17px;margin-top:1.5%;"></span></a></li>
            </ul>
          </div>
          <div id="collapse-3" class="panel-collapse collapse">
            <div class="panel-body">
              <ul class="nav nav-pills nav-stacked">
                <!-- <li><a href="manager_data_tambah_transaksi.php" tabindex="-1" ><span class="glyphicon glyphicon-triangle-right"></span>
                  <b>Buat Transaksi Setoran</b>  <span class="panel panel-default" style="padding:2px;background-color:#fffa65;color:red;">Baru</span></a></li> -->
                <li><a href="manager_data_transaksi.php" tabindex="-1"><span class="glyphicon glyphicon-triangle-right"></span> <b>Data Transaksi Setoran</b></a></li>
              </ul>
            </div>
          </div>
        </div>
        <!-- Laporan -->
        <div class="panel panel-info" style="margin-left:2%;margin-bottom:2%;margin-right:2%;">
          <div class="panel-heading">
            <ul class="nav nav-stacked panel panel-default" style="margin-left:-4%;margin-top:-2%;margin-right:-4%;margin-bottom:-2%;">
              <li><a tabindex="-1" class="huruf-link" data-toggle="collapse" data-parent="#accordion" data-target="#collapse-4"><span class="glyphicon glyphicon-folder-open" style="font-size:15px;color:orange"></span><b> Laporan Keuangan</b><span class="glyphicon glyphicon-chevron-down" style="float:right;font-size:17px;margin-top:1.5%;"></span></a></li>
            </ul>
          </div>
          <div id="collapse-4" class="panel-collapse collapse in">
            <div class="panel-body">
              <ul class="nav nav-pills nav-stacked">
                <li><a href="manager_data_laporan_pendapatan.php" tabindex="-1" ><span class="glyphicon glyphicon-triangle-right" ></span><b style="float:none;"> Data Laporan Pendapatan</b></a></li>
                <li><a href="manager_data_laporan_aruskas.php" tabindex="-1" style="background-color:#686de0;color:white;" onmouseover="this.style='text-decoration:none;color:#white;'" onmouseout="this.style='background-color:#686de0;color:white;'"><span class="glyphicon glyphicon-triangle-right"></span><b> Data Laporan Arus Kas</b></a></li>
              </ul>
            </div>
          </div>
        </div>
        <!-- Monitoring -->
        <div class="panel panel-info" style="margin-left:2%;margin-bottom:2%;margin-right:2%;">
          <div class="panel-heading">
            <ul class="nav nav-pills nav-stacked panel panel-default" style="margin-left:-4%;margin-top:-2%;margin-right:-4%;margin-bottom:-2%;">
              <li><a href="manager_data_monitoring.php" class="huruf-link" tabindex="-1"><span class="glyphicon glyphicon-eye-open" style="font-size:15px;color:#30336b;"></span><b> Monitoring</b></a></li>
            </ul>
          </div>
        </div>
        <!-- Info -->
        <div class="panel panel-info" style="margin-left:2%;margin-bottom:2%;margin-right:2%;">
          <div class="panel-heading">
            <ul class="nav nav-stacked panel panel-default" style="margin-left:-4%;margin-top:-2%;margin-right:-4%;margin-bottom:-2%;">
              <li><a tabindex="-1" class="huruf-link" data-toggle="collapse" data-parent="#accordion" data-target="#collapse-5"><span class="glyphicon glyphicon-info-sign" style="font-size:15px;color:blue;"></span><b> Info</b><span class="glyphicon glyphicon-chevron-down" style="float:right;font-size:17px;margin-top:1.5%;"></span></a></li>
              <!-- <li><a href="#" tabindex="-1" data-toggle="collapse" data-target="#collapse-1"><b>Link 2</b><span class="glyphicon glyphicon-chevron-down" style="float:right;font-size:13px;"></span></a></li> -->
            </ul>
          </div>
          <div id="collapse-5" class="panel-collapse collapse">
            <div class="panel-body">
              <ul class="nav nav-pills nav-stacked">
                <!-- Kalau misalnya lagi dibagian ini, mau di waranain tingal ubah style background-color -->
                <li><a href="manager_tentang_app.php" tabindex="-1"><span class="glyphicon glyphicon-triangle-right"></span> <b>Tentang App Website</b></a></li>
              </ul>
            </div>
          </div>
        </div>
        <hr>
      </div>
    </div>

    <!-- ======================== Konten Web  =============================  -->
    <div class="container-fluid atur-konten" style="">
      <div class="isi-konten" >
        <div class="container-fluid">


          <!-- Isi Konten -->
          <?php
            include "konten_data_laporan_aruskas.php";
           ?>

        </div>

    <!--- ========================= Footer ================================= -->
        <?php
          include "footer.php";
         ?>
      </div>
    </div>

    <!-- Untuk Scroll Ke Atas -->
    <div id="tombolScrollTop" onclick="scrolltotop()" href="#"><span class="glyphicon glyphicon-circle-arrow-up" style="font-size:40px;"></span></div>
    <!-- Untuk Scroll Ke Atas -->
    <script type="text/javascript">
      $(document).ready(function(){
        $(window).scroll(function(){
          if ($(window).scrollTop() > 100) {
            $('#tombolScrollTop').fadeIn();
          } else {
            $('#tombolScrollTop').fadeOut();
          }
        });
      });

      function scrolltotop(){
        $('html, body').animate({scrollTop : 0},500);
      }
    </script>

    <!-- Untuk Input Hanya Angka dan Huruf -->
    <script language="javascript">
      function getkey(e)
      {
      if (window.event)
         return window.event.keyCode;
      else if (e)
         return e.which;
      else
         return null;
      }
      function angkadanhuruf(e, goods, field)
      {
      var angka, karakterangka;
      angka = getkey(e);
      if (angka == null) return true;

      karakterangka = String.fromCharCode(angka);
      karakterangka = karakterangka.toLowerCase();
      goods = goods.toLowerCase();

      // check goodkeys
      if (goods.indexOf(karakterangka) != -1)
          return true;
      // control angka
      if ( angka==null || angka==0 || angka==8 || angka==9 || angka==27 )
         return true;

      if (angka == 13) {
          var i;
          for (i = 0; i < field.form.elements.length; i++)
              if (field == field.form.elements[i])
                  break;
          i = (i + 1) % field.form.elements.length;
          field.form.elements[i].focus();
          return false;
          };
      // else return false
      return false;
      }
    </script>

    <!-- Untuk Datatables -->
    <script type="text/javascript">
      $(document).ready(function() {
        $('#asexample').DataTable();
      } );
    </script>

    <!-- Untuk Date Picker (script Wajib disini) -->
    <script type="text/javascript">
      $(function () {
        $('#datetimepicker2').datetimepicker({
          format: 'DD-MM-YYYY',
        });
      });
    </script>

    <!-- Untuk Menampilkan Password -->
    <script type="text/javascript">
      $(document).ready(function() {
        var cek = $('.form-checkbox').val();
        $('.form-checkbox').click(function() {
          if ($(this).is(':checked')) {
            $('.form-password').attr('type', 'text');
          } else {
            $('.form-password').attr('type', 'password');
          }
        });
      });
    </script>

    <!-- Untuk Notif Sosmed -->
    <script type="text/javascript">
      $(document).ready(function(){
        $('[data-toggle="tooltip"]').tooltip();
      });
    </script>



    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!-- <script src="js/jquery.min.js"></script> -->
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <!-- <script src="js/bootstrap.min.js"></script> -->
    <!-- Include javascript sweetalert -->
    <!-- <script type="text/javascript" src="js/sweetalert.min.js"></script> -->
  </body>
</html>
