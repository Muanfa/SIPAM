<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Berkah Madani</title>


    <!-- Ikon Gambar Title -->
    <link rel="icon" href="gambar/logo_BM.png" type="png">
    <!-- CSS Andi -->
    <link href="css/andi.css" rel="stylesheet">


    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/jquery.min.js"></script>
    <!-- Untuk DataTables -->
    <link rel="stylesheet" href="DataTables/datatables.min.css">
    <script src="DataTables/datatables.min.js" type="text/javascript"></script>

    <!-- Untuk Font Supercell -->
    <style media="screen">
      @font-face {
        font-family: Supercell-Magic;
        src: url(Supercell.magic.webfont.ttf);
      }
    </style>

  </head>
  <body>

    <!-- ============================= Header ============================== x -->
    <?php
      include "index_header.php";
     ?>


    <!-- ====================== Navigasi (Horizontal) ====================== x -->
    <nav class="navbar-inverse" data-spy="affix" data-offset-top="197" style="background-color:#596275;">
      <div class="container-fluid">
        <div class="navbar-header ">
          <!-- Button Naviagasi Kanan (Saat Layar Chrome dikecil) -->
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar" style="background-color:black;" onmouseover="this.style='background-color:gray;'" onmouseout="this.style='background-color:black;'">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <div class="beranda">
            <a href="index.php" title="Home" class="navbar-brand glyphicon glyphicon-home"  style="color:#1B9CFC;font-size:20px" onmouseover="this.style='text-decoration:none;color:#white;font-size:20px'" onmouseout="this.style='color:#1B9CFC;font-size:20px'"></a>
          </div>
        </div>
        <!-- Tombol NAVIGASI ATAS -->
        <div class="collapse navbar-collapse" id="myNavbar">
          <ul class="nav navbar-nav">
            <li><a href="index_sejarah.php" class="huruf-nav" title="Sejarah" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><b>Sejarah</b></a></li>
            <li><a href="index_visi_misi.php" class="huruf-nav" title="Visi Misi" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><b>Visi Misi</b></a></li>
            <li><a href="index_murabahah.php" class="huruf-nav" title="Murabahah" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><b>Murabahah</b></a></li>
            <li><a href="index_hubungi_kami.php" class="huruf-nav" title="Hubungi Kami" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><b>Hubungi Kami</b></a></li>
            <!-- <li class="dropdown"><a title="Section 4" class="dropdown-toggle" data-toggle="dropdown" href="#" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><b>Tentang Kami</b> <span class="caret"></span></a>
              <ul class="dropdown-menu" style="text-align:center;">
                  <li><a href="sejarah.php">Sejarah</a></li>
                  <li><a href="visi-misi.php">Visi & Misi</a></li>
              </ul>
            </li> -->
          </ul>
          <!-- TOMBOL LOGIN -->
          <ul class="nav navbar-nav" style="float:right;">
            <li ><a href="login.php" title="Login" class="huruf-nav" title="Login" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><span class="glyphicon glyphicon-log-in" style="font-size:16px;color:#4bcffa;"></span><b> Login</b></a></li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- ===================== Navigasi (Veritakal)  ======================  -->

    <!-- ======================== Konten Web  =============================  -->
      <div class="container-fluid">
        <div class="container-fluid">


          <!-- Isi Konten -->
          <h1 class="text-center"><b>Home</b> </h1>
          <hr>
          <div class="panel panel-default">
            <div class="panel-heading">
              <h2><b>KSPPS BMT Berkah Madani</b></h2>
            </div>
            <div class="panel-body">
              <!-- Gambar KSPPS BMT Berkah Madani -->
              <div class="text-center">
                <img class="img-responsive img-thumbnail" src="gambar/BMT-Berkah-Madani-1.png" alt="gambar BMT Berkah Madani" width="640" height="250" style="margin-bottom:10px;"/>
              </div>

              <div class="container-fluid">
                <!-- HR -->
                <table style="width:100%;">
                  <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), black)"></td>
                  <td>&nbsp;&nbsp;&nbsp;</td>
                  <td><p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ&nbsp;اللهِ&nbsp;الرَّحْمَنِ&nbsp;الرَّحِيْمِ</p></td>
                  <td>&nbsp;&nbsp;&nbsp;</td>
                  <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, black, rgba(0,0,0,0.75), rgba(0,0,0,0));"></td>
                </table>

                <p class="paragraf">
                  <strong>BMT</strong> adalah singkatan dari nama sebutan lembaga keuangan mikro Baitul Maal wat Tamwil
                  atau padanan kata Balai-usaha Mandiri Terpadu.
                </p>
                <ol type="1">
                  <li><p class="paragraf" style="margin-bottom:0px;">
                    <strong>Kegiatan Baituttamwil</strong> adalah mengembangkan usaha-usaha produktif dan
                    investasi dalam meningkatkan kualitas kegiatan ekonomi pengusaha kecil dengan antara lain
                    mendorong kegiatan menabung dan menunjang kegiatan ekonominya.
                  </p></li>
                  <li><p class="paragraf">
                    <strong>Kegiatan Baitul Maal</strong> adalah menerima titipan BAZIS dari dana zakat,
                    infaq dan sadaqah dan menjalankannya sesuai dengan peraturan dan amanahnya.
                  </p></li>
                </ol><br>

                <strong>APA CIRI-CIRI UTAMA BMT ?</strong>
                <ol type="1">
                  <li><p class="paragraf" style="margin-bottom:0px;">
                    Berorientasi bisnis dan sosial mencari laba bersama, meningkatkan pemanfaatan ekonomi
                    paling banyak untuk anggota dan lingkungannya.
                  </p></li>
                  <li><p class="paragraf" style="margin-bottom:0px;">
                    Bukan lembaga sosial, tetapi dapat dimanfaatkan untuk mengefektifkan penggunaan zakat,
                    infaq dan sadaqah bagi kesejahteraan dan pemberdayaan orang banyak.
                  </p></li>
                  <li><p class="paragraf" style="margin-bottom:0px;">
                    Ditumbuhkan dari bawah berdasar peran dari masyarakat sekitarnya.
                  </p></li>
                  <li><p class="paragraf" style="margin-bottom:0px;">
                    Milik bersama masyarakat kecil bawah dan kecil dari lingkungan BMT itu sendiri,
                    bukan milik orang seorang atau orang lain diluar masyarakat itu.
                  </p></li>
                </ol><br>

                <p class="paragraf-kedalam">
                  Sesungguhnya dalam operasionalnya, antara BMT dan KSPPS ( Koperasi SimpanPinjam dan
                  Pembiayaan Syariah ) tidak terlalu banyak perbedaannya. Sebagai lembaga keuangan,
                  keduanya mempunyai fungsi yang sama dalam penghimpunan dan penyaluran dana. Istilah-istilah
                  yang digunakan juga tidak ada bedanya. Dalam proses penghimpunan dana, keduanya menggunakan
                  istilah simpanan atau tabungan. Begitu pula dalam penyaluran danya, keduanya menggunakan
                  istilah pembiayaan. Sedang syarat pendirian koperasi kedua lembaga tersebut mengharuskan
                  minimal 20 orang. <br>
                  Selain itu, dalam
                </p>
                <p class="paragraf-kedalam">
                  Peraturan menteri koperasi dan usaha kecil dan menengah Republik indonesia
                  Nomor 16 /per/m.kukm/ix/2015 Tentang Pelaksanaan kegiatan usaha simpan pinjam dan pembiayaan
                  Syariah oleh koperasi Menteri koperasi dan usaha kecil dan menengah Republik indonesia,
                  Bab I Ketentuan umum Pasal 1 ditegaskan bahwa operasional KSPPS juga memungkinkan untuk
                  melaksankan fungsi ‘Maal’ dan fungsi ‘Tamwil’, sebagaimana yang selama ini dijalankan oleh BMT.
                  Dalam hal ini, KSPPS harus dapat membedakan secara tegas antara fungsi ‘Maal’ dan fungsi ‘Tamwil’.
                </p>
                <p class="paragraf-kedalam">
                  Adapun yang sedikit membedakan dalam pelaksanaannya, pada BMT memungkin-kan penyaluran dananya
                  pada pihak luar, yaitu pihak yang belum menjadi anggota BMT. Sedangkan, dalam operasional KSPPS,
                  penyaluran dananya hanya diperuntuk-kan pada pihak yang telah terdaftar menjadi anggota KSPPS.
                  Dalam hal ini, KSPPS hanya diperkenankan memberikan pembiayaan kepada anggota. Hal ini sesuai
                  dengan prinsip dasar koperasi, dari anggota, oleh anggota dan untuk anggota.
                </p>
                <p class="paragraf-kedalam">
                  Adanya koperasi syariah (KSPPS) yang telah menjadi salah satu program Kementerian Negara
                  Koperasi dan UKM merupakan solusi bagi pemecahan kebuntuhan legalitas BMT. Sehingga, diharapkan
                  BMT-BMT yang saat ini belum berbadan hukum dapat mengkonversi menjadi koperasi syariah.
                </p>
                <p class="paragraf-kedalam">
                  Koperasi syariah mempunyai kesamaan pengertian dalam kegiatan usahanya bergerak di bidang
                  pembiayaan, investasi, dan simpanan sesuai pola bagi hasil (syariah), atau lebih dikenal dengan
                  koperasi jasa keuangan syariah. Sebagai contoh produk jual beli dalam koperasi umum diganti
                  namanya dengan istilah murabahah, produk simpan pinjam dalam koperasi umum diganti namanya
                  dengan mudharabah. Tidak hanya perubahan nama, sistem operasional yang digunakan juga berubah,
                  dari sistem konvesional (biasa) ke sistem syari’ah yang sesuai dengan aturan Islam.
                </p>

                <strong>Nilai-nilai Koperasi</strong>
                <p class="paragraf-kedalam">
                  Pemerintah dan swasta, meliputi individu maupun masyarakat, wajib mentransformasikan nilai-nilai syari’ah dalam nilai-nilai koperasi, dengan mengadopsi 7 nilai syariah dalam bisnis yaitu :
                  <ol type="a">
                    <li>Shiddiq yang mencerminkan kejujuran, akurasi dan akuntabilitas.</li>
                    <li>Istiqamah yang mencerminkan konsistensi, komitmen dan loyalitas.</li>
                    <li>Tabligh yang mencerminkan transparansi, kontrol, edukatif, dan komunikatif</li>
                    <li>Amanah yang mencerminkan kepercayaan, integritas, reputasi, dan kredibelitas.</li>
                    <li>Fathanah yang mencerminkan etos profesional, kompeten, kreatif, inovatif.</li>
                    <li>Ri’ayah yang mencerminkan semangat solidaritas, empati, kepedulian, awareness.</li>
                    <li>Mas’uliyah yang mencerminkan responsibilitas.</li>
                  </ol>
                </p>

                <strong>Tujuan Koperasi Syariah</strong>
                <p class="paragraf-kedalam">
                  Meningkatkan kesejahteraan anggota pada khususnya dan masyarakat pada umumnya serta turut
                  membangun tatanan perekonomian yang berkeadilan sesuai dengan prinsip-prinsip Islam.
                </p>

                <strong>Fungsi dan Peran Koperasi Syariah yaitu:</strong>
                <p>
                  <ol type="1">
                    <li><p class="paragraf" style="margin-bottom:0px;">
                      Membangun dan mengembangkan potensi dan kemampuan anggota pada khususnya, dan masyarakat
                      pada umumnya, guna meningkatkan kesejahteraan sosial ekonominya.

                    </p>
                    </li>
                    <li><p class="paragraf" style="margin-bottom:0px;">
                      Memperkuat kualitas sumber daya insani anggota, agar menjadi lebih amanah, professional
                      (fathonah), konsisten, dan konsekuen (istiqomah) di dalam menerapkan prinsip-prinsip
                      ekonomi islam dan prinsip-prinsip syariah islam.
                    </p></li>
                    <li><p class="paragraf" style="margin-bottom:0px;">
                      Berusaha untuk mewujudkan dan mengembangkan perekonomian nasional yang merupakan usaha
                      bersama berdasarkan azas kekeluargaan dan demokrasi ekonomi.
                    </p></li>
                    <li><p class="paragraf" style="margin-bottom:0px;">
                      Sebagai mediator antara menyandang dana dengan penggunan dana, sehingga tercapai
                      optimalisasi pemanfaatan harta.
                    </p></li>
                    <li><p class="paragraf" style="margin-bottom:0px;">
                      Menguatkan kelompok-kelompok anggota, sehingga mampu bekerjasama melakukan
                      kontrol terhadap koperasi secara efektif
                    </p></li>
                    <li>Mengembangkan dan memperluas kesempatan kerja</li>
                    <li>Menumbuhkan-kembangkan usaha-usaha produktif anggota</li>
                  </ol>
                  <i>by : supri</i>
                </p>
                <blockquote>
                  <footer>From <a href="https://berkahmadani.co.id" target="_blank">BMT Berkah Madani</a> website</footer>
                </blockquote>
              </div>
            </div>
          </div>


        </div>
      </div>
    <!--- ========================= Footer ================================= -->
    <?php
      include "footer.php";
    ?>


    <!-- Untuk Scroll Ke Atas -->
    <div id="tombolScrollTop" onclick="scrolltotop()" href="#"><span class="glyphicon glyphicon-circle-arrow-up" style="font-size:40px;"></span></div>
    <!-- JS Andi -->
    <script type="text/javascript" src="js/andi.js"></script>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!-- <script src="js/jquery.min.js"></script> -->
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <!-- Include javascript sweetalert -->
    <script type="text/javascript" src="js/sweetalert.min.js"></script>
  </body>
</html>
