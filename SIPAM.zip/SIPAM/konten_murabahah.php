<h1 class="text-center"><b>Murabahah</b> </h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>KSPPS BMT Berkah Madani</b></h2>
  </div>
  <div class="panel-body">
    <img class="img-responsive img-thumbnail" src="gambar/Murabahah.jpg" alt="gambar Murabahah" width="400" height="210" style="float:left;margin-right:30px;margin-bottom:10px;"/>
    <div class="container-fluid">
      <!-- Definisi Murabahah -->
      <div>
        <strong>Definisi Murabahah</strong>
        <!-- <strong></strong><br> -->
        <p class="paragraf-kedalam">
          Secara bahasa murabahah berasal dari kata Ar-Ribhu yang berarti <b style="font-size:20px;">النَّمَاءُ</b>
          (an-namaa’) yang berarti tumbuh dan berkembang, atau murabahah juga berarti Al-Irbaah,
          karena salah satu dari dua orang yang bertransaksi memberikan keuntungan kepada yang
          lainnya (Ibnu Al-Mandzur., hal. 443.).
        </p>
        <p class="paragraf">
          Sedangkan secara istilah, Bai'ul murabahah (murabahah) adalah:<br>
          <p style="text-align: center;font-size:30px;">
            بَيْعٌ بِمِثلِ الثمَنِ الأوَّلِ مَعَ زِيَادَةِ رِبْحٍ مَعلُوْمٍ
          </p>
        </p>
        <p class="paragraf">
          Yaitu jual beli dengan harga awal disertai dengan tambahan keuntungan
          (Azzuhaili, 1997., hal. 3765). Definisi ini adalah definisi yang disepakati oleh para
          ahli fiqh, walaupun ungkapan yang digunakan berbeda-beda. (Asshawy, 1990., hal.198.)
        </p>
        <p class="paragraf-kedalam">
          Gambaran transaksi jual beli murabahah ini sebagaimana yang disebutkan oleh Ulama Malikiyah,
          adalah jual beli dimana pemilik barang menyebutkan harga beli barang tersebut, kemudian ia
          mengambil keuntungan dari pembeli baik secara sekaligus dengan mengatakan, saya membelinya
          dengan harga sepuluh dinar dan anda berikan keuntungan kepadaku sebesar satu dinar atau dua
          dinar", atau merincinya dengan mengatakan, anda berikan keuntungan sebesar satu dirham per
          satu dinarnya. Atau bisa juga ditentukan dengan ukuran tertentu maupun dengan menggunakan
          porsentase (Ibnu Jazy, hal. 263.).
        </p>
        <p class="paragraf">
          Disamping jual beli murabahah, dalam fiqh al-muamalah ada empat jenis jual beli lainnya
          (Az Zuhaily, hal.3766), yaitu:
          <ol type="1">
            <li><p class="paragraf">
                Jual beli al-musawamah (ba'iu al musawamah), yaitu menjual dengan harga berapapun tanpa
                melihat kepada harga pokok atau harga perolehan saat pembelian awal. Jual beli ini yang
                biasa dilakukan.
            </p></li>
            <li><p class="paragraf">
              Jual beli at-tauliyah (bai'u at tauliyah), yaitu menjual dengan harga pokok atau harga
              perolehan tanpa tambahan keuntungan.
            </p></li>
            <li><p class="paragraf">
              Jual beli isytiraak (bai'u al isytiraak), sama dengan jual beli at-tauliyah, perbedaannya
              adalah menjual sebagian obyek jual beli dengan sebagian harga.
            </p></li>
            <li><p class="paragraf">
              Jual beli al-wadhi'ah (bai'u al wadhi'ah) yaitu menjual sama dengan harga pokok atau
              harga perolehan, dengan mengurangi atau memberikan potongan harga.
            </p></li>
          </ol>
        </p>
      </div><br>
      <!-- 1. Landasan Hukum -->
      <div>
        <strong>1. Landasan Hukum</strong>
        <p class="paragraf-kedalam">
          Murabahah merupakan suatu akad yang dibolehkan secara syar'i, serta didukung
          oleh mayoritas ulama dari kalangan Shahabat, Tabi'in serta Ulama-ulama dari
          berbagai mazhab dan aliran.<br>
          Landasan hukum akad murabahah ini adalah: <br>
          <div class="" style="margin-left:15px;">
            <ul>
              <li><b>Al-Quran</b></li>
            </ul>
            <p class="paragraf">
              Ayat-ayat Al-Quran yang secara umum membolehkan jual beli, diantaranya
              adalah firman Allah: <br>
            </p>
            <p style="text-align:center;font-size:30px;">
              وَأَحَلَّ اللهُ الْبَيْعَ وَحَرَّمَ الرِّبَا
            </p>
            <p class="paragraf">
              Artinya: "..dan Allah menghalalkan jual beli dan mengharamkan riba"(QS. Al-Baqarah:275).<br>
              Ayat ini menunjukkan bolehnya melakukan transaksi jual beli dan murabahah
              merupakan salah satu bentuk dari jual beli.
            </p>
          </div>

        </p>
      </div><br>
      <!-- 2. Rukun dan Syarat -->
      <div>
        <strong>2. Rukun dan Syarat Syarat Sahnya Jual Beli Murabahah</strong>
        <ul>
          <li>
            Rukun murabahah adalah:
            <ol type="1">
            <li>
              Adanya pihak-pihak yang melakukan akad, yaitu:
              <ol type="a">
                <li>Penjual</li>
                <li>Pembeli</li>
              </ol>
            </li>
            <li>
              Obyek yang diakadkan, yang mencakup:
              <ol type="a">
                <li>Barang yang diperjual belikan</li>
                <li>Harga</li>
              </ol>
            </li>
            <li>
              Akad/Sighat yang terdiri dari:
              <ol type="a">
                <li>Ijab (serah)</li>
                <li>Qabul (terima)</li>
              </ol>
            </li>
          </ol>
          </li><br>
          <li>
            Selanjutnya masing-masing rukun diatas harus memenuhi
            syarat-syarat sebagai berikut:
            <ol type="1">
            <li>
              Pihak yang berakad, harus:
              <ol type="a">
                <li>Cakap hukum.</li>
                <li>
                  Sukarela (ridha), tidak dalam keadaan terpaksa
                  atau berada dibawah tekanan atau ancaman.
                </li>
              </ol>
            </li>
            <li>
              Obyek yang diperjualbelikan harus:
              <ol type="a">
                <li>Tidak termasuk yang diharamkan atau dilarang.</li>
                <li>Memberikan manfaat atau sesuatu yang bermanfaat.</li>
                <li>Penyerahan obyek <i>murabahah</i> dari penjual kepada pembeli dapat dilakukan.</li>
                <li>Merupakan hak milik penuh pihak yang berakad.</li>
                <li>Sesuai spesifikasinya antara yang diserahkan penjual dan yang diterima pembeli.</li>
              </ol>
            </li>
            <li>
              Akad/Sighat
              <ol type="a">
                <li>Harus jelas dan disebutkan secara spesifik dengan siapa berakad.</li>
                <li>Antara ijab dan qabul (serah terima) harus selaras baik dalam spesifikasi barang maupun harga yang disepakati.</li>
                <li>Tidak mengandung klausul yang bersifat menggantungkan keabsahan transaksi pada kejadian yang akan datang.</li>
              </ol>
            </li>
          </ol>
          </li><br>
          <li>
            Selain itu ada beberapa syarat-syarat sahnya jual beli
            murabahah adalah sebagai berikut:
            <ol type="1">
              <li>
                Mengetahui Harga pokok <br>
                <p class="paragraf-kedalam">
                  Harga beli awal (harga pokok) harus diketahui oleh
                  pembeli kedua, karena mengetahui harga merupakan salah
                  satu syarat sahnya jual beli yang menggunakan prinsip
                  murabahah. Mengetahui harga merupakan syarat sahnya akad
                  jual beli, dan mayoritas ahli fiqh menekankan pentingnya
                  syarat ini. Bila harga pokok tidak diketahui oleh pembeli
                  maka akad jual beli menjadi fasid (tidak sah) (Al-Kasany, hal.3193). Pada praktek perbankan syariah, Bank dapat menunjukkan bukti pembelian obyek jual beli murabahah kepada nasabah, sehingga dengan bukti pembelian tersebut nasabah mengetahui harga pokok Bank.
                </p>
              </li>
              <li>
                Mengetahui Keuntungan<br>
                <p class="paragraf-kedalam">
                  Keuntungan seharusnya juga diketahui karena ia
                  merupakan bagian dari harga. Keuntungan atau
                  dalam praktek perbankan syariah sering disebut
                  dengan margin murabahah dapat dimusyawarahkan
                  antara bank sebagai penjual dan nasabah sebagai
                  pembeli, sehingga kedua belah pihak, terutama
                  nasabah dapat mengetahui keuntungan bank.
                </p>
              </li>
              <li>
                Harga pokok dapat dihitung dan diukur<br>
                <p class="paragraf-kedalam">
                  Harga pokok harus dapat diukur, baik menggunakan
                  takaran, timbangan ataupun hitungan. Ini merupakan
                  syarat murabahah. Harga bisa menggunakan ukuran awal,
                  ataupun dengan ukuran yang berbeda, yang penting bisa
                  diukur dan di ketahui.
                </p>
              </li>
              <li>
                <p class="paragraf">
                  Jual beli murabahah tidak bercampur dengan transaksi
                  yang mengandung riba.
                </p>
              </li>
              <li>
                <p class="paragraf">
                  Akad jual beli pertama harus sah. Bila akad pertama
                  tidak sah maka jual beli murabahah tidak boleh dilaksanakan.
                  Karena murabahah adalah jual beli dengan harga pokok ditambah
                  keuntungan, kalau jual beli pertama tidak sah maka jual beli
                  murabahah selanjutnya juga tidak sah (Azzuhaily, hal. 3767-3770).
                </p>
              </li>
            </ol>
          </li>
        </ul>
      </div>
      <blockquote>
        <footer>From <a href="http://alhushein.blogspot.com/2011/12/murabahah.html" target="_blank">Pengertian Murabahah</a> website</footer>
      </blockquote>
    </div>
  </div>
</div>
