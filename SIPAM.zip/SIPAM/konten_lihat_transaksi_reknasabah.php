<!-- Isi Konten -->
<h1 class="text-center"><b>Rekening</b></h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>Data Transaksi Rekening Nasabah</b></h2>
  </div>
  <div class="panel-body">
    <!-- HR -->
    <table style="width:100%;">
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), black)"></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td><p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ&nbsp;اللهِ&nbsp;الرَّحْمَنِ&nbsp;الرَّحِيْمِ</p></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, black, rgba(0,0,0,0.75), rgba(0,0,0,0));"></td>
    </table>

    <div class="" style="width:30%;">
      <?php
      // LIHAT
      if (isset($_SESSION['manager'])){ ?>
        <form method="post" action="manager_lihat_data_tranreknasabah.php" >
      <?php } else if(isset($_SESSION['admin'])){?>
        <form method="post" action="admin_lihat_data_tranreknasabah.php" >
      <?php } ?>
        <!-- Tanggal Lahir -->
        <div class="form-group" style="width:100%;margin-bottom:2px;">
          <label>Dari Tanggal</label>
          <div class='input-group date' id='datetimepicker2'>
            <input type='text' name="dari_tgl" class="form-control"  style="pointer-events: none;" placeholder="Dari Tanggal" required>
            <span class="input-group-addon">
              <span class="glyphicon glyphicon-calendar"></span>
            </span>
          </div>
        </div><br>
        <div class="form-group" style="width:100%;margin-bottom:2px;">
          <label>Sampai Tanggal</label>
          <div class='input-group date' id='datetimepicker1'>
            <input type='text' name="sampai_tgl" class="form-control"  style="pointer-events: none;" placeholder="Sampai Tanggal" required>
            <span class="input-group-addon">
              <span class="glyphicon glyphicon-calendar"></span>
            </span>
          </div>
          <?php
            // Menyembunyikan eror
            error_reporting(0);
            $id_nsb   = $_GET['id'];
          ?>
          <input type="hidden" name='id' value='<?php echo "$id_nsb"; ?>'>
        </div><br>
        <input type="submit" class="btn btn-success" value="LIHAT"/>
      </form>
    </div>
    <hr>



      <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
          <thead>
            <tr>
              <th>No</th>
              <th>ID Tranrek</th>
              <th>Tanggal</th>
              <th>Debit</th>
              <th>Kredit</th>
              <th>Keterangan</th>
              <th>Saldo</th>
            </tr>
          </thead>
          <?php
            // Menyembunyikan eror
            error_reporting(0);
            $id_nsb   = $_GET['id'];

            $query = mysqli_query($konek, "SELECT * FROM data_laporanreknasabah WHERE id_nasabah = '$id_nsb'");
            $no = 1;
            while($rows = mysqli_fetch_array($query)){
          ?>
          <tbody id="myTable">
            <tr style="text-align:center;">
              <td><?php echo $no++;?></td>
              <td><?php echo $rows['id_tranrek'];      ?></td>
              <td><?php echo $rows['tanggal'];         ?></td>
              <td><?php echo number_format($rows['debit']);            ?></td>
              <td><?php echo number_format($rows['kredit']);          ?></td>
              <td><?php echo $rows['keterangan'];      ?></td>
              <td><?php echo number_format($rows['saldo']);           ?></td>
            </tr>
          </tbody>
          <?php
            }
           ?>
        </table>
      </div>

  </div>

</div>
