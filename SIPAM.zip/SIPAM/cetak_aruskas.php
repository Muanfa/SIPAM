<?php
  require "koneksi/koneksi.php";

  session_start();
  ob_start();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Nama Title -->
    <title>Berkah Madani</title>
    <!-- Ikon Gambar Title -->
    <link rel="icon" href="gambar/logo_BM.png" type="png">
  </head>
  <body>
    <!-- Header Cetak -->
    <table style="margin-top:20px;">
      <tr>
        <td style="width:900px;">
          <img src="gambar/Logo_BM1.png" alt="" style="float:left;"/>
          <p style="margin-top:-1px;padding-left:10px;">Koperasi Jasa Keuangan Syariah</p>
          <p style="margin-top:-25px;padding-left:10px;"><b>Berkah</b> Madani</p>
          <p style="margin-top:-15px;">Berkah Madani</p>
        </td>
        <td>
          <p style="font-family:Agency FB;text-align:right;"><b>Aplikasi Pembiayaan</b></p>
        </td>
      </tr>
      <tr style="padding:0px;margin-top:-40px;">
        <hr>
      </tr>
    </table>

    <div style="margin-top:-50px;">
      <h3 style="text-align:center;">Data Laporan Arus Kas</h3>
    </div>

    <table border="1px solid black;" style="margin-top:-30px;border-collapse: collapse;margin-left:180px;">
      <thead>
        <tr>
          <th style="border-collapse: collapse;padding:1.5px;">No</th>
          <th style="border-collapse: collapse;padding:1.5px;">ID Arus Kas</th>
          <th style="border-collapse: collapse;padding:1.5px;">Tanggal</th>
          <th style="border-collapse: collapse;padding:1.5px;">Debit Rp.</th>
          <th style="border-collapse: collapse;padding:1.5px;">Kredit Rp.</th>
          <th style="border-collapse: collapse;padding:1.5px;width:300px;">Keterangan</th>
          <th style="border-collapse: collapse;padding:1.5px;">Kode Akun</th>
        </tr>
      </thead>
      <tbody>
        <!-- Isi Konten Cetak -->
        <?php
          $id_pem = $_GET['id'];
          $query  = mysqli_query($konek, "SELECT * FROM data_laporanaruskas WHERE id_pembiayaan = '$id_pem'");
          $no = 1;
         ?>
        <!-- Koddingan Lanjutan dari atas  -->
        <?php
          while($rows = mysqli_fetch_array($query)){
        ?>

        <tr style="text-align:center;">
          <td style="border-bottom: 0px solid black;"><?php echo $no++;                                  ?></td>
          <td style="border-bottom: 0px solid black;"><?php echo $rows['id_aruskas'];                    ?></td>
          <td style="border-bottom: 0px solid black;"><?php echo $rows['tanggal'];                       ?></td>
          <td style="border-bottom: 0px solid black;"><?php echo number_format($rows['debit']);          ?></td>
          <td style="border-bottom: 0px solid black;"><?php echo number_format($rows['kredit']);         ?></td>
          <?php if ($rows['kredit'] == '0'){?>
              <td style="text-align:left;border-bottom: 0px solid black;"><?php echo $rows['keterangan'];?></td>
          <?php } else if($rows['debit'] == '0'){ ?>
              <td style="text-align:right;border-bottom: 0px solid black;"><?php echo $rows['keterangan'];?></td>
          <?php } ?>
          <td style="border-bottom: 0px solid black;"><?php echo $rows['kode_akun'];                      ?></td>
        </tr>

        <?php
          }
          $query2  = mysqli_query($konek, "SELECT * FROM data_transaksi WHERE id_pembiayaan = '$id_pem'");
          $data = mysqli_fetch_array($query2);
        ?>


      </tbody>
      <tfoot>
        <tr>
          <td style="border-top: 1px solid black;border-right: 0px solid black;border-left: 0px solid black;border-bottom: 0px solid black;border-right: 0px solid black;border-left: 0px solid black;border-bottom: 0px solid black;"></td>
          <td style="border-top: 1px solid black;border-right: 0px solid black;border-left: 0px solid black;border-bottom: 0px solid black;"></td>
          <td style="border-top: 1px solid black;border-right: 0px solid black;border-left: 0px solid black;border-bottom: 0px solid black;"></td>
          <td style="border-top: 1px solid black;border-right: 0px solid black;border-left: 0px solid black;border-bottom: 0px solid black;"></td>
          <td style="border-top: 1px solid black;border-right: 0px solid black;border-left: 0px solid black;border-bottom: 0px solid black;"></td>
          <td style="border-top: 1px solid black;border-right: 0px solid black;border-left: 0px solid black;border-bottom: 0px solid black;"></td>
          <td style="border-top: 1px solid black;border-right: 0px solid black;border-left: 0px solid black;border-bottom: 0px solid black;"></td>
        </tr>
      </tfoot>
    </table>

    <p>Data yang tertera di atas adalah Data Laporan Arus Kas dari Nasabah : <u><?php echo $data['nama_nasabah']; ?></u>, di KSPPS BMT Berkah Madani ini.</p>
    <?php
      // Mengambil Tanggal Sekarang
      // $hari = date('d');
      // $hari = $hari - 1;
      // $tgl = date('-m-Y');
      // $hari_ini = $hari . $tgl;
      $tgl = date('d-m-Y');

      echo "<p align='right'>Depok, ".$tgl."
      <img src='gambar/bm_ttd.png' width='120' style='pointer-events:none;'>
      ( Berkah Madani )</p>";
    ?>

  </body>
</html>

<?php
  $filename="aruskas_".$data['nama_nasabah'].".pdf"; //ubah untuk menentukan nama file pdf yang dihasilkan nantinya
  //==========================================================================================================
  //Copy dan paste langsung script dibawah ini,untuk mengetahui lebih jelas tentang fungsinya silahkan baca-baca tutorial tentang HTML2PDF
  //==========================================================================================================
  $content = ob_get_clean();
  $content = '<page style="font-family: ">'.nl2br($content).'</page>';
  require_once(dirname(__FILE__).'/html2pdf/html2pdf.class.php');
  try
  {
    $html2pdf = new HTML2PDF('L','A4','en', false, 'ISO-8859-15', array(10, -10, 10, -1000));
    $html2pdf->setDefaultFont('Arial');
    $html2pdf->writeHTML($content, isset($_GET['vuehtml']));
    $html2pdf->Output($filename);
  }
  catch(HTML2PDF_exception $e) { echo $e; exit; }
  ?>
