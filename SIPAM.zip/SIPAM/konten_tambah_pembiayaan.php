<h1 class="text-center"><b>Pembiayaan Akad Murabahah</b></h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>Daftar Pembiayaan Baru</b></h2>
  </div>
  <div class="panel-body">
    <!-- HR -->
    <table style="width:100%;">
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), black)"></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td><p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ&nbsp;اللهِ&nbsp;الرَّحْمَنِ&nbsp;الرَّحِيْمِ</p></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, black, rgba(0,0,0,0.75), rgba(0,0,0,0));"></td>
    </table>

    <form name='autoSumForm' action="proses_pembiayaan.php" method="get">


      <!-- Pembiayaan Di Ajukan -->
      <div class="col-sm-12" style="border-radius:15px;background-color:#f2f2f2;margin-bottom:5px;">
        <div style="padding:1px 0px 1px 0px;">
          <h2 class="text-center">Pembiayaan yang diajukan</h2>
          <table class="table" border=0>
            <!-- Mengecek apakah diizinkan tambah pembiayaan -->
            <?php
              // Menyembunyikan eror
              error_reporting(0);
              $id_nsb   = $_GET['id'];

              $query    = mysqli_query($konek,"SELECT * FROM data_pembiayaan WHERE id_nasabah ='$id_nsb'");
              $data     = mysqli_fetch_array($query);
              $cek      = $data['status'];
              $nama     = $data['nama_nasabah'];

              $peringatan = "";
              if($cek == "Proses") {
                if ($_SESSION['accountofficer']) {
                  $peringatan = "<script>
                                  swal('Pemberitahuan!', 'Nasabah $nama ini, Pembiayaan masih ada yang Proses!', 'error')
                                  .then((value) => {
                                    window.location.href='ao_data_pembiayaan.php?id=$id_nsb';
                                  });
                                </script>";
                } else if ($_SESSION['manager']) {
                  $peringatan = "<script>
                                  swal('Pemberitahuan!', 'Nasabah $nama ini, Pembiayaan masih ada yang Proses!', 'error')
                                  .then((value) => {
                                    window.location.href='manager_data_pembiayaan.php?id=$id_nsb';
                                  });
                                </script>";
                }
              }
              echo "$peringatan";
             ?>

            <!-- ID Pembiayaan -->
            <tr>
              <!-- Membuat ID Pembiayaan BARU -->
              <?php
                $hasil = mysqli_query($konek,"select max(id_pembiayaan) as idMaks from data_pembiayaan");
                $data  = mysqli_fetch_array($hasil);
                $idMax = $data['idMaks'];
                $noUrut = substr($idMax, 1, 5);
                $noUrut++;
                $format = "P";
                $newID = $format . sprintf("%05s", $noUrut);
               ?>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;">ID Pembiayaan :</label></th>
              <td style="border:none;"><input name="id_pemb" type="text" class="form-control disabled" value="<?php echo "$newID";?>" readonly></td>
            </tr>
            <!-- Nama Nasabah -->
            <tr>
              <!-- Mengambil nama nasabah -->
              <?php
                $query    = mysqli_query($konek,"SELECT * FROM data_nasabah WHERE id_nasabah ='$id_nsb'");
                $data     = mysqli_fetch_array($query);
                $nama_nsb = $data['nama'];
               ?>
              <td style="border:none;"><label style="margin-top:8px;">Nama Nasabah :</label></td>
              <td style="border:none;"><input name="nma_nsb" type="text" class="form-control" placeholder="Nama Nasabah" value="<?php echo "$nama_nsb"; ?>" readonly></td>
            </tr>
            <!-- Tanggal Daftar -->
            <tr>
              <?php
                // $hari = date('d');
                // $hari = $hari - 1;
                // $no = array(
                //   '1' => '01',
                //   '2' => '02',
                //   '3' => '03',
                //   '4' => '04',
                //   '5' => '05',
                //   '6' => '06',
                //   '7' => '07',
                //   '8' => '08',
                //   '9' => '09'
                // );
                // if ($hari < "10") {
                //     $hari = $no[$hari];
                // }
                // $tgl = date('-m-Y');
                $tgl_sekarang = date('d-m-Y');
              ?>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;">Tanggal Daftar :</label></th>
              <!-- <td style="border:none;"><input name="tgl_dft" value=<?php if (date('d') > $hari) { echo "$hari" . "$tgl";} else {echo "$tgl_sekarang";}?> type="text" class="form-control" readonly></td> -->
              <td style="border:none;"><input name="tgl_dft" value=<?php echo "$tgl_sekarang";?> type="text" class="form-control" readonly></td>
            </tr>
            <!-- Kegunaan -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;">Kegunaan :</label></th>
              <td style="border:none;">
                <select name="kgnaan" class="form-control" id="sel1">
                  <option value="Konsumtif" selected>Konsumtif</option>
                  <option value="Modal Kerja">Modal Kerja</option>
                  <option value="Investasi">Investasi</option>
                </select>
              </td>
            </tr>
            <!-- Obyek Pembiayaan -->
            <tr>
              <td colspan="2" style="border:none;"><input name="oby_pemb" type="text" class="form-control" placeholder="Obyek Pembiayaan" required></td>
            </tr>
            <!-- Jenis Pembiayaan -->
            <tr>
              <td style="border:none;"><label style="margin-top:6px;">Jenis Pembiayaan :</label></td>
              <td style="border:none;"><input name="jns_pemb" type="text" value="Murabahah" class="form-control" placeholder="Murabahah" readonly></td>
            </tr>
            <!-- Sistem Pembayaran -->
            <tr>
              <td style="border:none;"><label style="margin-top:6px;">Sistem Pembayaran :</label></td>
              <td style="border:none;"><input name="sist_pmbyrn" type="text" value="Angsuran" class="form-control" placeholder="Angsuran" readonly></td>
            </tr>
            <!-- Jumlah Pembiayaan -->
            <tr>
              <td style="border:none;"><label style="margin-top:6px;">Jumlah Pembiayaan (ke nasabah):</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input style="border-radius:4px;" name="jml_pmbyn" onFocus="startCalc();" onBlur="stopCalc();" type="text" onKeyPress="return angkadanhuruf(event,'0123456789',this)" class="form-control" placeholder="Jumlah Pembiayaan" required>
                </div>
              </td>
            </tr>
            <!-- Margin -->
            <tr>
              <td style="border:none;"><label style="margin-top:6px;">Margin :</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <!-- <input style="border-radius:4px;" name="margin" onFocus="startCalc();" onBlur="stopCalc();" type="text" onKeyPress="return angkadanhuruf(event,'0123456789.',this)" class="form-control" placeholder="Margin (%)" required> -->
                  <select name="margin" onFocus="startCalc();" onBlur="stopCalc();" class="form-control" id="sel1">
                    <option value="2" selected>2</option>
                    <option value="2.5">2.5</option>
                  </select>
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>%</b></span>
                </div>
                <p style="font-size:12px;margin-bottom:0px;">
                  <b><mark>Catatan</mark>:</b> Margin yang di BMT Berkah Madani hanya 2 atau 2.5 (%).
                </p>
              </td>
            </tr>
            <!-- Jangaka Waktu  -->
            <tr>
              <td style="border:none;"><label style="margin-top:6px;">Jangka Waktu :</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <input name="jngk_waktu" onFocus="startCalc();" onBlur="stopCalc();" type="text" maxlength="2" onKeyPress="return angkadanhuruf(event,'0123456789',this)" class="form-control" placeholder="Jangka Waktu (Perbulan)" style="border-radius:4px;" required>
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Bulan</b></span>
                </div>
              </td>
            </tr>
            <!-- Kas BMT (di kembalikan)  -->
            <tr>
              <td style="border:none;"><label style="margin-top:6px;">Kas BMT (di Kembalikan) :</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input style="border-radius:4px;" name="kas_bmt" onchange='tryNumberFormat(this.form.thirdBox);' type="text" class="form-control" placeholder="" readonly>
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>/Bulan</b></span>
                </div>
                <p style="font-size:12px;margin-bottom:0px;">
                  <b><mark>Perhitungan</mark>:</b> Kas BMT = Jumlah Pembiayaan / Jangka Waktu.
                </p>
              </td>
            </tr>
            <!-- Pendapatan Margin  -->
            <tr>
              <td style="border:none;"><label style="margin-top:6px;">Pendapatan Margin :</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input style="border-radius:4px;" name="pndptn_margin" onchange='tryNumberFormat(this.form.thirdBox);' type="text" class="form-control" placeholder="" readonly>
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>/Bulan</b></span>
                </div>
                <p style="font-size:12px;margin-bottom:0px;">
                  <b><mark>Perhitungan</mark>:</b> Pendapatan Margin = Jumlah Pembiayaan x Margin.
                </p>
              </td>
            </tr>
            <!-- Total Jumlah Angsuran  -->
            <tr>
              <td style="border:none;"><label style="margin-top:7px;">Total Jumlah Angsuran :</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;"><script></script>
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input style="border-radius:4px;" name="jml_angs" onchange='tryNumberFormat(this.form.thirdBox)' type="text" class="form-control" placeholder="" readonly>
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>/Bulan</b></span>
                </div>
                <p style="font-size:12px;margin-bottom:0px;">
                  <b><mark>Perhitungan</mark>:</b> Total Jumlah Angsuran = Kas BMT + Pendapatan Margin.
                </p>
              </td>
            </tr>
            <!-- Total Jumlah Margin  -->
            <tr>
              <td style="border:none;"><label style="margin-top:6px;">Total Jumlah Margin :</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input style="border-radius:4px;" name="total_margin" onchange='tryNumberFormat(this.form.thirdBox);' type="text" class="form-control" placeholder="" readonly>
                </div>
                <p style="font-size:12px;margin-bottom:0px;">
                  <b><mark>Perhitungan</mark>:</b> Total Jumlah Margin = Pendapatan Margin x Jangka Waktu.
                </p>
              </td>
            </tr>
            <!-- Total Jumlah Pembiayaan  -->
            <tr>
              <td><label class="panel panel-default" style="margin-top:6px;margin-bottom:0px;">&nbsp;Total Jumlah Pembiayaan :&#160;</label></td>
              <td>
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input style="border-radius:4px;" name="total_pmbyaan" onchange='tryNumberFormat(this.form.thirdBox);' type="text" class="form-control" placeholder="" readonly>
                </div>
                <p style="font-size:12px;margin-bottom:0px;">
                  <b><mark>Perhitungan</mark>:</b> Sisa Setoran = Total Jumlah Pembiayaan + Total Jumlah Margin.
                </p>
              </td>
            </tr>
            <!-- Sisa Setoran  -->
            <tr>
              <td style="border:none;"><label style="margin-top:7px;">Sisa Setoran :</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input style="border-radius:4px;" name="sisa_setoran" onchange='tryNumberFormat(this.form.thirdBox);' type="text" class="form-control" placeholder="" readonly>
                </div>
              </td>
            </tr>
          </table>
        </div>
      </div>

      <!-- Data Jaminan -->
      <div class="col-sm-12" style="border-radius:15px;background-color:#f2f2f2;">
        <div style="padding:1px 0px 1px 0px;">
          <h2 class="text-center">Jaminan</h2>
          <table class="table" border=0>
            <!-- ID Jaminan -->
            <tr>
              <!-- Membuat ID Jaminan BARU -->
              <?php
                $hasil = mysqli_query($konek,"select max(id_jaminan) as idMaks from data_jaminan");
                $data  = mysqli_fetch_array($hasil);
                $idMax = $data['idMaks'];
                $noUrut =  substr($idMax, 1, 5);
                $noUrut++;
                $format = "J";
                $newID3 = $format . sprintf("%05s", $noUrut);
               ?>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;">ID Jaminan :</label></th>
              <td style="border:none;"><input name="id_jam" type="text" class="form-control" value=<?php echo "$newID3";?> readonly></td>
            </tr>
            <!-- Jenis Jaminan -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;" >Jenis Jaminan :</label></th>
              <td style="border:none;">
                <select name="jns_jam" class="form-control" id="sel1">
                  <option value="Tanah/Pembangunan" selected>Tanah/Pembangunan</option>
                  <option value="Kios/Toko">Kios/Toko</option>
                  <option value="Kendaraan">Kendaraan</option>
                  <option value="Lainnya">Lainnya</option>
                </select>
              </td>
            </tr>
            <!-- Dokumen Jaminan -->
            <tr>
              <td style="border:none;"><label style="margin-top:8px;">Dokumen Jaminan :</label></td>
              <td style="border:none;"><input name="dok_jam" type="text" class="form-control" placeholder="Dokumen Jaminan" required></td>
            </tr>
            <!-- Lokasi Jaminan  -->
            <tr>
              <td colspan="2"style="border:none;"><textarea name="almt_jam" class="form-control" rows="5" style="resize:none;" placeholder="Lokasi Jaminan" required></textarea></td>
            </tr>
            <!-- Nilai Jaminan -->
            <tr>
              <td style="border:none;"><label style="margin-top:8px;">Nilai Jaminan :</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input style="border-radius:4px;" name="nilai_jam" type="text" onKeyPress="return angkadanhuruf(event,'0123456789',this)" class="form-control" placeholder="Nilai Jaminan" required>
                </div>
                <p style="font-size:12px;margin-bottom:0px;">
                  <b><mark>Catatan</mark>:</b> Nilai Jaminan harus lebih tinggi dari Total Jumlah Pembiayaan.
                </p>
              </td>
            </tr>
            <!-- Pemilik Jaminan -->
            <tr>
              <td style="border:none;"><label style="margin-top:8px;">Pemilik Jaminan :</label></td>
              <td style="border:none;"><input name="pmlk_jam" type="text" class="form-control" placeholder="Pemilik Jaminan" value="<?php echo "$nama_nsb"; ?>" readonly></td>
            </tr>


            <!-- Simpan id nsb -->
            <tr>
              <td colspan="2" style="border:none;"><input name="id_nsb" type="hidden" class="form-control" placeholder="Pemilik Jaminan" value="<?php echo "$id_nsb"; ?>" readonly></td>
            </tr>
          </table>
        </div>
      </div>

      <!-- Tombol Simpan -->
      <div class="col-sm-12">
        <div style="text-align:center;">
          <input class="btn btn-success" type="submit" value="SIMPAN" name="tambah_pembiayaan" style="margin-top:15px;" readonly></input>
        </div>
        <!-- Untuk Info Jika Simpan Berhasil / Gagal -->
        <?php
          if (isset($_GET['ok'])){
            $error=$_GET['ok'];
          }else{
            $error="";
          }

          $pesan="";
          if ($error=="berhasil"){
                // BERHASIL
                if ($_SESSION['accountofficer']) {
                  $pesan=  "<script>
                              swal('Berhasil!', 'Data Telah Tersimpan!', 'success')
                              .then((value) => {
                                window.location.href='ao_data_pembiayaan.php';
                              });
                            </script>";
                } else if ($_SESSION['manager']) {
                  $pesan=  "<script>
                              swal('Berhasil!', 'Data Telah Tersimpan!', 'success')
                              .then((value) => {
                                window.location.href='manager_data_pembiayaan.php';
                              });
                            </script>";
                }
          } else if ($error=="gagal") {
                // GAGAL
                if ($_SESSION['accountofficer']) {
                  $pesan=  "<script>
                              swal('Gagal!', 'Data Gagal Diubah Di Database!', 'error')
                              .then((value) => {
                                swal('Info!', 'Coba Periksa Di File proses_pembiayaan.php / kode halaman ini', 'info')
                                .then((value) => {
                                  window.location.href='ao_tambah_pembiayaan.php';
                                })
                              });
                            </script>";
                } else if ($_SESSION['manager']) {
                  $pesan=  "<script>
                              swal('Gagal!', 'Data Gagal Diubah Di Database!', 'error')
                              .then((value) => {
                                swal('Info!', 'Coba Periksa Di File proses_pembiayaan.php / kode halaman ini', 'info')
                                .then((value) => {
                                  window.location.href='manager_tambah_pembiayaan.php';
                                })
                              });
                            </script>";
                }
          }
          // Tampil Hasil Pesan
          echo "$pesan";
         ?>
      </div>
    </form>
  </div>
</div>
