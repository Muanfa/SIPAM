<h1 class="text-center"><b>Nasabah</b></h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>Data Rekening</b></h2>
  </div>
  <div class="panel-body">
    <!-- HR -->
    <table style="width:100%;">
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), black)"></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td><p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ&nbsp;اللهِ&nbsp;الرَّحْمَنِ&nbsp;الرَّحِيْمِ</p></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, black, rgba(0,0,0,0.75), rgba(0,0,0,0));"></td>
    </table>

    <!-- BUTTON CETAK LAPORAN -->
    <div>
      <button type='button' onclick="window.open('cetak_tranreknasabah.php?dari_tgl=<?php echo $_POST['dari_tgl'];?>&sampai_tgl=<?php echo $_POST['sampai_tgl'];?>&id=<?php echo $_POST['id'];?>','nama_window_pop_up','width=200,height=200,scrollbars=yes,resizeable=no')" class='btn btn-info btn-lg'>
        <span class="glyphicon glyphicon-print" style="color:black;"></span> Cetak</button>
      <hr>
    </div>

    <?php
      $id_nsb = $_POST['id'];
      $query1 = mysqli_query($konek, "SELECT * FROM data_nasabah WHERE id_nasabah = '$id_nsb'");
      $data   = mysqli_fetch_array($query1);
    ?>

    <h3 align="center"><b>Laporan Data Transaksi Reknening Nasabah</b></h3>
    <h3 align="center"><b><?php echo $data['nama']; ?></b></h3>
    <h3 align="center"><b>dari <i><?php echo $_POST['dari_tgl'];?></i> hingga <i><?php echo $_POST['sampai_tgl'];?></i></b></h3>
    <?php
      $dari_tgl   = $_POST['dari_tgl'];
      $sampai_tgl = $_POST['sampai_tgl'];

      $query = mysqli_query($konek, "SELECT * FROM data_laporanreknasabah WHERE tanggal BETWEEN '$dari_tgl' AND '$sampai_tgl' AND id_nasabah = '$id_nsb'");
      while($rows2 = mysqli_fetch_array($query)){
      }
     ?>
    <div class="container-fluid panel panel-default" style="padding-top:10px;padding-bottom:10px;">
      <table id="asexample" class="table responsive table-striped table-bordered table-hover" style="width:100%">
        <thead>
          <tr>
            <th>No</th>
            <th>ID Tranrek</th>
            <th>Tanggal</th>
            <th>Debit</th>
            <th>Kredit</th>
            <th>Keterangan</th>
            <th>Saldo</th>
          </tr>
        </thead>
        <tbody>
          <?php


            $query = mysqli_query($konek, "SELECT * FROM data_laporanreknasabah WHERE tanggal BETWEEN '$dari_tgl' AND '$sampai_tgl' AND id_nasabah = '$id_nsb'");
            $no = 1;
            while($rows = mysqli_fetch_array($query)){
           ?>

          <tr style="text-align:center;">
            <td><?php echo $no++;?></td>
            <td><?php echo $rows['id_tranrek'];      ?></td>
            <td><?php echo $rows['tanggal'];         ?></td>
            <td><?php echo number_format($rows['debit']);            ?></td>
            <td><?php echo number_format($rows['kredit']);          ?></td>
            <td><?php echo $rows['keterangan'];      ?></td>
            <td><?php echo number_format($rows['saldo']);           ?></td>
          </tr>

          <?php
            }
          ?>
        </tbody>
      </table>
    </div>

  </div>
</div>
