<h1 class="text-center"><b>Pembiayaan Akad Murabahah</b></h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>Data Pembiayaan Baru</b></h2>
  </div>
  <div class="panel-body">
    <!-- HR -->
    <table style="width:100%;">
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), black)"></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td><p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ&nbsp;اللهِ&nbsp;الرَّحْمَنِ&nbsp;الرَّحِيْمِ</p></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, black, rgba(0,0,0,0.75), rgba(0,0,0,0));"></td>
    </table>

    <div class="container-fluid panel panel-default" style="padding-top:10px;padding-bottom:10px;">
      <table id="asexample" class="table responsive table-striped table-bordered table-hover" style="width:100%">
        <thead>
          <tr>
              <th>No</th>
              <th>Aksi</th>
              <th>ID Nasabah</th>
              <th>Nama</th>
              <th>Alamat</th>
              <th>Nomer Telepon</th>
              <th>Jenis Kelamin</th>
              <th>Tanggal Lahir</th>
              <th>Identitas Diri</th>
              <th>Email</th>
              <th>Tanggal Daftar</th>
              <th>Pekerjaan</th>
              <th>Perusahaan</th>
              <th>Bidang Usaha</th>
              <th>Alamat Usaha</th>
              <th>Nama Istri/Suami</th>
          </tr>
        </thead>
        <tbody>


          <?php
            $query = mysqli_query($konek, "SELECT * FROM data_nasabah ORDER BY id_nasabah");
            $no = 1;
            while($rows = mysqli_fetch_array($query)){
           ?>

          <tr style="text-align:center;">
            <td><?php echo $no++;?></td>
            <td style="width:0px;">
              <!-- TAMBAH -->
              <?php if (isset($_SESSION['manager'])){ ?>
                <button type='button' onclick="window.location = 'manager_tambah_pembiayaan.php?id=<?php echo $rows['id_nasabah'];?>'" class='btn btn-success btn-sm'>Tambah</button>                      </td>
              <?php } else if(isset($_SESSION['accountofficer'])){?>
                <button type='button' onclick="window.location = 'proses_pembiayaan.php?id=<?php echo $rows['id_nasabah'];?>&cek=ok'" class='btn btn-success btn-sm'>Tambah</button>                      </td>
              <?php } ?>
            <td><?php echo $rows['id_nasabah'];                   ?></td>
            <td><?php echo $rows['nama']                          ?></td>
            <td><?php echo $rows['alamat'];                       ?></td>
            <td><?php echo $rows['no_telp'];                      ?></td>
            <td><?php echo $rows['jenis_kelamin'];                ?></td>
            <td><?php echo $rows['tanggal_lahir'];                ?></td>
            <td><?php echo $rows['identitas_diri'];               ?></td>
            <td><?php echo $rows['email'];                        ?></td>
            <td><?php echo $rows['tanggal_daftar'];               ?></td>
            <td><?php echo $rows['pekerjaan'];                    ?></td>
            <td><?php echo $rows['perusahaan'];                   ?></td>
            <td><?php echo $rows['bidang_usaha'];                 ?></td>
            <td><?php echo $rows['alamat_usaha'];                 ?></td>
            <td><?php echo $rows['nama_istri_suami'];             ?></td>
          </tr>

          <?php
            }
          ?>
        </tbody>
      </table>
      <!-- Untuk Info Jika Simpan Berhasil / Gagal -->
      <?php
          if (isset($_GET['ok'])){
            $error=$_GET['ok'];
          }else{
            $error="";
          }

          $pesan="";
          if ($error=="gagal"){
                // BERHASIL
                if ($_SESSION['accountofficer']) {
                  $pesan=  "<script>
                              swal('Gagal!', 'Data Nasabah ini Status masih ada Proses', 'error')
                              .then((value) => {
                                window.location.href='ao_data_tambah_pembiayaan.php';
                              });
                            </script>";
                } else if ($_SESSION['manager']) {
                  $pesan=  "<script>
                              swal('Gagal!', 'Data Nasabah ini Status masih ada Proses', 'error')
                              .then((value) => {
                                window.location.href='manager_data_tambah_pembiayaan.php';
                              });
                            </script>";
                }
          }
          // Tampil Hasil Pesan
          echo "$pesan";
         ?>
    </div>

  </div>
</div>
