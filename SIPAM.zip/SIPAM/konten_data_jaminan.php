<!-- Isi Konten -->
<h1 class="text-center"><b>Pembiayaan Akad Murabahah</b></h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>Data Jaminan</b></h2>
  </div>
  <div class="panel-body">
    <!-- HR -->
    <table style="width:100%;">
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), black)"></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td><p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ&nbsp;اللهِ&nbsp;الرَّحْمَنِ&nbsp;الرَّحِيْمِ</p></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, black, rgba(0,0,0,0.75), rgba(0,0,0,0));"></td>
    </table>

    <div class="container-fluid panel panel-default" style="padding-top:10px;padding-bottom:10px;">
      <table id="asexample" class="table responsive table-striped table-bordered table-hover" style="width:100%">
        <thead>
          <tr>
              <th>No</th>
              <th>Aksi</th>
              <th>ID Jaminan</th>
              <th>Pemilik Jaminan</th>
              <th>Jenis Jaminan</th>
              <th>Dokumen Jaminan</th>
              <th>Lokasi Jaminan</th>
              <th>Nilai Jaminan Rp.</th>
          </tr>
        </thead>
        <tbody>
          <?php
            $query = mysqli_query($konek, "SELECT * FROM data_jaminan ORDER BY id_jaminan");
            $no = 1;
            while($rows = mysqli_fetch_array($query)){
           ?>

          <tr style="text-align:center;">
            <td><?php echo $no++;?></td>
            <td style="width:115px;">
              <!-- UBAH -->
              <?php // if (isset($_SESSION['manager'])){ ?>
                <!-- <button type='button' onclick="window.location = 'manager_ubah_jaminan.php?id=<?php // echo $rows['id_nasabah'];?>'" class='btn btn-success btn-sm'>Ubah</button>&#32; -->
              <?php // } else
               if(isset($_SESSION['accountofficer'])){?>
                <button type='button' onclick="window.location = 'ao_ubah_jaminan.php?id=<?php echo $rows['id_nasabah'];?>'" class='btn btn-success btn-sm'>Ubah</button>&#32;
              <?php } ?>
              <button type='button' onclick="window.open('cetak_jaminan.php?id=<?php echo $rows['id_nasabah'];?>','nama_window_pop_up','size=800,height=800,scrollbars=yes,resizeable=no')" class='btn btn-info btn-sm'>Cetak</button>
            </td>
            <td><?php echo $rows['id_jaminan'];                       ?></td>
            <td><?php echo $rows['pemilik_jaminan'];                  ?></td>
            <td><?php echo $rows['jenis_jaminan'];                    ?></td>
            <td><?php echo $rows['dokumen_jaminan'];                  ?></td>
            <td><?php echo $rows['lokasi_jaminan'];                   ?></td>
            <td><?php echo number_format($rows['nilai_jaminan']);     ?></td>
          </tr>

          <?php
            }
          ?>
        </tbody>
      </table>
    </div>

  </div>
</div>
