<h1 class="text-center"><b>Pegawai</b></h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>Data Pegawai</b></h2>
  </div>
  <div class="panel-body">
    <!-- HR -->
    <table style="width:100%;">
      <h1>muhammad Andi fadillah</h1>
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), black)"></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td><p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ&nbsp;اللهِ&nbsp;الرَّحْمَنِ&nbsp;الرَّحِيْمِ</p></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, black, rgba(0,0,0,0.75), rgba(0,0,0,0));"></td>
    </table>

    <div class="container-fluid panel panel-default" style="padding-top:10px;padding-bottom:10px;">
      <table id="asexample" class="table responsive table-striped table-bordered table-hover" style="width:100%">
        <thead>
          <tr>
              <th>No</th>
              <th>Aksi</th>
              <th>ID Pegawai</th>
              <th>Nama</th>
              <th>Jenis Kelamin</th>
              <th>Jabatan</th>
              <th>Tanggal Daftar</th>
              <th>Nomer Telepon</th>
              <th>Tanggal Lahir</th>
              <th>Identitas Diri</th>
              <th>Email</th>
              <th>Alamat</th>
          </tr>
        </thead>
        <tbody>


          <?php
            $query = mysqli_query($konek, "SELECT * FROM data_pegawai ORDER BY id_pegawai");
            $no =1;
            while($rows = mysqli_fetch_array($query)){
              $status = $rows['jabatan'];
          ?>

          <tr style="text-align:center;">
            <td><?php echo $no++;?></td>
            <td style="width:140px;">
              <!-- UBAH -->
              <?php
                if (isset($_SESSION['manager']))
                {
                      if ($status == "Manager")
                      {
              ?>
                          <button type='button' onclick="window.location = 'manager_ubah_pegawai.php?id=<?php echo $rows['id_pegawai'];?>'" class='btn btn-success btn-sm'>Ubah</button>&#32;
              <?php
                      }
                } if(isset($_SESSION['admin'])) {
                      if ($status != "Manager") {
              ?>
                        <button type='button' onclick="window.location = 'admin_ubah_pegawai.php?id=<?php echo $rows['id_pegawai'];?>'" class='btn btn-success btn-sm'>Ubah</button>&#32;
              <?php
                      }
                }
              ?>

              <!-- CETAK -->
              <button type='button' onclick="window.open('cetak_pegawai.php?id=<?php echo $rows['id_pegawai'];?>','nama_window_pop_up','size=800,height=800,scrollbars=yes,resizeable=no')" class='btn btn-info btn-sm'>Cetak</button>
              <!-- <button type='button' onclick="window.location = 'proses_pegawai.php?id=<?php echo $rows['id_pegawai'];?>'" class='btn btn-danger btn-sm'>Hapus</button> -->

              <?php
              // HAPUS
              if (isset($_SESSION['manager'])) {?>
                <button type='button' onclick="swal({
                                        title: 'Apakah anda yakin?',
                                        text: 'Setelah dihapus, Anda tidak akan dapat memulihkan data ini!',
                                        icon: 'warning',
                                        buttons: true,
                                        dangerMode: true,
                                      })
                                      .then((willDelete) => {
                                        if (willDelete) {
                                          window.location.href = 'proses_pegawai.php?id=<?php echo $rows['id_pegawai'];?>';
                                        }
                                      })" class='btn btn-danger btn-sm'>Hapus
                </button>
              <?php
                }
               ?>

            </td>
            <td><?php echo $rows['id_pegawai'];                                ?></td>
            <td><?php echo $rows['nama_depan'] . " ". $rows['nama_belakang'];  ?></td>
            <td><?php echo $rows['jenis_kelamin'];                             ?></td>
            <td><?php echo $rows['jabatan'];                                   ?></td>
            <td><?php echo $rows['tanggal_daftar'];                            ?></td>
            <td><?php echo $rows['nomer_telepon'];                             ?></td>
            <td><?php echo $rows['tanggal_lahir'];                             ?></td>
            <td><?php echo $rows['identitas_diri'];                            ?></td>
            <td><?php echo $rows['email'];                                     ?></td>
            <td><?php echo $rows['alamat'];                                    ?></td>
          </tr>

          <?php
            }
          ?>
        </tbody>
      </table>


      <?php
       // Untuk Info Jika Simpan Berhasil atau Gagal
        if (isset($_GET['ok'])){
          $error=$_GET['ok'];
        }else{
          $error="";
        }

        $pesan="";
        if ($error=="berhasil"){
              // BERHASIL
              if (isset($_SESSION['admin'])) {
                $pesan=  "<script>
                            swal('Berhasil!', 'Data Telah Dihapus!', 'success')
                            .then((value) => {
                              window.location.href='admin_data_pegawai.php';
                            });
                          </script>";
              } else if (isset($_SESSION['manager'])) {
                $pesan=  "<script>
                            swal('Berhasil!', 'Data Telah Dihapus!', 'success')
                            .then((value) => {
                              window.location.href='manager_data_pegawai.php';
                            });
                          </script>";
              }
        }else if ($error=="gagal") {
              if (isset($_SESSION['admin'])) {
                $pesan=  "<script>
                            swal('Gagal!', 'Data Gagal Dihapus Di Database!', 'error')
                            .then((value) => {
                              swal('Info!', 'Coba Periksa Di File proses_pegawai.php', 'info')
                              .then((value) => {
                                window.location.href='admin_data_pegawai.php';
                              })
                            });
                          </script>";
              } else if (isset($_SESSION['manager'])) {
                $pesan=  "<script>
                            swal('Gagal!', 'Data Gagal Dihapus Di Database!', 'error')
                            .then((value) => {
                              swal('Info!', 'Coba Periksa Di File proses_pegawai.php', 'info')
                              .then((value) => {
                                window.location.href='manager_data_pegawai.php';
                              })
                            });
                          </script>";
              }
        }
        echo "$pesan";
       ?>
    </div>

  </div>
</div>
