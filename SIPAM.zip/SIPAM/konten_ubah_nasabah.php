<h1 class="text-center"><b>Nasabah</b></h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>Daftar Nasabah Baru</b></h2>
  </div>
  <div class="panel-body">
    <!-- HR -->
    <table style="width:100%;">
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), black)"></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td><p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ&nbsp;اللهِ&nbsp;الرَّحْمَنِ&nbsp;الرَّحِيْمِ</p></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, black, rgba(0,0,0,0.75), rgba(0,0,0,0));"></td>
    </table>

    <form name='autoSumForm' action="proses_nasabah.php" method="get">

      <!-- Data Nasabah -->
      <div class="col-sm-12" style="border-radius:15px;background-color:#f2f2f2;margin-bottom:5px;">
        <div style="padding:1px 0px 1px 0px;">
          <h2 class="text-center">Data Pemohon</h2>
          <table class="table" border=0>
            <?php
              // Fungsi ini menyembunyikan eror
              error_reporting(0);
              // Mengambil nilai id, dari form manager_data_pegawai.php dari tombol UBAH
              $id	  	= $_GET['id'];
              $query	= mysqli_query($konek,"SELECT * FROM data_nasabah WHERE id_nasabah='$id'");
              $data	  = mysqli_fetch_array($query);
            ?>
            <!-- ID Nasabah -->
            <tr>
                <th style="border:none;"><label class="control-label" style="margin-top:8px;">ID Nasabah :</label></th>
                <td style="border:none;"><input name="id_nas" type="text" class="form-control disabled" value="<?php echo $data['id_nasabah'];?>" readonly></td>
            </tr>
            <!-- Nama Lengkap -->
            <tr>
              <td colspan="2" style="border:none;"><input id="txtFirst" onkeyup="copytextbox();" name="nama_lkp" type="text" class="form-control" placeholder="Nama Lengkap" value="<?php echo $data['nama'];?>" required></td>
            </tr>
            <!-- Alamat -->
            <tr>
              <td colspan="2"style="border:none;"><textarea name="almt" class="form-control" rows="5" style="resize:none;" placeholder="Alamat Tempat Tinggal" required><?php echo $data['alamat'];?></textarea></td>
            </tr>
            <!-- No Telepon -->
            <tr>
              <td colspan="2" style="border:none;"><input name="no_telp" type="text" onKeyPress="return angkadanhuruf(event,'0123456789',this)" class="form-control" placeholder="Nomer Telepon" value="<?php echo $data['no_telp'];?>" required></td>
            </tr>
            <!-- Jenis Kelamin -->
            <tr>
              <th style="border:none;">Jenis Kelamin :</td>
              <td style="border:none;">
                <label class="radio-inline" style="text-align:right;">
                  <input type="radio" name="jk" value="Pria" <?php if ($data['jenis_kelamin']=="Pria") { echo "checked=\"checked\""; } ?>>Pria
                </label>
                <label class="radio-inline" >
                  <input type="radio" name="jk" value="Wanita" <?php if ($data['jenis_kelamin']=="Wanita") { echo "checked=\"checked\""; } ?> style="text-align:right;">Wanita
                </label>
              </td>
            </tr>
            <!-- Tanggal Lahir -->
            <tr>
              <td colspan="2" style="border:none;">
                <div class="form-group" style="width:100%;margin-bottom:2px;">
                  <div class='input-group date' id='datetimepicker2'>
                    <input type='text' name="tgl_lhr" value="<?php echo $data['tanggal_lahir'];?>" class="form-control"  style="pointer-events:none;" placeholder="Tanggal Lahir" required>
                    <span class="input-group-addon">
                      <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                  </div>
                </div>
              </td>
            </tr>
            <!-- Identitas Diri -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;" >Identitas Diri :</label></th>
              <td style="border:none;">
                <select name="ident" class="form-control" id="sel1">
                  <option value="KTP"     <?php if ($data['identitas_diri']=="KTP") { echo "selected=\"selected\""; } ?>>KTP</option>
                  <option value="SIM"     <?php if ($data['identitas_diri']=="SIM") { echo "selected=\"selected\""; } ?>>SIM</option>
                  <option value="Paspor"  <?php if ($data['identitas_diri']=="Paspor") { echo "selected=\"selected\""; } ?>>Paspor</option>
                  <option value="Lainnya" <?php if ($data['identitas_diri']=="Lainnya") { echo "selected=\"selected\""; } ?>>Lainnya</option>
                </select>
              </td>
            </tr>
            <!-- Email -->
            <tr>
              <td colspan="2" style="border:none;"><input name="email" type="email" id="email" class="form-control" placeholder="Email" value="<?php echo $data['email'];?>" required></td>
            </tr>
            <!-- Tanggal Daftar -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;">Tanggal Daftar :</label></th>
              <td style="border:none;"><input name="tgl_dft" value="<?php echo $data['tanggal_daftar'];?>" type="text" class="form-control" readonly></td>
            </tr>
            <!-- Pekerjaan -->
            <tr>
              <td colspan="2" style="border:none;"><input name="pkrjn" type="text" class="form-control" placeholder="Pekerjaan" value="<?php echo $data['pekerjaan'];?>" required></td>
            </tr>
            <!-- Perusahaan -->
            <tr>
              <td colspan="2" style="border:none;"><input name="prshn" type="text" class="form-control" placeholder="Perusahaan" value="<?php echo $data['perusahaan'];?>" required></td>
            </tr>
            <!-- Bidang Usaha -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;">Bidang Usaha :</label></th>
              <td style="border:none;">
                <select name="bdng_usha" class="form-control" id="sel1">
                  <option value="Produksi"    <?php if ($data['bidang_usaha']=="Produksi")    { echo "selected=\"selected\""; } ?>>Produksi</option>
                  <option value="Jasa"        <?php if ($data['bidang_usaha']=="Jasa")        { echo "selected=\"selected\""; } ?>>Jasa</option>
                  <option value="Perdagangan" <?php if ($data['bidang_usaha']=="Perdagangan") { echo "selected=\"selected\""; } ?>>Perdagangan</option>
                  <option value="Pertanian"   <?php if ($data['bidang_usaha']=="Pertanian")   { echo "selected=\"selected\""; } ?>>Pertanian</option>
                  <option value="Perternakan" <?php if ($data['bidang_usaha']=="Perternakan") { echo "selected=\"selected\""; } ?>>Perternakan</option>
                </select>
              </td>
            </tr>
            <!-- Alamat Perusahaan -->
            <tr>
              <td colspan="2" style="border:none;"><textarea name="almt_prshn" class="form-control" rows="5" style="resize:none;" placeholder="Alamat Perusahaan" required><?php echo $data['alamat_usaha'];?></textarea></td>
            </tr>
            <!-- Nama Istri/Suami -->
            <tr>
              <td colspan="2" style="border:none;"><input name="nma_issu" type="text" class="form-control" placeholder="Nama Istri/Suami" value="<?php echo $data['nama_istri_suami'];?>">
                <p style="font-size:12px;margin-left:10px;">
                  <strong>Catatan:</strong> Belum menikah kosongkan saja
                </p>
              </td>
            </tr>
          </table>
        </div>
      </div>

      <!-- Tombol Simpan -->
      <div class="col-sm-12">
        <div style="text-align:center;">
          <input class="btn btn-success" type="submit" value="SIMPAN" name="ubah_nasabah" style="margin-top:15px;" readonly></input>
        </div>
        <!-- Untuk Info Jika Simpan Berhasil / Gagal -->
        <?php
          if (isset($_GET['ok'])){
            $error=$_GET['ok'];
          }else{
            $error="";
          }

          $pesan="";
          if ($error=="berhasil"){
                // BERHASIL
                if ($_SESSION['admin']) {
                  $pesan=  "<script>
                              swal('Berhasil!', 'Data Telah Diubah!', 'success')
                              .then((value) => {
                                window.location.href='admin_data_nasabah.php';
                              });
                            </script>";
                } else if ($_SESSION['manager']) {
                  $pesan=  "<script>
                              swal('Berhasil!', 'Data Telah Diubah!', 'success')
                              .then((value) => {
                                window.location.href='manager_data_nasabah.php';
                              });
                            </script>";
                }
          } else if ($error=="gagal") {
                // GAGAL
                if ($_SESSION['admin']) {
                  $pesan=  "<script>
                              swal('Gagal!', 'Data Gagal Diubah Di Database!', 'error')
                              .then((value) => {
                                swal('Info!', 'Coba Periksa Di File proses_nasabah.php / kode halaman ini', 'info')
                                .then((value) => {
                                  window.location.href='admin_ubah_nasabah.php';
                                })
                              });
                            </script>";
                } else if ($_SESSION['manager']) {
                  $pesan=  "<script>
                              swal('Gagal!', 'Data Gagal Diubah Di Database!', 'error')
                              .then((value) => {
                                swal('Info!', 'Coba Periksa Di File proses_nasabah.php / kode halaman ini', 'info')
                                .then((value) => {
                                  window.location.href='manager_ubah_nasabah.php';
                                })
                              });
                            </script>";
                }
          }
          // Tampil Hasil Pesan
          echo "$pesan";
         ?>
      </div>
    </form>
  </div>
</div>
