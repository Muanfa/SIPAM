<h1 class="text-center"><b>Pegawai</b></h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>Daftar Pegawai Baru</b></h2>
  </div>
  <div class="panel-body">
    <!-- HR -->
    <table style="width:100%;">
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), black)"></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td><p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ&nbsp;اللهِ&nbsp;الرَّحْمَنِ&nbsp;الرَّحِيْمِ</p></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, black, rgba(0,0,0,0.75), rgba(0,0,0,0));"></td>
    </table>

    <form action="proses_pegawai.php" method="get">
      <div class="" style="border-radius:15px;background-color: #f2f2f2;}">
        <div class="col-sm-12" >


          <table class="table" border=0>
            <?php
              $hasil = mysqli_query($konek,"select max(id_pegawai) as idMaks from data_pegawai");
              $data  = mysqli_fetch_array($hasil);
              $idMax = $data['idMaks'];
              $noUrut =  substr($idMax, 1, 3);
              $noUrut++;
              $format = "P";
              $newID = $format . sprintf("%03s", $noUrut);
            ?>
            <!-- ID Pegawi -->
            <tr>
                <th style="border:none;"><label class="control-label" style="margin-top:8px;">ID Pegawai:</label></th>
                <td style="border:none;"><input name="id_peg" type="text" class="form-control disabled" value=<?php echo "$newID"; ?> readonly></td>
            </tr>
            <!-- Nama Depan & Nama Belakang -->
            <tr>
              <td style="border:none;"><input name="nama_dpn" type="text" class="form-control" placeholder="Nama Depan" required></td>
              <td style="border:none;"><input name="nama_blkng" type="text" class="form-control" placeholder="Nama Belakang" ></td>
            </tr>
            <!-- Jenis Kelamin -->
            <tr>
                <th style="border:none;">Jenis Kelamin :</td>
                <td style="border:none;">
                  <label class="radio-inline" style="text-align:right;">
                    <input type="radio" name="jk" value="Pria" checked>Pria
                  </label>
                  <label class="radio-inline" >
                    <input type="radio" name="jk" value="Wanita" style="text-align:right;">Wanita
                  </label>
                </td>
            </tr>
            <!-- Identitas Diri -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;" >Identitas Diri :</label></th>
              <td style="border:none;">
                <select name="ident" class="form-control" id="sel1">
                  <option value="KTP" selected>KTP</option>
                  <option value="SIM">SIM</option>
                  <option value="Paspor">Paspor</option>
                  <option value="Lainnya">Lainnya</option>
                </select>
              </td>
            </tr>
            <!-- Tanggal Lahir -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;" >Tanggal Lahir :</label></th>
              <td colspan="2"style="border:none;">
                <div class="form-group" style="width:100%;margin-bottom:2px;">
                  <div class='input-group date' id='datetimepicker2'>
                    <input type='text' name="tgl_lhr" class="form-control"  style="pointer-events: none;"placeholder="Tanggal Lahir" required>
                    <span class="input-group-addon">
                      <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                  </div>
                </div>
              </td>
            </tr>
            <!-- Alamat -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;" >Alamat Tempat Tinggal :</label></th>
              <td colspan="2"style="border:none;"><textarea name="almt" class="form-control" rows="5" style="resize:none;" placeholder="Alamat Tempat Tinggal" required></textarea></td>
            </tr>
            <!-- No Telpon -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;" >No Telphone :</label></th>
              <td colspan="2" style="border:none;"><input name="no_telp" type="number" min="0" maxlength="8" class="form-control" placeholder="Nomer Telepon" required></td>
            </tr>
            <!-- Email -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;" >Email :</label></th>
              <td colspan="2" style="border:none;"><input name="email" type="email" id="email"  class="form-control" placeholder="Email" required></td>
            </tr>
            <!-- Tanggal Daftar -->
            <tr>
              <?php
                // $hari = date('d');
                // $hari = $hari - 1;
                // $no = array(
                //   '1' => '01',
                //   '2' => '02',
                //   '3' => '03',
                //   '4' => '04',
                //   '5' => '05',
                //   '6' => '06',
                //   '7' => '07',
                //   '8' => '08',
                //   '9' => '09'
                // );
                // if ($hari < "10") {
                //     $hari = $no[$hari];
                // }
                // $tgl = date('-m-Y');
                $tgl_sekarang = date('d-m-Y');
              ?>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;">Tanggal Daftar :</label></th>
              <!-- <td style="border:none;"><input name="tgl_dft" value=<?php if (date('d') > $hari) { echo "$hari" . "$tgl";} else {echo "$tgl_sekarang";}?> type="text" class="form-control" readonly></td> -->
              <td style="border:none;"><input name="tgl_dft" value=<?php echo "$tgl_sekarang";?> type="text" class="form-control" readonly></td>
            </tr>
            <!-- Jabatan -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;" >Jabatan :</label></th>
              <td style="border:none;">
                <select name="jbt" class="form-control" id="sel1">
                  <option value="Admin" selected>Admin</option>
                  <option value="Account Officer">Account Officer</option>
                  <option value="Manager">Manager</option>
                </select>
              </td>
            </tr>
            <!-- Username Baru -->
            <tr>
                <th style="border:none;"><label class="control-label" style="margin-top:8px;" >Username Baru :</label></th>
                <td colspan="2" style="border:none;"><input type="text" name="usr" onKeyPress="return angkadanhuruf(event,'abcdefghijklmnopqrstuvwxyz0123456789',this)" class="form-control" placeholder="Username Baru" required></td>
            </tr>
            <!-- Password Baru -->
            <tr>
                <th style="border:none;"><label class="control-label" style="margin-top:8px;" >Password Baru :</label></th>
                <td colspan="2" style="border:none;"><input type="text" name="pwd" onKeyPress="return angkadanhuruf(event,'abcdefghijklmnopqrstuvwxyz0123456789',this)" maxlength="12" minlength="3" class="form-control" placeholder="Password Baru (Max 12 Karakter)" required>
                <p style="font-size:12px;margin-left:10px;">
                  <strong>Catatan:</strong> Password Minimal 3 Karakter
                </p></td>
            </tr>
          </table>
        </div>
        <!-- Tombol Simpan -->
        <div class=""style="text-align:center;">
          <input class="btn btn-success" type="submit" value="SIMPAN" name="tambah_pegawai" readonly></input>
        </div><br>
        <!-- Untuk Info Jika Simpan Berhasil / Gagal -->
        <?php
          if (isset($_GET['ok'])){
            $error=$_GET['ok'];
          }else{
            $error="";
          }

          $pesan="";
          if ($error=="berhasil"){
                if ($_SESSION['admin']) {
                  $pesan=  "<script>
                              swal('Berhasil!', 'Data Telah Tersimpan!', 'success')
                              .then((value) => {
                                window.location.href='admin_data_pegawai.php';
                              });
                            </script>";
                } else if ($_SESSION['manager']) {
                  $pesan=  "<script>
                              swal('Berhasil!', 'Data Telah Tersimpan!', 'success')
                              .then((value) => {
                                window.location.href='manager_data_pegawai.php';
                              });
                            </script>";
                }
          }else if ($error=="gagal") {
                if ($_SESSION['admin']) {
                  $pesan=  "<script>
                              swal('Gagal!', 'Data Gagal Disimpan Di Database!', 'error')
                              .then((value) => {
                                swal('Info!', 'Coba Periksa Di File proses_pegawai.php', 'info')
                                .then((value) => {
                                  window.location.href='admin_tambah_pegawai.php';
                                })
                              });
                            </script>";
                } else if ($_SESSION['manager']) {
                  $pesan=  "<script>
                              swal('Gagal!', 'Data Gagal Disimpan Di Database!', 'error')
                              .then((value) => {
                                swal('Info!', 'Coba Periksa Di File proses_pegawai.php', 'info')
                                .then((value) => {
                                  window.location.href='manager_tambah_pegawai.php';
                                })
                              });
                            </script>";
                }
          }else if ($error == "gagalumur") {
                  if ($_SESSION['admin']) {
                    $pesan=  "<script>
                                swal('Gagal!', 'Data Gagal Disimpan Di Database!', 'error')
                                .then((value) => {
                                  swal('Info!', 'Umur anda tidak cukup', 'info')
                                  .then((value) => {
                                    window.location.href='admin_tambah_pegawai.php';
                                  })
                                });
                              </script>";
                  } else if ($_SESSION['manager']) {
                    $pesan=  "<script>
                                swal('Gagal!', 'Data Gagal Disimpan Di Database!', 'error')
                                .then((value) => {
                                  swal('Info!', 'Umur anda tidak cukup', 'info')
                                  .then((value) => {
                                    window.location.href='manager_tambah_pegawai.php';
                                  })
                                });
                              </script>";
                  }
            }else if ($error == "gagalunpw") {
                    if ($_SESSION['admin']) {
                      $pesan=  "<script>
                                  swal('Gagal!', 'Data Gagal Disimpan Di Database!', 'error')
                                  .then((value) => {
                                    swal('Info!', 'Username / Password sudah di gunakan', 'info')
                                    .then((value) => {
                                      window.location.href='admin_tambah_pegawai.php';
                                    })
                                  });
                                </script>";
                    } else if ($_SESSION['manager']) {
                      $pesan=  "<script>
                                  swal('Gagal!', 'Data Gagal Disimpan Di Database!', 'error')
                                  .then((value) => {
                                    swal('Info!', 'Username / Password sudah digunakan', 'info')
                                    .then((value) => {
                                      window.location.href='manager_tambah_pegawai.php';
                                    })
                                  });
                                </script>";
                    }
              }
          // Tampil Hasil Pesan
          echo "$pesan";
        ?>
      </div>
    </form>
  </div>
</div>
