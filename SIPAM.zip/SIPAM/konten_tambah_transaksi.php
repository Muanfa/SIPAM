<h1 class="text-center"><b>Transaksi Setoran</b></h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>Buat Transaksi Setoran Baru</b></h2>
  </div>
  <div class="panel-body">
    <!-- HR -->
    <table style="width:100%;">
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), black)"></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td><p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ&nbsp;اللهِ&nbsp;الرَّحْمَنِ&nbsp;الرَّحِيْمِ</p></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, black, rgba(0,0,0,0.75), rgba(0,0,0,0));"></td>
    </table>

    <form name='autoSumForm' action="proses_transaksi.php" method="get">

      <!-- Data Nasabah -->
      <div class="col-sm-12" style="border-radius:15px;background-color:#f2f2f2;margin-bottom:5px;">
        <div style="padding:1px 0px 1px 0px;">
          <table class="table" border=0>
            <!-- ID Transaksi -->
            <tr>
              <!-- Membuat ID Baru untuk transaksi -->
              <?php
                $hasil = mysqli_query($konek,"SELECT max(id_transaksi) AS idMaks FROM data_transaksi");
                $data  = mysqli_fetch_array($hasil);
                $idMax = $data['idMaks'];
                $noUrut = substr($idMax, 1, 5);
                $noUrut++;
                $format = "T";
                $newID = $format . sprintf("%05s", $noUrut);
              ?>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;">ID Transaksi :</label></th>
              <td style="border:none;"><input name="id_trnsk" type="text" class="form-control " value=<?php echo "$newID"; ?> readonly></td>
            </tr>

            <?php
              // Fungsi ini menyembunyikan eror
              error_reporting(0);
              // Mengambil nilai id, dari form manager_data_pegawai.php dari tombol UBAH
              $id_pem	= $_GET['id'];
              $query	= mysqli_query($konek, "SELECT * FROM data_pembiayaan WHERE id_pembiayaan='$id_pem'");
              $data2  = mysqli_fetch_array($query);
              $nama = $data2['nama_nasabah'];
             ?>

            <!-- Nama Nasabah -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;">Nama Nasabah :</label></th>
              <td style="border:none;"><input name="nama_nas" type="text" class="form-control" placeholder="Nama Nasabah" readonly value="<?php echo $data2['nama_nasabah']; ?>"></input></td>
            </tr>
            <!-- ==================================================== -->
            <!-- Obyek Pembiayaan -->
            <tr>
              <th style=""><label class="control-label" style="margin-top:8px;">Obyek Pembiayaan :</label></th>
              <td style=""><input name="oby_pmb" type="text" class="form-control" placeholder="Obyek Pembiayaan" readonly value="<?php echo $data2['obyek_pembiayaan']; ?>"></td>
            </tr>
            <!-- Jumlah Pembiayaan -->
            <tr>
              <td style="border:none;"><label style="margin-top:6px;">Jumlah Pembiayaan :</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input style="border-radius:4px;" type="text" class="form-control" placeholder="Jumlah Pembiayaan" readonly value="<?php echo $data2['jumlah_pembiayaan']; ?>">
                </div>
              </td>
            </tr>
            <!-- Margin -->
            <tr>
              <td style="border:none;"><label style="margin-top:6px;">Margin :</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <input style="border-radius:4px;" type="text" class="form-control" placeholder="Margin (%)" readonly value="<?php echo $data2['margin']; ?>">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>%</b></span>
                </div>
              </td>
            </tr>
            <!-- Jangka Waktu -->
            <tr>
              <td style="border:none;"><label style="margin-top:6px;">Jangka Waktu :</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <input style="border-radius:4px;" type="text" class="form-control" placeholder="Jangka Waktu" readonly value="<?php echo $data2['jangka_waktu']; ?>">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Bulan</b></span>
                </div>
              </td>
            </tr>
            <!-- Total Jumlah Margin -->
            <tr>
              <td style="border:none;"><label style="margin-top:6px;">Total Margin :</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input style="border-radius:4px;" type="text" class="form-control" placeholder="Sisa Setoran" readonly value="<?php echo $data2['total_margin']; ?>">
                </div>
              </td>
            </tr>
            <!-- Total Pembiayaan -->
            <tr>
              <td style="border:none;"><label style="margin-top:6px;">Total Pembiayaan :</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input style="border-radius:4px;" name="ttl_pmb" type="text" class="form-control" placeholder="Sisa Setoran" readonly value="<?php echo $data2['total_pembiayaan']; ?>">
                </div>
              </td>
            </tr>
            <!-- Sisa Belum Dibayar x -->
            <tr>
              <td style="border:none;"><label style="margin-top:6px;">Setoran Belum Dibayar :</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input style="border-radius:4px;" type="text" class="form-control" placeholder="Sisa Setoran" readonly value="<?php echo $data2['sisa_setoran']; ?>">
                </div>
              </td>
            </tr>
            <!-- Pendapatan Margin -->
            <tr>
              <td style="border:none;"><label style="margin-top:6px;">Pendapatan Margin :</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input style="border-radius:4px;" name="pnd_mrg" type="text" class="form-control" placeholder="Nominal Setoran" readonly value="<?php echo $data2['pendapatan_margin']; ?>">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>/Angsuran</b></span>
                </div>
                <p style="font-size:12px;margin-bottom:0px;">
                  <b><mark>Perhitungan</mark>:</b> Pendapatan Margin (Per Angsuran) =  Total Margin / Jangka Waktu.
                </p>
              </td>
            </tr>
            <!-- Kas BMT Dikembalikan -->
            <tr>
              <td style="border:none;"><label style="margin-top:6px;">Kas BMT (di kembalikan):</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input style="border-radius:4px;" name="kas_bmt" type="text" class="form-control" placeholder="Nominal Setoran" readonly value="<?php echo $data2['kas_bmt']; ?>">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>/Angsuran</b></span>
                </div>
                <p style="font-size:12px;margin-bottom:0px;">
                  <b><mark>Perhitungan</mark>:</b> Kas BMT (di kembalikan) = Total Pembiayaan / Jangka Waktu.
                </p>
              </td>
            </tr>
            <!-- ============================================= -->
            <!-- Nominal Nyetor -->
            <tr>
              <td><label class="panel panel-default" style="margin-top:6px;margin-bottom:0px;">&nbsp;Nominal Nyetor :&#160;</label></td>
              <td>
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input style="border-radius:4px;" name="no_set" type="text" class="form-control" placeholder="Nominal Setoran" readonly value="<?php echo $data2['jumlah_angsuran']; ?>">
                </div>
                <p style="font-size:12px;margin-bottom:0px;">
                  <b><mark>Perhitungan</mark>:</b> Nominal Setoran = Total Pembiayaan / Jangka Waktu.
                </p>
              </td>
            </tr>
            <!-- Sisa Setoran -->
            <tr>
              <?php
                // Mengurangi Sisa Setoran
                $hasil = $data2['sisa_setoran'] - $data2['jumlah_angsuran'];
                if ($hasil <= "-1") { //Jika Hasil Negatif (Minus) maka nilainya jadi NOL (0)
                  $hasil = "0";
                }
               ?>
              <td style="border:none"><label style="margin-top:6px;margin-bottom:0px;">Sisa Setoran :</label></td>
              <td style="border:none">
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input style="border-radius:4px;" name="sisa_set" type="text" class="form-control" placeholder="Nominal Setoran" readonly value="<?php echo $hasil ?>">
                </div>
                <p style="font-size:12px;margin-bottom:0px;">
                  <b><mark>Perhitungan</mark>:</b> Sisa Setoran = Setoran Belum Dibayar - Nominal Nyetor.
                </p>
              </td>
            </tr>
            <!-- Penyetor -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;">Nama Penyetor :</label></th>
              <td style="border:none;"><input name="nama_pen" type="text" class="form-control" placeholder="Nama Penyetor" required></td>
            </tr>
            <!-- Tanggal Setor -->
            <tr>
              <?php
                // $hari = date('d');
                // // $hari = $hari - 1;
                // $no = array(
                //   '1' => '01',
                //   '2' => '02',
                //   '3' => '03',
                //   '4' => '04',
                //   '5' => '05',
                //   '6' => '06',
                //   '7' => '07',
                //   '8' => '08',
                //   '9' => '09'
                // );
                // if ($hari < "10") {
                //     $hari = $no[$hari];
                // }
                // $tgl = date('-m-Y');
                $tgl = date('d-m-Y');
               ?>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;">Tanggal Setor  :</label></th>
              <!-- <td style="border:none;"><input name="tgl_set" value=<?php if (date('d') > $hari) { echo "$hari" . "$tgl";} else {echo "$tgl_sekarang";}?> type="text" class="form-control" readonly></td> -->
              <td style="border:none;"><input name="tgl_set" value=<?php if (date('d') > $hari) { echo "$tgl";} else {echo "$tgl_sekarang";}?> type="text" class="form-control" readonly></td>
            </tr>

            <!-- ID Pembiayaan -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;">ID Pembiayaan :</label></th>
              <td style="border:none;"><input name="id_pmb" type="text" class="form-control" readonly value="<?php echo $data2['id_pembiayaan']; ?>"></td>
            </tr>
            <!-- ID Nasabah -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;">ID Nasabah :</label></th>
              <td style="border:none;"><input name="id_nsb" type="text" class="form-control" readonly value="<?php echo $data2['id_nasabah']; ?>"></td>
            </tr>
          </table>
        </div>
      </div>


      <!-- Tombol Simpan -->
      <div class="col-sm-12">
        <div style="text-align:center;">
          <input class="btn btn-success" type="submit" value="SIMPAN" name="tambah_transaksi" style="margin-top:15px;" readonly></input>
        </div>
        <!-- Untuk Info Jika Simpan Berhasil / Gagal -->
        <?php
          // Mengmbil id transaksi sebelumnya
          $noUrut = substr($newID, 1, 5);
          $noUrut--;
          $format = "T";
          $newID2 = $format . sprintf("%05s", $noUrut);

          // Mengambil id pembiayaan, dipindahkan ke pesan
          $query2	= mysqli_query($konek, "SELECT * FROM data_transaksi WHERE id_transaksi='$newID2'");
          $data3  = mysqli_fetch_array($query2);
          $id_pembiayaan = $data3['id_pembiayaan'];

          // Menampilkan Pesan Berhasil / Gagal
          if (isset($_GET['ok'])){
            $error = $_GET['ok'];
            $info  = $_GET['info'];

            $pesan="";
            if ($info=="saldo") {
                  // Saldo Tidak Mencukupi
                  if ($_SESSION['accountofficer']) {
                    $pesan  = "<script>
                                swal('Gagal!', 'Data Gagal Disimpan!', 'error')
                                .then((value) => {
                                  swal('Info!', 'Saldo Nasabah dari $nama Tidak Mencukupi', 'info')
                                  .then((value) => {
                                    window.location.href='ao_data_tambah_transaksi.php';
                                  })
                                });
                              </script>";
                  } else if ($_SESSION['manager']) {
                    $pesan  = "<script>
                                swal('Gagal!', 'Data Gagal Diubah Di Database!', 'error')
                                .then((value) => {
                                  swal('Info!', 'Saldo Nasabah dari $nama Tidak Mencukupi', 'info')
                                  .then((value) => {
                                    window.location.href='manager_data_tambah_transaksi.php';
                                  })
                                });
                              </script>";
                  }
            } else if ($info=="lunas"){
                  // LUNAS
                  if ($_SESSION['accountofficer']) {
                    $pesan=  "<script>
                                swal('Berhasil!', 'Data Telah Tersimpan!', 'success')
                                .then((value) => {
                                  window.location.href='ao_data_setoran.php?id=$id_pembiayaan&info=$info';
                                });
                              </script>";
                  } else if ($_SESSION['manager']) {
                    $pesan=  "<script>
                                swal('Berhasil!', 'Data Telah Tersimpan!', 'success')
                                .then((value) => {
                                  window.location.href='manager_data_setoran.php?id=$id_pembiayaan&info=$info';
                                });
                              </script>";
                  }
            } else if ($error=="berhasil"){
                  // BERHASIL
                  if ($_SESSION['accountofficer']) {
                    $pesan=  "<script>
                                swal('Berhasil!', 'Data Telah Tersimpan!', 'success')
                                .then((value) => {
                                  window.location.href='ao_data_setoran.php?id=$id_pembiayaan';
                                });
                              </script>";
                  } else if ($_SESSION['manager']) {
                    $pesan=  "<script>
                                swal('Berhasil!', 'Data Telah Tersimpan!', 'success')
                                .then((value) => {
                                  window.location.href='manager_data_setoran.php?id=$id_pembiayaan';
                                });
                              </script>";
                  }
            } else if ($error=="gagal") {
                  // GAGAL
                  if ($_SESSION['accountofficer']) {
                    $pesan=  "<script>
                                swal('Gagal!', 'Data Gagal Diubah Di Database!', 'error')
                                .then((value) => {
                                  swal('Info!', 'Coba Periksa Di File proses_transaksi.php / kode halaman ini', 'info')
                                  .then((value) => {
                                    window.location.href='ao_data_tambah_transaksi.php';
                                  })
                                });
                              </script>";
                  } else if ($_SESSION['manager']) {
                    $pesan=  "<script>
                                swal('Gagal!', 'Data Gagal Diubah Di Database!', 'error')
                                .then((value) => {
                                  swal('Info!', 'Coba Periksa Di File proses_jaminan.php / kode halaman ini', 'info')
                                  .then((value) => {
                                    window.location.href='manager_data_tambah_transaksi.php';
                                  })
                                });
                              </script>";
                  }
            }
            // Tampil Hasil Pesan
            echo "$pesan";
          }
         ?>
      </div>
    </form>
  </div>
</div>
