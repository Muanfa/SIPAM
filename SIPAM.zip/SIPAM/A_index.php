<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Berkah Madani</title>


    <!-- Ikon Gambar Title -->
    <link rel="icon" href="gambar/logo_BM.png" type="png">
    <!-- CSS Andi -->
    <link href="css/andi.css" rel="stylesheet">


    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/jquery.min.js"></script>

    <link rel="stylesheet" href="DataTables/datatables.min.css">
    <script src="DataTables/datatables.min.js" type="text/javascript"></script>


    <style media="screen">
      @font-face {
        font-family: Supercell-Magic;
        src: url(Supercell.magic.webfont.ttf);
      }
    </style>

  </head>
  <body>


    <!-- ============================= Header ============================== x -->
    <div class="judul-web" >
      <div class="jarak-judul" >
        <h1 style="font-size:32px;">
          <a href="index.php" title="berkahmadani.co.id" class="dideketin2">berkahmadani<span style="color:#884dff;">.co.id</span></a>
        </h1>
      </div>
    </div>


    <!-- ====================== Navigasi (Horizontal) ====================== x -->
    <nav class="navbar-inverse" data-spy="affix" data-offset-top="197" style="background-color:#596275;">
      <div class="container-fluid">
        <div class="navbar-header ">
          <!-- Button Naviagasi Kanan (Saat Layar Chrome dikecil) -->
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar" style="background-color:black;" onmouseover="this.style='background-color:gray;'" onmouseout="this.style='background-color:black;'">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <div class="beranda">
            <a href="index.php" title="Home" class="navbar-brand glyphicon glyphicon-home"  style="color:#1B9CFC;font-size:20px" onmouseover="this.style='text-decoration:none;color:#white;font-size:20px'" onmouseout="this.style='color:#1B9CFC;font-size:20px'"></a>
          </div>
        </div>
       <!-- Tombol NAVIGASI ATAS -->
          <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav">
              <li><a href="index-sejarah.php" class="huruf-nav" title="Sejarah" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><b>Sejarah</b></a></li>
              <li><a href="index-visi-misi.php" class="huruf-nav" title="Visi Misi" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><b>Visi Misi</b></a></li>
              <li><a href="index-murabahah.php" class="huruf-nav" title="Murabahah" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><b>Murabahah</b></a></li>
              <li><a href="index-hubungi-kami.php" class="huruf-nav" title="Hubungi Kami" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><b>Hubungi Kami</b></a></li>
              <!-- <li class="dropdown"><a title="Section 4" class="dropdown-toggle" data-toggle="dropdown" href="#" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><b>Tentang Kami</b> <span class="caret"></span></a>
                <ul class="dropdown-menu" style="text-align:center;">
                    <li><a href="sejarah.php">Sejarah</a></li>
                    <li><a href="visi-misi.php">Visi & Misi</a></li>
                </ul>
              </li> -->
            </ul>
            <!-- TOMBOL LOGIN -->
            <ul class="nav navbar-nav" style="float:right;">
              <li ><a href="login.php" class="huruf-nav" title="Login" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><span class="glyphicon glyphicon-log-in" style="font-size:16px;color:#4bcffa;"></span><b> Login</b></a></li>
            </ul>
          </div>
        </div>
      </div>
    </nav>


    <!-- ===================== Navigasi (Veritakal)  ======================  -->

    <!-- ======================== Konten Web  =============================  -->
      <div class="container-fluid">
        <div class="container-fluid">
          <h1 class="text-center"><b>Home</b> </h1>
          <hr>


          <!-- Isi Konten -->
          <div class="panel panel-default">
                <div class="panel-heading">
                  <h2><b>KSPPS BMT Berkah Madani</b></h2>
                </div>
                <div class="panel-body">
                  <img class="img-responsive img-thumbnail" src="gambar/BMT-Berkah-Madani-1.png" alt="gambar BMT Berkah Madani" width="640" height="250" style="float:left;margin-right:30px;"/>
                  <div class="container-fluid">
                    <p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ اللهِ الرَّحْمَنِ الرَّحِيْمِ <br> <span style="font-size:18px;">(Bismillahirrahmanirrahim)</span></p>
                    <p class="paragraf">
                      <strong>BMT</strong> adalah singkatan dari nama sebutan lembaga keuangan mikro Baitul Maal wat Tamwil
                      atau padanan kata Balai-usaha Mandiri Terpadu.
                    </p>
                    <ol type="1">
                      <li><p class="paragraf" style="margin-bottom:0px;">
                        <strong>Kegiatan Baituttamwil</strong> adalah mengembangkan usaha-usaha produktif dan
                        investasi dalam meningkatkan kualitas kegiatan ekonomi pengusaha kecil dengan antara lain
                        mendorong kegiatan menabung dan menunjang kegiatan ekonominya.
                      </p></li>
                      <li><p class="paragraf">
                        <strong>Kegiatan Baitul Maal</strong> adalah menerima titipan BAZIS dari dana zakat,
                        infaq dan sadaqah dan menjalankannya sesuai dengan peraturan dan amanahnya.
                      </p></li>
                    </ol><br>

                    <strong>APA CIRI-CIRI UTAMA BMT ?</strong>
                    <ol type="1">
                      <li><p class="paragraf" style="margin-bottom:0px;">
                        Berorientasi bisnis dan sosial mencari laba bersama, meningkatkan pemanfaatan ekonomi
                        paling banyak untuk anggota dan lingkungannya.
                      </p></li>
                      <li><p class="paragraf" style="margin-bottom:0px;">
                        Bukan lembaga sosial, tetapi dapat dimanfaatkan untuk mengefektifkan penggunaan zakat,
                        infaq dan sadaqah bagi kesejahteraan dan pemberdayaan orang banyak.
                      </p></li>
                      <li><p class="paragraf" style="margin-bottom:0px;">
                        Ditumbuhkan dari bawah berdasar peran dari masyarakat sekitarnya.
                      </p></li>
                      <li><p class="paragraf" style="margin-bottom:0px;">
                        Milik bersama masyarakat kecil bawah dan kecil dari lingkungan BMT itu sendiri,
                        bukan milik orang seorang atau orang lain diluar masyarakat itu.
                      </p></li>
                    </ol><br>

                    <p class="paragraf-kedalam">
                      Sesungguhnya dalam operasionalnya, antara BMT dan KSPPS ( Koperasi SimpanPinjam dan
                      Pembiayaan Syariah ) tidak terlalu banyak perbedaannya. Sebagai lembaga keuangan,
                      keduanya mempunyai fungsi yang sama dalam penghimpunan dan penyaluran dana. Istilah-istilah
                      yang digunakan juga tidak ada bedanya. Dalam proses penghimpunan dana, keduanya menggunakan
                      istilah simpanan atau tabungan. Begitu pula dalam penyaluran danya, keduanya menggunakan
                      istilah pembiayaan. Sedang syarat pendirian koperasi kedua lembaga tersebut mengharuskan
                      minimal 20 orang. <br>
                      Selain itu, dalam
                    </p>
                    <p class="paragraf-kedalam">
                      Peraturan menteri koperasi dan usaha kecil dan menengah Republik indonesia
                      Nomor 16 /per/m.kukm/ix/2015 Tentang Pelaksanaan kegiatan usaha simpan pinjam dan pembiayaan
                      Syariah oleh koperasi Menteri koperasi dan usaha kecil dan menengah Republik indonesia,
                      Bab I Ketentuan umum Pasal 1 ditegaskan bahwa operasional KSPPS juga memungkinkan untuk
                      melaksankan fungsi ‘Maal’ dan fungsi ‘Tamwil’, sebagaimana yang selama ini dijalankan oleh BMT.
                      Dalam hal ini, KSPPS harus dapat membedakan secara tegas antara fungsi ‘Maal’ dan fungsi ‘Tamwil’.
                    </p>
                    <p class="paragraf-kedalam">
                      Adapun yang sedikit membedakan dalam pelaksanaannya, pada BMT memungkin-kan penyaluran dananya
                      pada pihak luar, yaitu pihak yang belum menjadi anggota BMT. Sedangkan, dalam operasional KSPPS,
                      penyaluran dananya hanya diperuntuk-kan pada pihak yang telah terdaftar menjadi anggota KSPPS.
                      Dalam hal ini, KSPPS hanya diperkenankan memberikan pembiayaan kepada anggota. Hal ini sesuai
                      dengan prinsip dasar koperasi, dari anggota, oleh anggota dan untuk anggota.
                    </p>
                    <p class="paragraf-kedalam">
                      Adanya koperasi syariah (KSPPS) yang telah menjadi salah satu program Kementerian Negara
                      Koperasi dan UKM merupakan solusi bagi pemecahan kebuntuhan legalitas BMT. Sehingga, diharapkan
                      BMT-BMT yang saat ini belum berbadan hukum dapat mengkonversi menjadi koperasi syariah.
                    </p>
                    <p class="paragraf-kedalam">
                      Koperasi syariah mempunyai kesamaan pengertian dalam kegiatan usahanya bergerak di bidang
                      pembiayaan, investasi, dan simpanan sesuai pola bagi hasil (syariah), atau lebih dikenal dengan
                      koperasi jasa keuangan syariah. Sebagai contoh produk jual beli dalam koperasi umum diganti
                      namanya dengan istilah murabahah, produk simpan pinjam dalam koperasi umum diganti namanya
                      dengan mudharabah. Tidak hanya perubahan nama, sistem operasional yang digunakan juga berubah,
                      dari sistem konvesional (biasa) ke sistem syari’ah yang sesuai dengan aturan Islam.
                    </p>

                    <strong>Nilai-nilai Koperasi</strong>
                    <p class="paragraf-kedalam">
                      Pemerintah dan swasta, meliputi individu maupun masyarakat, wajib mentransformasikan nilai-nilai syari’ah dalam nilai-nilai koperasi, dengan mengadopsi 7 nilai syariah dalam bisnis yaitu :
                      <ol type="a">
                        <li>Shiddiq yang mencerminkan kejujuran, akurasi dan akuntabilitas.</li>
                        <li>Istiqamah yang mencerminkan konsistensi, komitmen dan loyalitas.</li>
                        <li>Tabligh yang mencerminkan transparansi, kontrol, edukatif, dan komunikatif</li>
                        <li>Amanah yang mencerminkan kepercayaan, integritas, reputasi, dan kredibelitas.</li>
                        <li>Fathanah yang mencerminkan etos profesional, kompeten, kreatif, inovatif.</li>
                        <li>Ri’ayah yang mencerminkan semangat solidaritas, empati, kepedulian, awareness.</li>
                        <li>Mas’uliyah yang mencerminkan responsibilitas.</li>
                      </ol>
                    </p>

                    <strong>Tujuan Koperasi Syariah</strong>
                    <p class="paragraf-kedalam">
                      Meningkatkan kesejahteraan anggota pada khususnya dan masyarakat pada umumnya serta turut
                      membangun tatanan perekonomian yang berkeadilan sesuai dengan prinsip-prinsip Islam.
                    </p>

                    <strong>Fungsi dan Peran Koperasi Syariah yaitu:</strong>
                    <p>
                      <ol type="1">
                        <li><p class="paragraf" style="margin-bottom:0px;">
                          Membangun dan mengembangkan potensi dan kemampuan anggota pada khususnya, dan masyarakat
                          pada umumnya, guna meningkatkan kesejahteraan sosial ekonominya.
                        
                        </p>
                        </li>
                        <li><p class="paragraf" style="margin-bottom:0px;">
                          Memperkuat kualitas sumber daya insani anggota, agar menjadi lebih amanah, professional
                          (fathonah), konsisten, dan konsekuen (istiqomah) di dalam menerapkan prinsip-prinsip
                          ekonomi islam dan prinsip-prinsip syariah islam.
                        </p></li>
                        <li><p class="paragraf" style="margin-bottom:0px;">
                          Berusaha untuk mewujudkan dan mengembangkan perekonomian nasional yang merupakan usaha
                          bersama berdasarkan azas kekeluargaan dan demokrasi ekonomi.
                        </p></li>
                        <li><p class="paragraf" style="margin-bottom:0px;">
                          Sebagai mediator antara menyandang dana dengan penggunan dana, sehingga tercapai
                          optimalisasi pemanfaatan harta.
                        </p></li>
                        <li><p class="paragraf" style="margin-bottom:0px;">
                          Menguatkan kelompok-kelompok anggota, sehingga mampu bekerjasama melakukan
                          kontrol terhadap koperasi secara efektif
                        </p></li>
                        <li>Mengembangkan dan memperluas kesempatan kerja</li>
                        <li>Menumbuhkan-kembangkan usaha-usaha produktif anggota</li>
                      </ol>
                      <i>by : supri</i>
                    </p>
                    <blockquote>
                      <footer>From <a href="https://berkahmadani.co.id" target="_blank">BMT Berkah Madani</a> website</footer>
                    </blockquote>
                  </div>
                </div>
              </div>


        </div>
      </div>
    <!--- ========================= Footer ================================= -->
    <footer>
      <div class="col-sm-12 sosmed" style="width:100%;">
        <!-- Ikon Sosmed -->
        <div class="posisi-sosmed">
          <ul class="list-inline">
            <li><a data-toggle="tooltip" title="Facebook" href="#" target="_blank"><img class="ukuran-ikon-sosmed" src="gambar/footer/Icon-facebook.png"></a></li>
            <li><a data-toggle="tooltip" title="Instagram" href="#" target="_blank"><img class="ukuran-ikon-sosmed" src="gambar/footer/Icon-instagram.png"></a></li>
            <li><a data-toggle="tooltip" title="Youtube" href="#" target="_blank"><img class="ukuran-ikon-sosmed" src="gambar/footer/Icon-Youtube.png"></a></li>
            <li><a data-toggle="tooltip" title="Twiter" href="#" target="_blank"><img class="ukuran-ikon-sosmed" src="gambar/footer/Icon-Twitter.png"></a></li>
            <li><a data-toggle="tooltip" title="Line" href="#" target="_blank"><img class="ukuran-ikon-sosmed" src="gambar/footer/Icon-Line.png"></a></li>
          </ul>
        </div >
        <!-- Kata-kata CopyRight -->
        <div class="posisi-copyright">
          <strong class="warna-teks-fot">Copyright &copy; 2018 <a class href="" style="color:#33d9b2;">AdminAndi.io</a> All rights reserved.</strong><br><br>
        </div>
      </div>
    </footer>

    <!-- Untuk Scroll Ke Atas -->
    <div id="tombolScrollTop" onclick="scrolltotop()" href="#"><span class="glyphicon glyphicon-circle-arrow-up" style="font-size:40px;"></span></div>

    <!-- Untuk Scroll Ke Atas -->
    <script type="text/javascript">
      $(document).ready(function(){
        $(window).scroll(function(){
          if ($(window).scrollTop() > 100) {
            $('#tombolScrollTop').fadeIn();
          } else {
            $('#tombolScrollTop').fadeOut();
          }
        });
      });

      function scrolltotop(){
        $('html, body').animate({scrollTop : 0},500);
      }
    </script>

    <!-- Untuk DataTables -->
    <script type="text/javascript">
        $(document).ready(function() {
          $('#asexample').DataTable();
        } );
    </script>

    <!-- Untuk Notif Sosmed -->
    <script>
      $(document).ready(function(){
          $('[data-toggle="tooltip"]').tooltip();
      });
    </script>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!-- <script src="js/jquery.min.js"></script> -->
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
