<!-- Isi Konten -->
<h1 class="text-center"><b>Penjelasan</b></h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>Alur Akad Pembiayaan Murabah</b></h2>
  </div>
  <div class="panel-body">
    <!-- HR -->
    <table style="width:100%;">
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), black)"></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td><p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ&nbsp;اللهِ&nbsp;الرَّحْمَنِ&nbsp;الرَّحِيْمِ</p></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, black, rgba(0,0,0,0.75), rgba(0,0,0,0));"></td>
    </table><br>

    <h3 class="text-center"><b>Cara Melakukan Akad Pembiayaan Murabahah :</b></h3><br><br>
    <blockquote style="font-size:17px;">
      <ol type="1">
        <li><p class="paragraf" style="margin-bottom:0px;">
          Nasabah harus mendaftar sebagai nasabah di BMT Berkah Madani, bertemu dengan Admin.
        </p></li>
        <li><p class="paragraf" style="margin-bottom:0px;">
          Nasabah ingin melakukan akad pembiayaan murabahah, bertemu dengan Account Officer dan menyiapkan surat-surat yaitu seperti dibawah ini, Fotocopy:
          <ul>
            <li><p class="paragraf" style="margin-bottom:0px;">
              KTP / SIM / Paspor / Surat Identitas Lainnya.
            </p></li>
            <li><p class="paragraf" style="margin-bottom:0px;">
              Surat Obyek Pembiayaan (Contoh: Surat Membeli Mobil)
            </p></li>
            <li><p class="paragraf" style="margin-bottom:0px;">
              Dokumen Jaminan.
            </p></li>
          </ul>
        </p></li>
        <li><p class="paragraf" style="margin-bottom:0px;">
          Nasabah sudah melakukan akad pembiayaan murabahah, akan mendapatakan surat setelah terjadinya akad.
        </p></li>
        <li><p class="paragraf" style="margin-bottom:0px;">
          Nasabah diwajibkan mengembalikkan uang yang telah dipembiayaan oleh BMT Berkah Madani, sesuai dengan nilai setoran perbulan & jangka waktu pengembalian uang, yang telah disepakati oleh BMT Berkah Madani.
        </p></li>
        <li><p class="paragraf" style="margin-bottom:0px;">
          Nasabah boleh melakukan pembiayaan akad murabahah lagi, jika nasabah sudah menyelesaikan mengembalikkan uang yang sudah terjadi akad pembiayaan murabahah sebelumnya.
        </p></li>
      </ol>
      <footer>From <a href="https://berkahmadani.co.id" target="_blank">BMT Berkah Madani</a> website</footer>
    </blockquote>



  </div>
</div>
