<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Login - Berkah Madani</title>


    <!-- Ikon Gambar Title -->
    <link rel="icon" href="gambar/logo_BM.png" type="png">
    <!-- CSS Andi -->
    <link href="css/andi.css" rel="stylesheet">


    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/jquery.min.js"></script>

    <!-- Include javascript sweetalert -->
    <script type="text/javascript" src="js/sweetalert.min.js"></script>

  </head>
  <body style="background-color:rgb(240, 240, 320)">
    <!-- Tombol Keluar -->
    <div class="tombolkeluar" style="text-align:right;height: 50px;margin-top:10px;">
      <a href="index.php" class="warna-kembali" style="margin-right:10px;" data-placement="left" title="Home"><span class="glyphicon glyphicon-share-alt" style="font-size:40px;"></span></a>
    </div>

    <div class="container">
      <div class="col-sm-3 col-md-4 col-lg-4">
      </div>
      <div class="col-sm-6 col-md-5 col-lg-4">
        <!-- <div style="margin-top:50%;margin-bottom:50%;"> -->
        <div class="text-center" style="margin-top:15%;color:#6c5ce7;">
          <h2>KSPPS BMT Berkah Madani</h2>
        </div>
          <div class="panel panel-default">
            <div class="panel-heading" style="font-size:25px;text-align:center;font-family:'courier';">
              <b>Login</b>
            </div>
            <div class="panel-body" style="margin-bottom:-13px;">
                <div class="text-center">
                  <p style=" margin-bottom:-10px"><strong>Masuk untuk memulai sesi Anda</strong></p>
                  <br>
                  <!-- Untuk form input user -->
                  <form action="proses_login.php" method="get">
                    <div class="input-group form-group">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                      <input name="username" id="email" type="text" class="form-control"  placeholder="Username" required>
                    </div>
                    <div class="input-group form-group">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                      <input name="password" id="password" type="password" class="form-control form-password"  placeholder="Password" required>
                    </div>
                    <div class="checkbox">
                      <label><input type="checkbox" class="form-checkbox">Tampilkan Password</label>
                    </div>
                    <div class="">
                      <button name="login" type="submit" class="btn btn-block" style="background-color:#3399ff;color:white;" onmouseover="this.style='background-color:#0080ff;color:white;'" onmouseout="this.style='background-color:#3399ff;color:white;'">Login</button>
                    </div>
                  </form><hr>


                  <!-- Pengecekan Gagal Login -->
                  <?php
                    // Fungsi ini menyembunyikan eror
                    error_reporting(0);

                    if (isset($_GET['ok'])){
                      $error = $_GET['ok'];

                      if ($error=="gagal"){
                        $pesan = "<script>
                                    swal('Gagal!', 'Anda Gagal Login!', 'error')
                                    .then((value) => {
                                      swal('Info!', 'Username dan Password anda masukkan salah / tidak ada', 'info')
                                      .then((value) => {
                                        window.location.href='login.php';
                                      })
                                    });
                                  </script>";
                      }else if ($error=="loncat") {
                        $pesan = "<script>
                                    swal('Gagal!', 'Anda Harus Login Terlebih Dahulu!', 'error')
                                    .then((value) => {
                                        window.location.href='login.php';
                                    });
                                  </script>";
                      }
                    }
                    // Tampil Hasil Pesan
                    echo "$pesan";
                   ?>
                  <strong class="warna-teks-fot">Copyright &copy; 2018 <a class href="" style="color:#33d9b2;">AdminAndi.io</a> All rights reserved.</strong><br><br>
                </div>
            </div>
          </div>


        </div>
      </div>
      <div class="col-sm-3 col-md-3 col-lg-4">
      </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function() {
        var cek = $('.form-checkbox').val();
        $('.form-checkbox').click(function() {
          if ($(this).is(':checked')) {
            $('.form-password').attr('type', 'text');
          } else {
            $('.form-password').attr('type', 'password');
          }
        });
      });
    </script>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!-- <script src="js/jquery.min.js"></script> -->
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <!-- <script src="js/bootstrap.min.js"></script> -->
  </body>

</html>
