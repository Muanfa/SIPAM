<?php
require "koneksi/koneksi.php";

session_start();

if ($_SESSION['admin']) {
  $id_pegawai_s = $_SESSION['admin'];
} else if ($_SESSION['manager']) {
  $id_pegawai_s = $_SESSION['manager'];
}


// Membuat id_monitoring baru
$hasil = mysqli_query($konek,"select max(id_monitoring) as idMaks from data_monitoring");
$data  = mysqli_fetch_array($hasil);
$idMax = $data['idMaks'];
$noUrut =  substr($idMax, 1, 5);
$noUrut++;
$format = "M";
$newID = $format . sprintf("%05s", $noUrut);

// validasi umur
$tanggal_lahir    = $_GET['tgl_lhr'];
$tanggal_dipilih  = substr($tanggal_lahir, 6, 4);
$tanggal_sekarang = date('Y');
$selisih = $tanggal_sekarang - $tanggal_dipilih;

// validasi username / password sudah dipakai
$query     = mysqli_query($konek,"SELECT * FROM data_pegawai");
$data      = mysqli_fetch_array($query);
$dpt_uname = $data['username'];
$username  = $_GET['usr'];

// Jika di Tekan tombol simpan (Tambah Pegawai) eksekusi code ini
if(isset($_GET['tambah_pegawai']))
{
  if ($selisih < 18) { // validasi umur
    if ($_SESSION['admin']) {
      header('location:admin_tambah_pegawai.php?ok=gagalumur');
    } else if ($_SESSION['manager']) {
      header('location:manager_tambah_pegawai.php?ok=gagalumur');
    }
  }else if($username == $dpt_uname){
    if ($_SESSION['admin']) {
      header('location:admin_tambah_pegawai.php?ok=gagalunpw');
    } else if ($_SESSION['manager']) {
      header('location:manager_tambah_pegawai.php?ok=gagalunpw');
    }
  }else {
    // Mengambil nilai dari form manager_tambah_pegawai.php
    $id_pegawai			= $_GET['id_peg'];
    $nama_depan 		= $_GET['nama_dpn'];
    $nama_belakang  = $_GET['nama_blkng'];
    $jenis_kelamin	= $_GET['jk'];
    $identitas_diri = $_GET['ident'];
    $tgl_lahir			= $_GET['tgl_lhr'];
    $alamat					= $_GET['almt'];
    $no_telepon  		= $_GET['no_telp'];
    $email  	    	= $_GET['email'];
    $tgl_daftar  		= $_GET['tgl_dft'];
    $jabatan    		= $_GET['jbt'];
    $username				= $_GET['usr'];
    $password				= md5($_GET['pwd']);
    $deskripsi			= $_GET['pwd'];
    // Menyimpan ke database sipam, dari tabel data_pegawai
    $query = mysqli_query($konek, "INSERT INTO data_pegawai VALUES(
      '$id_pegawai',
      '$nama_depan',
      '$nama_belakang',
      '$jenis_kelamin',
      '$identitas_diri',
      '$tgl_lahir',
      '$alamat',
      '$no_telepon',
      '$email',
      '$tgl_daftar',
      '$jabatan',
      '$username',
      '$password',
      '$deskripsi')"
    );

    if ($query) {
      // Mengambil nilai nama pegawai dari data_pegawai, nanti di pindahakan nilai nama pegawai ke data_monitoring
      $query2    = mysqli_query($konek,"SELECT * FROM data_pegawai WHERE id_pegawai = '$id_pegawai_s'");
      $data      = mysqli_fetch_array($query2);
      $dpt_nama  = $data['nama_depan'] . " " . $data['nama_belakang'];
      $jabatan   = $data['jabatan'];

      // Menyimpan ke database sipam, dari tabel data_monitoring
      $query3 = mysqli_query($konek, "INSERT INTO data_monitoring VALUES(
        '$newID',
        '$jabatan',
        '$dpt_nama',
        'Daftar Pegawai Baru',
        Now(),
        '$id_pegawai_s')"
      );

      // BERHASIL
      if ($_SESSION['admin']) {
        header('location:admin_tambah_pegawai.php?ok=berhasil');
      } else if ($_SESSION['manager']) {
        header('location:manager_tambah_pegawai.php?ok=berhasil');
      }
    }else {
      // GAGAL
      if ($_SESSION['admin']) {
        header('location:admin_tambah_pegawai.php?ok=gagal');
      } else if ($_SESSION['manager']) {
        header('location:manager_tambah_pegawai.php?ok=gagal');
      }
    }
  }
}



// Jika di Tekan tombol ubah (Ubah Pegawai) eksekusi code ini
if(isset($_GET['ubah_pegawai']))
{
  // Mengambil nilai dari form manager_ubah_pegawai.php
  $id_pegawai			= $_GET['id_peg'];
  $nama_depan 		= $_GET['nama_dpn'];
  $nama_belakang  = $_GET['nama_blkng'];
  $jenis_kelamin	= $_GET['jk'];
  $identitas_diri = $_GET['ident'];
  $tgl_lahir			= $_GET['tgl_lhr'];
  $alamat					= $_GET['almt'];
  $no_telepon  		= $_GET['no_telp'];
  $email  	    	= $_GET['email'];
  $tgl_daftar  		= $_GET['tgl_dft'];
  $jabatan    		= $_GET['jbt'];
  $username				= $_GET['usr'];
  $password				= md5($_GET['pwd']);
  $deskripsi			= $_GET['pwd'];
  // Memperbarui ke database sipam, dari tabel data_pegawai
  $query = mysqli_query($konek, "UPDATE data_pegawai SET
           id_pegawai       ='$id_pegawai',
           nama_depan       ='$nama_depan',
           nama_belakang    ='$nama_belakang',
           jenis_kelamin    ='$jenis_kelamin',
           identitas_diri   ='$identitas_diri',
           tanggal_lahir    ='$tgl_lahir',
           alamat           ='$alamat',
           nomer_telepon    ='$no_telepon',
           email            ='$email',
           tanggal_daftar   ='$tgl_daftar',
           jabatan          ='$jabatan',
           username         ='$username',
           password         ='$password',
           deskripsi        ='$deskripsi' WHERE id_pegawai='$id_pegawai'"
  );
  if ($query) {
    // Mengambil nilai nama pegawai dari data_pegawai, nanti di pindahakan nilai nama pegawai ke data_monitoring
    $query2    = mysqli_query($konek,"SELECT * FROM data_pegawai WHERE id_pegawai = '$id_pegawai_s'");
    $data      = mysqli_fetch_array($query2);
    $dpt_nama  = $data['nama_depan'] . " " . $data['nama_belakang'];
    $jabatan   = $data['jabatan'];

    // Menyimpan ke database sipam, dari tabel data_monitoring
    $query3 = mysqli_query($konek, "INSERT INTO data_monitoring VALUES(
      '$newID',
      '$jabatan',
      '$dpt_nama',
      'Mengubah Data Pegawai',
      Now(),
      '$id_pegawai_s')"
    );

    // BERHASIl
    if ($_SESSION['admin']) {
      header('location:admin_ubah_pegawai.php?ok=berhasil');
    } else if ($_SESSION['manager']) {
      header('location:manager_ubah_pegawai.php?ok=berhasil');
    }
  }else {
    // GAGAL
    if ($_SESSION['admin']) {
      header('location:admin_ubah_pegawai.php?ok=gagal');
    } else if ($_SESSION['manager']) {
      header('location:manager_ubah_pegawai.php?ok=gagal');
    }
  }
}


// Jika di Tekan tombol id (Ubah Pegawai) eksekusi code ini
if(isset($_GET['id']))
{
  // Mengambil nilai dari form manager_data_pegawai.php
  $id_pegawai = $_GET['id'];
  // Memperbarui ke database sipam, dari tabel data_pegawai
  $query = mysqli_query($konek, "DELETE FROM data_monitoring WHERE id_pegawai='$id_pegawai'");
  $query = mysqli_query($konek, "DELETE FROM data_pegawai WHERE id_pegawai='$id_pegawai'");

  if ($query) {
    // Mengambil nilai nama pegawai dari data_pegawai, nanti di pindahakan nilai nama pegawai ke data_monitoring
    $query2    = mysqli_query($konek,"SELECT * FROM data_pegawai WHERE id_pegawai = '$id_pegawai_s'");
    $data      = mysqli_fetch_array($query2);
    $dpt_nama  = $data['nama_depan'] . " " . $data['nama_belakang'];
    $jabatan   = $data['jabatan'];

    // Menyimpan ke database sipam, dari tabel data_monitoring
    $query3 = mysqli_query($konek, "INSERT INTO data_monitoring VALUES(
      '$newID',
      '$jabatan',
      '$dpt_nama',
      'Menghapus Data Pegawai',
      Now(),
      '$id_pegawai_s')"
    );

    // BERHASIL
    if ($_SESSION['admin']) {
      header('location:admin_data_pegawai.php?ok=berhasil');
    } else if ($_SESSION['manager']) {
      header('location:manager_data_pegawai.php?ok=berhasil');
    }
  }else {
    // GAGAL
    if ($_SESSION['admin']) {
      header('location:admin_data_pegawai.php?ok=gagal');
    } else if ($_SESSION['manager']) {
      header('location:manager_data_pegawai.php?ok=gagal');
    }
  }
}
?>
