<?php
  require "koneksi/koneksi.php";

  session_start();

  // pengecekan session untuk mendapatakan id pegawai, untuk JABATAN & DAPAT NAMA
  if ($_SESSION['admin']) {
    $id_pegawai = $_SESSION['admin'];
  } else if ($_SESSION['accountofficer']) {
    $id_pegawai = $_SESSION['accountofficer'];
  } else if ($_SESSION['manager']) {
    $id_pegawai = $_SESSION['manager'];
  }

  // Membuat id monitoring baru
  $hasil = mysqli_query($konek,"select max(id_monitoring) as idMaks from data_monitoring");
  $data  = mysqli_fetch_array($hasil);
  $idMax = $data['idMaks'];
  $noUrut =  substr($idMax, 1, 5);
  $noUrut++;
  $format = "M";
  $newID = $format . sprintf("%05s", $noUrut);

  // Mengmabil data_pegawai
  $query = mysqli_query($konek, "SELECT * FROM data_pegawai WHERE id_pegawai = '$id_pegawai'");
  $data  = mysqli_fetch_array($query);
  $dpt_nama  = $data['nama_depan'] . " " . $data['nama_belakang'];
  $jabatan   = $data['jabatan'];

  // Menyimpan ke data_monitoring
  $query = mysqli_query($konek, "INSERT INTO data_monitoring VALUES(
    '$newID',
    '$jabatan',
    '$dpt_nama',
    'Pegawai Telah Logout',
    Now(),
    '$id_pegawai')"
  );

  session_destroy();
  header("Location: login.php");
 ?>
