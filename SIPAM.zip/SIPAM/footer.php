<footer>
  <div class="col-sm-12 sosmed" style="width:100%;">
    <!-- Ikon Sosmed -->
    <div class="posisi-sosmed">
      <ul class="list-inline">
        <li><a data-toggle="tooltip" title="Facebook" href="#" target="_blank"><img class="ukuran-ikon-sosmed" src="gambar/footer/Icon-facebook.png"></a></li>
        <li><a data-toggle="tooltip" title="Instagram" href="#" target="_blank"><img class="ukuran-ikon-sosmed" src="gambar/footer/Icon-instagram.png"></a></li>
        <li><a data-toggle="tooltip" title="Youtube" href="#" target="_blank"><img class="ukuran-ikon-sosmed" src="gambar/footer/Icon-Youtube.png"></a></li>
        <li><a data-toggle="tooltip" title="Twiter" href="#" target="_blank"><img class="ukuran-ikon-sosmed" src="gambar/footer/Icon-Twitter.png"></a></li>
        <li><a data-toggle="tooltip" title="Line" href="#" target="_blank"><img class="ukuran-ikon-sosmed" src="gambar/footer/Icon-Line.png"></a></li>
      </ul>
    </div >
    <!-- Kata-kata CopyRight -->
    <div class="posisi-copyright">
      <strong class="warna-teks-fot">Copyright &copy; 2018 <a class href="" style="color:#33d9b2;">AdminAndi.io</a> All rights reserved.</strong><br><br>
    </div>
  </div>
</footer>
