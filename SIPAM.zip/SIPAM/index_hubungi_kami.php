<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Hubungi Kami - Berkah Madani</title>


    <!-- Ikon Gambar Title -->
    <link rel="icon" href="gambar/logo_BM.png" type="png">
    <!-- CSS Andi -->
    <link href="css/andi.css" rel="stylesheet">


    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/jquery.min.js"></script>
    <!-- Untuk DataTables -->
    <link rel="stylesheet" href="DataTables/datatables.min.css">
    <script src="DataTables/datatables.min.js" type="text/javascript"></script>

    <!-- Untuk Font Supercell -->
    <style media="screen">
      @font-face {
        font-family: Supercell-Magic;
        src: url(Supercell.magic.webfont.ttf);
      }
    </style>

  </head>
  <body>


    <!-- ============================= Header ============================== x -->
    <?php
      include "index_header.php";
    ?>


    <!-- ====================== Navigasi (Horizontal) ====================== x -->
    <nav class="navbar-inverse" data-spy="affix" data-offset-top="197" style="background-color:#596275;">
      <div class="container-fluid">
        <div class="navbar-header ">
          <!-- Button Naviagasi Kanan (Saat Layar Chrome dikecil) -->
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar" style="background-color:black;" onmouseover="this.style='background-color:gray;'" onmouseout="this.style='background-color:black;'">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <div class="beranda">
            <a href="index.php" title="Home" class="navbar-brand glyphicon glyphicon-home"  style="color:white;font-size:20px" onmouseover="this.style='text-decoration:none;color:#303952;font-size:20px'" onmouseout="this.style='color:white;font-size:20px'"></a>
          </div>
        </div>
        <!-- Tombol NAVIGASI ATAS -->
        <div class="collapse navbar-collapse" id="myNavbar">
          <ul class="nav navbar-nav">
            <li><a href="index_sejarah.php" class="huruf-nav" title="Sejarah" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><b>Sejarah</b></a></li>
            <li><a href="index_visi_misi.php" class="huruf-nav" title="Visi Misi" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><b>Visi Misi</b></a></li>
            <li><a href="index_murabahah.php" class="huruf-nav" title="Murabahah" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><b>Murabahah</b></a></li>
            <li><a href="index_hubungi_kami.php" class="huruf-nav" title="Hubungi Kami" style="background-color:#1B9CFC;color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='background-color:#1B9CFC;color:white;'"><b>Hubungi Kami</b></a></li>
          </ul>
          <!-- TOMBOL LOGIN -->
          <ul class="nav navbar-nav" style="float:right;">
            <li ><a href="login.php" class="huruf-nav" title="Login" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><span class="glyphicon glyphicon-log-in" style="font-size:16px;color:#4bcffa;"></span><b> Login</b></a></li>
          </ul>
        </div>
      </div>
    </nav>


    <!-- ===================== Navigasi (Veritakal)  ======================  -->

    <!-- ======================== Konten Web  =============================  -->
    <div class="container-fluid">
      <div class="container-fluid">


        <!-- Isi Konten -->
        <?php
          include "konten_hubungi_kami.php";
        ?>


      </div>
    </div>
    <!--- ========================= Footer ================================= -->
    <?php
      include "footer.php";
    ?>

    <!-- Untuk Scroll Ke Atas -->
    <div id="tombolScrollTop" onclick="scrolltotop()" href="#"><span class="glyphicon glyphicon-circle-arrow-up" style="font-size:40px;"></span></div>
    <!-- JS Andi -->
    <script type="text/javascript" src="js/andi.js"></script>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!-- <script src="js/jquery.min.js"></script> -->
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <!-- JS sweetalert -->
    <script type="text/javascript" src="js/sweetalert.min.js"></script>
  </body>
</html>
