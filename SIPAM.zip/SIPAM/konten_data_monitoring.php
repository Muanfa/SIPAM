<h1 class="text-center"><b>Monitoring</b></h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>Data Monitoring</b></h2>
  </div>
  <div class="panel-body">
    <!-- HR -->
    <table style="width:100%;">
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), black)"></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td><p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ&nbsp;اللهِ&nbsp;الرَّحْمَنِ&nbsp;الرَّحِيْمِ</p></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, black, rgba(0,0,0,0.75), rgba(0,0,0,0));"></td>
    </table>

    <div class="container-fluid panel panel-default" style="padding-top:10px;padding-bottom:10px;">
      <table id="asexample" class="table responsive table-striped table-bordered table-hover" style="width:100%">
        <thead>
          <tr>
              <th>No</th>
              <th>Aksi</th>
              <th>ID Monitoring</th>
              <th>User</th>
              <th>Nama Pegawai</th>
              <th>Keterangan</th>
              <th>Tanggal</th>
          </tr>
        </thead>
        <tbody>


          <?php
            $query = mysqli_query($konek, "SELECT * FROM data_monitoring ORDER BY id_monitoring");
            $no =1;
            while($rows = mysqli_fetch_array($query)){
          ?>

          <tr style="text-align:center;">
            <td><?php echo $no++;?></td>
            <td style="width:50px;">
              <button type='button' onclick="window.open('cetak_monitoring.php?id=<?php echo $rows['id_monitoring'];?>','nama_window_pop_up','size=800,height=800,scrollbars=yes,resizeable=no')" class='btn btn-info btn-sm'>Cetak</button>
            </td>
            <td><?php echo $rows['id_monitoring'];         ?></td>
            <td><?php echo $rows['user']                   ?></td>
            <td><?php echo $rows['nama_pegawai'];          ?></td>
            <td><?php echo $rows['keterangan'];            ?></td>
            <td><?php echo $rows['tanggal'];               ?></td>
          </tr>

          <?php
            }
          ?>
        </tbody>
      </table>


      <!-- Untuk Info Jika Simpan Berhasil atau Gagal-->
      <?php
        if (isset($_GET['ok'])){
          $error=$_GET['ok'];
        }else{
          $error="";
        }

        $pesan="";
        if ($error=="berhasil"){
        $pesan=  "<script>
                    swal('Berhasil!', 'Data Telah Dihapus!', 'success')
                    .then((value) => {
                      window.location.href='manager_data_pegawai.php';
                    });
                  </script>";
        }else if ($error=="gagal") {
          $pesan=  "<script>
                      swal('Gagal!', 'Data Gagal Dihapus Di Database!', 'error')
                      .then((value) => {
                        swal('Info!', 'Coba Periksa Di File proses_pegawai.php', 'info')
                        .then((value) => {
                          window.location.href='manager_data_pegawai.php';
                        })
                      });
                    </script>";
        }
      ?>
      <?php
        echo "$pesan";
      ?>
    </div>

  </div>
</div>
