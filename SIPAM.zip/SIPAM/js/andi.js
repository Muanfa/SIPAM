// <!-- Untuk Scroll Ke Atas -->
$(document).ready(function(){
  $(window).scroll(function(){
    if ($(window).scrollTop() > 100) {
      $('#tombolScrollTop').fadeIn();
    } else {
      $('#tombolScrollTop').fadeOut();
    }
  });
});
function scrolltotop(){
  $('html, body').animate({scrollTop : 0},500);
}


// <!-- Untuk Datatables -->
$(document).ready(function() {
  $('#asexample').DataTable();
} );


// <!-- Untuk Notif Sosmed -->
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();
});


// <!-- Untuk Menampilkan Password -->
$(document).ready(function() {
  var cek = $('.form-checkbox').val();
  $('.form-checkbox').click(function() {
    if ($(this).is(':checked')) {
      $('.form-password').attr('type', 'text');
    } else {
      $('.form-password').attr('type', 'password');
    }
  });
});
