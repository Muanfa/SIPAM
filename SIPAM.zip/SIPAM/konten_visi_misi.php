<h1 class="text-center"><b>Visi dan Misi</b> </h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>KSPPS BMT Berkah Madani</b></h2>
  </div>
  <div class="panel-body">
    <h3 class="text-center"><b>VISI</b></h3>
    <blockquote style="font-size:17px;">
      <p class="paragraf-kedalam">
        Pada tahun 2005 kebutuhan akan lembaga keuangan akan akses permodalan pembiayaan
        sesuai dengan kebutuhan bagi kalangan usaha mikro Begitu sulit bagi usaha mikro
        untuk melakukan transaksi di perbankan baik pembiayaan maupun pinjaman. Banyak
        sekali persyaratan yang harus dipenuhi sehingga usaha mikro pada saat itu tidak
        dapat berjalan dengan baik.menengah masih sangtlah sulit, dikarenakan untuk melakukan
        pinjaman di bank sendiri memiliki prosedur yang lebih sulit dan minimal pinjaman yang
        ditentukan diluar kemampuan para nasabah. bagi para anggota atau nasabah perbankan
        hanya memberikan pinjaman kepada para pemodal besar.
      </p>
    </blockquote>

    <h3 class="text-center"><b>Misi</b></h3>
    <blockquote style="font-size:17px;">
      <ol type="1">
        <li><p class="paragraf" style="margin-bottom:0px;">
          Meningkatkan akses permodalan bagi masyarakat kecil baik finansial maupun non-finansial.
        </p></li>
        <li><p class="paragraf" style="margin-bottom:0px;">
          Membantu menciptakan lapangan kerja dan meningkatkan produktivitas masyarakat kecil demi
          kesejahteraan dan keadilan ekonomi.
        </p></li>
        <li><p class="paragraf" style="margin-bottom:0px;">
          Menjadi lembaga keuangan syariah yang tumbuh secara berkelanjutan seiring dengan pertumbuhan
          usaha nasabahnya.
        </p></li>
        <li><p class="paragraf" style="margin-bottom:0px;">
          Memberikan keuntungan maksimal secara terus menerus kepada shareholder melalui pelayanan
          terbaik kepada stakeholder
        </p></li>
        <li><p class="paragraf" style="margin-bottom:0px;">
          Menjadi organisasi pembelajar yang secara kontinyu meningkatkan kompetensi dan kapasitas
        </p></li>
      </ol>
      <p class="paragraf">Sumber Daya Insani yang beriman & bertaqwa dengan kesejahteraan yang maksimal.</p>
      <footer>From <a href="https://berkahmadani.co.id" target="_blank">BMT Berkah Madani</a> website</footer>
    </blockquote>
  </div>
</div>
