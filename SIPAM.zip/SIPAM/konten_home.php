<!-- Isi Konten -->
<h1 class="text-center"><b>Home</b></h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>KSPPS BMT Berkah Madani</b></h2>
  </div>
  <div class="panel-body">
    <div class="text-center">
      <img class="img-responsive img-thumbnail" src="gambar/BMT-Berkah-Madani-1.png" alt="gambar BMT Berkah Madani" width="640" height="250" style="margin-bottom:10px;"/>
    </div>
    <div class="container-fluid">
      <!-- HR -->
      <table style="width:100%;">
        <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), black)"></td>
        <td>&nbsp;&nbsp;&nbsp;</td>
        <td><p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ&nbsp;اللهِ&nbsp;الرَّحْمَنِ&nbsp;الرَّحِيْمِ</p></td>
        <td>&nbsp;&nbsp;&nbsp;</td>
        <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, black, rgba(0,0,0,0.75), rgba(0,0,0,0));"></td>
      </table>

      <p class="paragraf">
        <strong>BMT</strong> adalah singkatan dari nama sebutan lembaga keuangan mikro Baitul Maal wat Tamwil
        atau padanan kata Balai-usaha Mandiri Terpadu.
      </p>
      <ol type="1">
        <li><p class="paragraf" style="margin-bottom:0px;">
          <strong>Kegiatan Baituttamwil</strong> adalah mengembangkan usaha-usaha produktif dan
          investasi dalam meningkatkan kualitas kegiatan ekonomi pengusaha kecil dengan antara lain
          mendorong kegiatan menabung dan menunjang kegiatan ekonominya.
        </p></li>
        <li><p class="paragraf">
          <strong>Kegiatan Baitul Maal</strong> adalah menerima titipan BAZIS dari dana zakat,
          infaq dan sadaqah dan menjalankannya sesuai dengan peraturan dan amanahnya.
        </p></li>
      </ol><br>

      <strong>APA CIRI-CIRI UTAMA BMT ?</strong>
      <ol type="1">
        <li><p class="paragraf" style="margin-bottom:0px;">
          Berorientasi bisnis dan sosial mencari laba bersama, meningkatkan pemanfaatan ekonomi
          paling banyak untuk anggota dan lingkungannya.
        </p></li>
        <li><p class="paragraf" style="margin-bottom:0px;">
          Bukan lembaga sosial, tetapi dapat dimanfaatkan untuk mengefektifkan penggunaan zakat,
          infaq dan sadaqah bagi kesejahteraan dan pemberdayaan orang banyak.
        </p></li>
        <li><p class="paragraf" style="margin-bottom:0px;">
          Ditumbuhkan dari bawah berdasar peran dari masyarakat sekitarnya.
        </p></li>
        <li><p class="paragraf" style="margin-bottom:0px;">
          Milik bersama masyarakat kecil bawah dan kecil dari lingkungan BMT itu sendiri,
          bukan milik orang seorang atau orang lain diluar masyarakat itu.
        </p></li>
      </ol><br>

      <p class="paragraf-kedalam">
        Sesungguhnya dalam operasionalnya, antara BMT dan KSPPS ( Koperasi SimpanPinjam dan
        Pembiayaan Syariah ) tidak terlalu banyak perbedaannya. Sebagai lembaga keuangan,
        keduanya mempunyai fungsi yang sama dalam penghimpunan dan penyaluran dana. Istilah-istilah
        yang digunakan juga tidak ada bedanya. Dalam proses penghimpunan dana, keduanya menggunakan
        istilah simpanan atau tabungan. Begitu pula dalam penyaluran danya, keduanya menggunakan
        istilah pembiayaan. Sedang syarat pendirian koperasi kedua lembaga tersebut mengharuskan
        minimal 20 orang. <br>
        Selain itu, dalam
      </p>
      <p class="paragraf-kedalam">
        Peraturan menteri koperasi dan usaha kecil dan menengah Republik indonesia
        Nomor 16 /per/m.kukm/ix/2015 Tentang Pelaksanaan kegiatan usaha simpan pinjam dan pembiayaan
        Syariah oleh koperasi Menteri koperasi dan usaha kecil dan menengah Republik indonesia,
        Bab I Ketentuan umum Pasal 1 ditegaskan bahwa operasional KSPPS juga memungkinkan untuk
        melaksankan fungsi ‘Maal’ dan fungsi ‘Tamwil’, sebagaimana yang selama ini dijalankan oleh BMT.
        Dalam hal ini, KSPPS harus dapat membedakan secara tegas antara fungsi ‘Maal’ dan fungsi ‘Tamwil’.
      </p>
      <p class="paragraf-kedalam">
        Adapun yang sedikit membedakan dalam pelaksanaannya, pada BMT memungkin-kan penyaluran dananya
        pada pihak luar, yaitu pihak yang belum menjadi anggota BMT. Sedangkan, dalam operasional KSPPS,
        penyaluran dananya hanya diperuntuk-kan pada pihak yang telah terdaftar menjadi anggota KSPPS.
        Dalam hal ini, KSPPS hanya diperkenankan memberikan pembiayaan kepada anggota. Hal ini sesuai
        dengan prinsip dasar koperasi, dari anggota, oleh anggota dan untuk anggota.
      </p>
      <p class="paragraf-kedalam">
        Adanya koperasi syariah (KSPPS) yang telah menjadi salah satu program Kementerian Negara
        Koperasi dan UKM merupakan solusi bagi pemecahan kebuntuhan legalitas BMT. Sehingga, diharapkan
        BMT-BMT yang saat ini belum berbadan hukum dapat mengkonversi menjadi koperasi syariah.
      </p>
      <p class="paragraf-kedalam">
        Koperasi syariah mempunyai kesamaan pengertian dalam kegiatan usahanya bergerak di bidang
        pembiayaan, investasi, dan simpanan sesuai pola bagi hasil (syariah), atau lebih dikenal dengan
        koperasi jasa keuangan syariah. Sebagai contoh produk jual beli dalam koperasi umum diganti
        namanya dengan istilah murabahah, produk simpan pinjam dalam koperasi umum diganti namanya
        dengan mudharabah. Tidak hanya perubahan nama, sistem operasional yang digunakan juga berubah,
        dari sistem konvesional (biasa) ke sistem syari’ah yang sesuai dengan aturan Islam.
      </p>

      <strong>Nilai-nilai Koperasi</strong>
      <p class="paragraf-kedalam">
        Pemerintah dan swasta, meliputi individu maupun masyarakat, wajib mentransformasikan nilai-nilai syari’ah dalam nilai-nilai koperasi, dengan mengadopsi 7 nilai syariah dalam bisnis yaitu :
        <ol type="a">
          <li>Shiddiq yang mencerminkan kejujuran, akurasi dan akuntabilitas.</li>
          <li>Istiqamah yang mencerminkan konsistensi, komitmen dan loyalitas.</li>
          <li>Tabligh yang mencerminkan transparansi, kontrol, edukatif, dan komunikatif</li>
          <li>Amanah yang mencerminkan kepercayaan, integritas, reputasi, dan kredibelitas.</li>
          <li>Fathanah yang mencerminkan etos profesional, kompeten, kreatif, inovatif.</li>
          <li>Ri’ayah yang mencerminkan semangat solidaritas, empati, kepedulian, awareness.</li>
          <li>Mas’uliyah yang mencerminkan responsibilitas.</li>
        </ol>
      </p>

      <strong>Tujuan Koperasi Syariah</strong>
      <p class="paragraf-kedalam">
        Meningkatkan kesejahteraan anggota pada khususnya dan masyarakat pada umumnya serta turut
        membangun tatanan perekonomian yang berkeadilan sesuai dengan prinsip-prinsip Islam.
      </p>

      <strong>Fungsi dan Peran Koperasi Syariah yaitu:</strong>
      <p>
        <ol type="1">
          <li><p class="paragraf" style="margin-bottom:0px;">
            Membangun dan mengembangkan potensi dan kemampuan anggota pada khususnya, dan masyarakat
            pada umumnya, guna meningkatkan kesejahteraan sosial ekonominya.

          </p>
          </li>
          <li><p class="paragraf" style="margin-bottom:0px;">
            Memperkuat kualitas sumber daya insani anggota, agar menjadi lebih amanah, professional
            (fathonah), konsisten, dan konsekuen (istiqomah) di dalam menerapkan prinsip-prinsip
            ekonomi islam dan prinsip-prinsip syariah islam.
          </p></li>
          <li><p class="paragraf" style="margin-bottom:0px;">
            Berusaha untuk mewujudkan dan mengembangkan perekonomian nasional yang merupakan usaha
            bersama berdasarkan azas kekeluargaan dan demokrasi ekonomi.
          </p></li>
          <li><p class="paragraf" style="margin-bottom:0px;">
            Sebagai mediator antara menyandang dana dengan penggunan dana, sehingga tercapai
            optimalisasi pemanfaatan harta.
          </p></li>
          <li><p class="paragraf" style="margin-bottom:0px;">
            Menguatkan kelompok-kelompok anggota, sehingga mampu bekerjasama melakukan
            kontrol terhadap koperasi secara efektif
          </p></li>
          <li>Mengembangkan dan memperluas kesempatan kerja</li>
          <li>Menumbuhkan-kembangkan usaha-usaha produktif anggota</li>
        </ol>
        <i>by : supri</i>
      </p>
      <blockquote>
        <footer>From <a href="https://berkahmadani.co.id" target="_blank">BMT Berkah Madani</a> website</footer>
      </blockquote>
    </div>
  </div>
</div>
