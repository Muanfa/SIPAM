<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Home</title>

    <!-- Ikon Gambar Title -->
    <link rel="icon" href="gambar/ccit.png" type="png">
    <!-- CSS Andi -->
    <link href="css/andi.css" rel="stylesheet">


    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/jquery.min.js"></script>

    <link rel="stylesheet" href="DataTables/datatables.min.css">
    <script src="DataTables/datatables.min.js" type="text/javascript"></script>


    <style media="screen">
      @font-face {
        font-family: Supercell-Magic;
        src: url(Supercell.magic.webfont.ttf);
      }
    </style>

  </head>
  <body>


    <!-- ============================= Header ============================== -->
      <div class="judul-web">
        <div class="container klik-judul">
          <a href="Home.html" class="dideketin"><h1 class="nama-judul">Muanfa<span class="nama-dotcom">.com</span></h1></a>
        </div>
        </div>
      </div>


    <!-- ====================== Navigasi (Horizontal) ====================== -->
    <nav class="navbar-inverse" data-spy="affix" data-offset-top="197" style="background-color:#596275;">
      <div class="container-fluid">
        <div class="navbar-header ">
          <!-- Button Naviagasi Kanan (Saat Layar Chrome dikecil) -->
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar" style="background-color:black;" onmouseover="this.style='background-color:gray;'" onmouseout="this.style='background-color:black;'">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <!-- Tombol LINK KIRI (Saat Layar Chrome dikecil)-->
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar2" style="float:left;margin-left:10px;background-color:black;" onmouseover="this.style='background-color:gray;float:left;margin-left:10px;'" onmouseout="this.style='background-color:black;float:left;margin-left:10px;'">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <div class="beranda">
            <a href="Home.html" title="Home" class="navbar-brand glyphicon glyphicon-home"  style="color:white;font-size:20px" onmouseover="this.style='text-decoration:none;color:#303952;font-size:20px'" onmouseout="this.style='color:white;font-size:20px'"></a>
          </div>
        </div>
       <!-- Tombol NAVIGASI ATAS -->
          <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav">
              <li><a href="Data.html" title="Section 1" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><b>Data</b></a></li>
              <li class="dropdown dropdown-toggle"><a title="Section 4" data-toggle="dropdown" href="#" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><b>Section 2</b> <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="#section41">Section 4-1</a></li>
                  <li><a href="#section42">Section 4-2</a></li>
                </ul>
              </li>
            </ul>
            <!-- TOMBOL LOGIN -->
            <ul class="nav navbar-nav" style="float:right;">
              <li class="dropdown" ><a href="#" class="dropdown-toggle" data-toggle="dropdown" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><span class="glyphicon glyphicon-log-in" style="font-size:16px;color:#4bcffa;"></span><b> Login</b></a>
                <div class="dropdown-menu">
                  <form id="formLogin" class="form container-fluid">
                    <div class="form-group">
                      <label for="email">Email:</label>
                      <!-- <input type="text" class="form-control" id="usr"> -->
                      <input id="email" type="text" class="form-control" name="email" placeholder="Email">
                    </div>
                    <div class="form-group">
                      <label for="pwd">Password:</label>
                      <!-- <input type="password" class="form-control" id="pwd"> -->
                      <input id="password" type="password" class="form-control" name="password" placeholder="Password">
                    </div>
                    <button type="submit" id="btnLogin" class="btn btn-block" style="background-color:#3399ff;color:white;" onmouseover="this.style='background-color:#0080ff;color:white;'" onmouseout="this.style='background-color:#3399ff;color:white;'" >Login</button><br>
                  </form>
                </div>
              </li>
              <!-- <li><a href="Login.html" title="Sign Up" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><span class="glyphicon glyphicon-user" style="font-size:16px;"></span><b> Logout</b></a></li> -->
              <li>
                <!-- TOMBOL LOGOUT -->
                <form class="" action="Login.html" method="post">
                  <button class="btn navbar-btn" style="background-color:#ff3838;color:white;margin-left:8%;" onmouseover="this.style='background-color:#ee5253;color:white;margin-left:8%;'" onmouseout="this.style='background-color:#ff3838;color:white;margin-left:8%;'"><span class="glyphicon glyphicon-off" style="color:black;"></span><b> Logout</b></button>
                </form>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>


    <!-- ===================== Navigasi (Veritakal)  ======================  -->
    <div id="myNavbar2" class="atur-link collapse navbar-collapse navbar-inverse" data-spy="affix" data-offset-top="197" style="height:900px;">
      <div class="scroll-link" id="accordion">
        <!-- Gambar Admin -->
          <div class="panel" style="margin:2%;background-color:#706fd3;" >
            <div class="panel-heading" onmouseover="this.style='text-decoration:none;background-color:#574b90;'" onmouseout="this.style='color:white;background-color:#706fd3;'">
              <div class="" style="height:50px;" >
                <div class="gambar-profil">
                  <img src="gambar/Andi.jpg" class="img-circle img-responsive" alt="m andi fadillah" width="50" height="50">
                </div>
                <div class="profil">
                  <div class="nama-profil responsive">
                    Muhammad Andi F
                  </div>
                  <div class=" jarak-bulet">
                    <div class="status-bullet">
                      <b><span>&bull;</span></b>
                    </div>
                  </div>
                  <div class="status-online">
                    <b>Online</b>
                  </div>
                </div>
            </div>
          </div>
          </div>
            <!-- Link 1 -->
          <div class="panel panel-info" style="margin-left:2%;margin-bottom:2%;margin-right:2%;">
            <div class="panel-heading">
              <ul class="nav nav-pills nav-stacked panel panel-default" style="margin-left:-4%;margin-top:-2%;margin-right:-4%;margin-bottom:-2%;">
                <li><a href="#" tabindex="-1"><span class="glyphicon glyphicon-bookmark" style="font-size:15px;color:#9c88ff;"></span><b> Link 1</b></a></li>
              </ul>
            </div>
          </div>
            <!-- User -->
          <div class="panel panel-info" style="margin-left:2%;margin-bottom:2%;margin-right:2%;">
            <div class="panel-heading">
              <ul class="nav nav-stacked panel panel-default" style="margin-left:-4%;margin-top:-2%;margin-right:-4%;margin-bottom:-2%;">
                <li><a tabindex="-1" data-toggle="collapse" data-parent="#accordion" data-target="#collapse-1"><span class="glyphicon glyphicon-user" style="font-size:15px;color:black"></span><b> User</b><span class="glyphicon glyphicon-chevron-down" style="float:right;font-size:18px;margin-top:1.5%;"></span></a></li>
                <!-- <li><a href="#" tabindex="-1" data-toggle="collapse" data-target="#collapse-1"><b>Link 2</b><span class="glyphicon glyphicon-chevron-down" style="float:right;font-size:13px;"></span></a></li> -->
              </ul>
            </div>
            <div id="collapse-1" class="panel-collapse collapse in">
              <div class="panel-body">
                <ul class="nav nav-pills nav-stacked ">
                  <!-- Kalau misalnya lagi dibagian ini, mau di waranain tingal ubah style background-color -->
                  <li><a href="#" tabindex="-1" style="background-color:#686de0;color:white;"><span class="glyphicon glyphicon-triangle-right"></span> User</a></li>
                  <li><a href="#" tabindex="-1"><span class="glyphicon glyphicon-triangle-right"></span> User</a></li>
                  <li><a href="#" tabindex="-1"><span class="glyphicon glyphicon-triangle-right"></span> User</a></li>
                </ul>
              </div>
            </div>
          </div>
            <!-- Transaksi -->
          <div class="panel panel-info" style="margin-left:2%;margin-bottom:2%;margin-right:2%;">
            <div class="panel-heading">
              <ul class="nav nav-stacked panel panel-default" style="margin-left:-4%;margin-top:-2%;margin-right:-4%;margin-bottom:-2%;">
                <li><a tabindex="-1" data-toggle="collapse" data-parent="#accordion" data-target="#collapse-2"><span class="glyphicon glyphicon-briefcase" style="font-size:15px;color:red;"></span><b> Transaksi</b><span class="glyphicon glyphicon-chevron-down" style="float:right;font-size:18px;margin-top:1.5%;"></span></a></li>
                <!-- <li><a href="#" tabindex="-1" data-toggle="collapse" data-target="#collapse-1"><b>Link 2</b><span class="glyphicon glyphicon-chevron-down" style="float:right;font-size:13px;"></span></a></li> -->
              </ul>
            </div>
            <div id="collapse-2" class="panel-collapse collapse">
              <div class="panel-body">
                <ul class="nav nav-pills nav-stacked">
                  <!-- Kalau misalnya lagi dibagian ini, mau di waranain tingal ubah style background-color -->
                  <li><a href="#" tabindex="-1"><span class="glyphicon glyphicon-triangle-right"></span> Folder</a></li>
                  <li><a href="#" tabindex="-1"><span class="glyphicon glyphicon-triangle-right"></span> Folder</a></li>
                  <li><a href="#" tabindex="-1"><span class="glyphicon glyphicon-triangle-right"></span> Folder</a></li>
                </ul>
              </div>
            </div>
          </div>
            <!-- Laporan -->
          <div class="panel panel-info" style="margin-left:2%;margin-bottom:2%;margin-right:2%;">
            <div class="panel-heading">
              <ul class="nav nav-stacked panel panel-default" style="margin-left:-4%;margin-top:-2%;margin-right:-4%;margin-bottom:-2%;">
                <li><a tabindex="-1" data-toggle="collapse" data-parent="#accordion" data-target="#collapse-3"><span class="glyphicon glyphicon-folder-open" style="font-size:15px;color:orange"></span><b> Laporan</b><span class="glyphicon glyphicon-chevron-down" style="float:right;font-size:18px;margin-top:1.5%;"></span></a></li>
                <!-- <li><a href="#" tabindex="-1" data-toggle="collapse" data-target="#collapse-1"><b>Link 2</b><span class="glyphicon glyphicon-chevron-down" style="float:right;font-size:13px;"></span></a></li> -->
              </ul>
            </div>
            <div id="collapse-3" class="panel-collapse collapse">
              <div class="panel-body">
                <ul class="nav nav-pills nav-stacked">
                  <!-- Kalau misalnya lagi dibagian ini, mau di waranain tingal ubah style background-color -->
                  <li><a href="#" tabindex="-1"><span class="glyphicon glyphicon-triangle-right"></span> Laporan</a></li>
                  <li><a href="#" tabindex="-1"><span class="glyphicon glyphicon-triangle-right"></span> Laporan</a></li>
                  <li><a href="#" tabindex="-1"><span class="glyphicon glyphicon-triangle-right"></span> Laporan</a></li>
                </ul>
              </div>
            </div>
          </div>


          <!-- Info -->
          <div class="panel panel-info" style="margin-left:2%;margin-bottom:2%;margin-right:2%;">
            <div class="panel-heading">
              <ul class="nav nav-stacked panel panel-default" style="margin-left:-4%;margin-top:-2%;margin-right:-4%;margin-bottom:-2%;">
                <li><a tabindex="-1" data-toggle="collapse" data-parent="#accordion" data-target="#collapse-4"><span class="glyphicon glyphicon-info-sign" style="font-size:15px;color:blue;"></span><b> Info</b><span class="glyphicon glyphicon-chevron-down" style="float:right;font-size:18px;margin-top:1.5%;"></span></a></li>
                <!-- <li><a href="#" tabindex="-1" data-toggle="collapse" data-target="#collapse-1"><b>Link 2</b><span class="glyphicon glyphicon-chevron-down" style="float:right;font-size:13px;"></span></a></li> -->
              </ul>
            </div>
            <div id="collapse-4" class="panel-collapse collapse">
              <div class="panel-body">
                <ul class="nav nav-pills nav-stacked">
                  <!-- Kalau misalnya lagi dibagian ini, mau di waranain tingal ubah style background-color -->
                  <li><a href="#" tabindex="-1"><span class="glyphicon glyphicon-triangle-right"></span> Laporan</a></li>
                  <li><a href="#" tabindex="-1"><span class="glyphicon glyphicon-triangle-right"></span> Laporan</a></li>
                  <li><a href="#" tabindex="-1"><span class="glyphicon glyphicon-triangle-right"></span> Laporan</a></li>
                </ul>
              </div>
            </div>
          </div>
          <hr>
        </div>
      </div>
    </div>


    <!-- ======================== Konten Web  =============================  -->
      <!-- Konten -->
    <div class="container-fluid atur-konten" style="">
        <div class="isi-konten" >
          <div class="container-fluid">
            <h1 class="text-center">Beranda</h1>

            <hr>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h1 class="panel-title text-center"><b>Admin</b>
                  <strong style="color:#884dff;font-family:'Supercell-Magic'">Muanfa</strong>
                </h1>
              </div>
              <div class="panel-body">
                <div class="container-fluid">
                  <table id="asexample" class="table responsive table-striped table-bordered table-hover" style="width:100%">
                          <thead>
                              <tr>
                                  <th>Name</th>
                                  <th>Position</th>
                                  <th>Office</th>
                                  <th>Age</th>
                                  <th>Start date</th>
                                  <th>Salary</th>
                              </tr>
                          </thead>
                          <tbody>
                              <tr>
                                  <td>Tiger Nixon</td>
                                  <td>System Architect</td>
                                  <td>Edinburgh</td>
                                  <td>61</td>
                                  <td>2011/04/25</td>
                                  <td>$320,800</td>
                              </tr>
                              <tr>
                                  <td>Garrett Winters</td>
                                  <td>Accountant</td>
                                  <td>Tokyo</td>
                                  <td>63</td>
                                  <td>2011/07/25</td>
                                  <td>$170,750</td>
                              </tr>
                              <tr>
                                  <td>Ashton Cox</td>
                                  <td>Junior Technical Author</td>
                                  <td>San Francisco</td>
                                  <td>66</td>
                                  <td>2009/01/12</td>
                                  <td>$86,000</td>
                              </tr>
                              <tr>
                                  <td>Cedric Kelly</td>
                                  <td>Senior Javascript Developer</td>
                                  <td>Edinburgh</td>
                                  <td>22</td>
                                  <td>2012/03/29</td>
                                  <td>$433,060</td>
                              </tr>
                              <tr>
                                  <td>Airi Satou</td>
                                  <td>Accountant</td>
                                  <td>Tokyo</td>
                                  <td>33</td>
                                  <td>2008/11/28</td>
                                  <td>$162,700</td>
                              </tr>
                              <tr>
                                  <td>Brielle Williamson</td>
                                  <td>Integration Specialist</td>
                                  <td>New York</td>
                                  <td>61</td>
                                  <td>2012/12/02</td>
                                  <td>$372,000</td>
                              </tr>
                              <tr>
                                  <td>Herrod Chandler</td>
                                  <td>Sales Assistant</td>
                                  <td>San Francisco</td>
                                  <td>59</td>
                                  <td>2012/08/06</td>
                                  <td>$137,500</td>
                              </tr>
                              <tr>
                                  <td>Rhona Davidson</td>
                                  <td>Integration Specialist</td>
                                  <td>Tokyo</td>
                                  <td>55</td>
                                  <td>2010/10/14</td>
                                  <td>$327,900</td>
                              </tr>
                              <tr>
                                  <td>Colleen Hurst</td>
                                  <td>Javascript Developer</td>
                                  <td>San Francisco</td>
                                  <td>39</td>
                                  <td>2009/09/15</td>
                                  <td>$205,500</td>
                              </tr>
                              <tr>
                                  <td>Sonya Frost</td>
                                  <td>Software Engineer</td>
                                  <td>Edinburgh</td>
                                  <td>23</td>
                                  <td>2008/12/13</td>
                                  <td>$103,600</td>
                              </tr>
                              <tr>
                                  <td>Jena Gaines</td>
                                  <td>Office Manager</td>
                                  <td>London</td>
                                  <td>30</td>
                                  <td>2008/12/19</td>
                                  <td>$90,560</td>
                              </tr>
                              <tr>
                                  <td>Quinn Flynn</td>
                                  <td>Support Lead</td>
                                  <td>Edinburgh</td>
                                  <td>22</td>
                                  <td>2013/03/03</td>
                                  <td>$342,000</td>
                              </tr>
                              <tr>
                                  <td>Charde Marshall</td>
                                  <td>Regional Director</td>
                                  <td>San Francisco</td>
                                  <td>36</td>
                                  <td>2008/10/16</td>
                                  <td>$470,600</td>
                              </tr>
                              <tr>
                                  <td>Haley Kennedy</td>
                                  <td>Senior Marketing Designer</td>
                                  <td>London</td>
                                  <td>43</td>
                                  <td>2012/12/18</td>
                                  <td>$313,500</td>
                              </tr>
                              <tr>
                                  <td>Tatyana Fitzpatrick</td>
                                  <td>Regional Director</td>
                                  <td>London</td>
                                  <td>19</td>
                                  <td>2010/03/17</td>
                                  <td>$385,750</td>
                              </tr>
                              <tr>
                                  <td>Michael Silva</td>
                                  <td>Marketing Designer</td>
                                  <td>London</td>
                                  <td>66</td>
                                  <td>2012/11/27</td>
                                  <td>$198,500</td>
                              </tr>
                              <tr>
                                  <td>Paul Byrd</td>
                                  <td>Chief Financial Officer (CFO)</td>
                                  <td>New York</td>
                                  <td>64</td>
                                  <td>2010/06/09</td>
                                  <td>$725,000</td>
                              </tr>
                              <tr>
                                  <td>Gloria Little</td>
                                  <td>Systems Administrator</td>
                                  <td>New York</td>
                                  <td>59</td>
                                  <td>2009/04/10</td>
                                  <td>$237,500</td>
                              </tr>
                              <tr>
                                  <td>Bradley Greer</td>
                                  <td>Software Engineer</td>
                                  <td>London</td>
                                  <td>41</td>
                                  <td>2012/10/13</td>
                                  <td>$132,000</td>
                              </tr>
                              <tr>
                                  <td>Dai Rios</td>
                                  <td>Personnel Lead</td>
                                  <td>Edinburgh</td>
                                  <td>35</td>
                                  <td>2012/09/26</td>
                                  <td>$217,500</td>
                              </tr>
                              <tr>
                                  <td>Jenette Caldwell</td>
                                  <td>Development Lead</td>
                                  <td>New York</td>
                                  <td>30</td>
                                  <td>2011/09/03</td>
                                  <td>$345,000</td>
                              </tr>
                              <tr>
                                  <td>Yuri Berry</td>
                                  <td>Chief Marketing Officer (CMO)</td>
                                  <td>New York</td>
                                  <td>40</td>
                                  <td>2009/06/25</td>
                                  <td>$675,000</td>
                              </tr>
                              <tr>
                                  <td>Caesar Vance</td>
                                  <td>Pre-Sales Support</td>
                                  <td>New York</td>
                                  <td>21</td>
                                  <td>2011/12/12</td>
                                  <td>$106,450</td>
                              </tr>
                              <tr>
                                  <td>Doris Wilder</td>
                                  <td>Sales Assistant</td>
                                  <td>Sidney</td>
                                  <td>23</td>
                                  <td>2010/09/20</td>
                                  <td>$85,600</td>
                              </tr>
                              <tr>
                                  <td>Angelica Ramos</td>
                                  <td>Chief Executive Officer (CEO)</td>
                                  <td>London</td>
                                  <td>47</td>
                                  <td>2009/10/09</td>
                                  <td>$1,200,000</td>
                              </tr>
                              <tr>
                                  <td>Gavin Joyce</td>
                                  <td>Developer</td>
                                  <td>Edinburgh</td>
                                  <td>42</td>
                                  <td>2010/12/22</td>
                                  <td>$92,575</td>
                              </tr>
                              <tr>
                                  <td>Jennifer Chang</td>
                                  <td>Regional Director</td>
                                  <td>Singapore</td>
                                  <td>28</td>
                                  <td>2010/11/14</td>
                                  <td>$357,650</td>
                              </tr>
                              <tr>
                                  <td>Brenden Wagner</td>
                                  <td>Software Engineer</td>
                                  <td>San Francisco</td>
                                  <td>28</td>
                                  <td>2011/06/07</td>
                                  <td>$206,850</td>
                              </tr>
                              <tr>
                                  <td>Fiona Green</td>
                                  <td>Chief Operating Officer (COO)</td>
                                  <td>San Francisco</td>
                                  <td>48</td>
                                  <td>2010/03/11</td>
                                  <td>$850,000</td>
                              </tr>
                              <tr>
                                  <td>Shou Itou</td>
                                  <td>Regional Marketing</td>
                                  <td>Tokyo</td>
                                  <td>20</td>
                                  <td>2011/08/14</td>
                                  <td>$163,000</td>
                              </tr>
                              <tr>
                                  <td>Michelle House</td>
                                  <td>Integration Specialist</td>
                                  <td>Sidney</td>
                                  <td>37</td>
                                  <td>2011/06/02</td>
                                  <td>$95,400</td>
                              </tr>
                              <tr>
                                  <td>Suki Burks</td>
                                  <td>Developer</td>
                                  <td>London</td>
                                  <td>53</td>
                                  <td>2009/10/22</td>
                                  <td>$114,500</td>
                              </tr>
                              <tr>
                                  <td>Prescott Bartlett</td>
                                  <td>Technical Author</td>
                                  <td>London</td>
                                  <td>27</td>
                                  <td>2011/05/07</td>
                                  <td>$145,000</td>
                              </tr>
                              <tr>
                                  <td>Gavin Cortez</td>
                                  <td>Team Leader</td>
                                  <td>San Francisco</td>
                                  <td>22</td>
                                  <td>2008/10/26</td>
                                  <td>$235,500</td>
                              </tr>
                              <tr>
                                  <td>Martena Mccray</td>
                                  <td>Post-Sales support</td>
                                  <td>Edinburgh</td>
                                  <td>46</td>
                                  <td>2011/03/09</td>
                                  <td>$324,050</td>
                              </tr>
                              <tr>
                                  <td>Unity Butler</td>
                                  <td>Marketing Designer</td>
                                  <td>San Francisco</td>
                                  <td>47</td>
                                  <td>2009/12/09</td>
                                  <td>$85,675</td>
                              </tr>
                              <tr>
                                  <td>Howard Hatfield</td>
                                  <td>Office Manager</td>
                                  <td>San Francisco</td>
                                  <td>51</td>
                                  <td>2008/12/16</td>
                                  <td>$164,500</td>
                              </tr>
                              <tr>
                                  <td>Hope Fuentes</td>
                                  <td>Secretary</td>
                                  <td>San Francisco</td>
                                  <td>41</td>
                                  <td>2010/02/12</td>
                                  <td>$109,850</td>
                              </tr>
                              <tr>
                                  <td>Vivian Harrell</td>
                                  <td>Financial Controller</td>
                                  <td>San Francisco</td>
                                  <td>62</td>
                                  <td>2009/02/14</td>
                                  <td>$452,500</td>
                              </tr>
                              <tr>
                                  <td>Timothy Mooney</td>
                                  <td>Office Manager</td>
                                  <td>London</td>
                                  <td>37</td>
                                  <td>2008/12/11</td>
                                  <td>$136,200</td>
                              </tr>
                              <tr>
                                  <td>Jackson Bradshaw</td>
                                  <td>Director</td>
                                  <td>New York</td>
                                  <td>65</td>
                                  <td>2008/09/26</td>
                                  <td>$645,750</td>
                              </tr>
                              <tr>
                                  <td>Olivia Liang</td>
                                  <td>Support Engineer</td>
                                  <td>Singapore</td>
                                  <td>64</td>
                                  <td>2011/02/03</td>
                                  <td>$234,500</td>
                              </tr>
                              <tr>
                                  <td>Bruno Nash</td>
                                  <td>Software Engineer</td>
                                  <td>London</td>
                                  <td>38</td>
                                  <td>2011/05/03</td>
                                  <td>$163,500</td>
                              </tr>
                              <tr>
                                  <td>Sakura Yamamoto</td>
                                  <td>Support Engineer</td>
                                  <td>Tokyo</td>
                                  <td>37</td>
                                  <td>2009/08/19</td>
                                  <td>$139,575</td>
                              </tr>
                              <tr>
                                  <td>Thor Walton</td>
                                  <td>Developer</td>
                                  <td>New York</td>
                                  <td>61</td>
                                  <td>2013/08/11</td>
                                  <td>$98,540</td>
                              </tr>
                              <tr>
                                  <td>Finn Camacho</td>
                                  <td>Support Engineer</td>
                                  <td>San Francisco</td>
                                  <td>47</td>
                                  <td>2009/07/07</td>
                                  <td>$87,500</td>
                              </tr>
                              <tr>
                                  <td>Serge Baldwin</td>
                                  <td>Data Coordinator</td>
                                  <td>Singapore</td>
                                  <td>64</td>
                                  <td>2012/04/09</td>
                                  <td>$138,575</td>
                              </tr>
                              <tr>
                                  <td>Zenaida Frank</td>
                                  <td>Software Engineer</td>
                                  <td>New York</td>
                                  <td>63</td>
                                  <td>2010/01/04</td>
                                  <td>$125,250</td>
                              </tr>
                              <tr>
                                  <td>Zorita Serrano</td>
                                  <td>Software Engineer</td>
                                  <td>San Francisco</td>
                                  <td>56</td>
                                  <td>2012/06/01</td>
                                  <td>$115,000</td>
                              </tr>
                              <tr>
                                  <td>Jennifer Acosta</td>
                                  <td>Junior Javascript Developer</td>
                                  <td>Edinburgh</td>
                                  <td>43</td>
                                  <td>2013/02/01</td>
                                  <td>$75,650</td>
                              </tr>
                              <tr>
                                  <td>Cara Stevens</td>
                                  <td>Sales Assistant</td>
                                  <td>New York</td>
                                  <td>46</td>
                                  <td>2011/12/06</td>
                                  <td>$145,600</td>
                              </tr>
                              <tr>
                                  <td>Hermione Butler</td>
                                  <td>Regional Director</td>
                                  <td>London</td>
                                  <td>47</td>
                                  <td>2011/03/21</td>
                                  <td>$356,250</td>
                              </tr>
                              <tr>
                                  <td>Lael Greer</td>
                                  <td>Systems Administrator</td>
                                  <td>London</td>
                                  <td>21</td>
                                  <td>2009/02/27</td>
                                  <td>$103,500</td>
                              </tr>
                              <tr>
                                  <td>Jonas Alexander</td>
                                  <td>Developer</td>
                                  <td>San Francisco</td>
                                  <td>30</td>
                                  <td>2010/07/14</td>
                                  <td>$86,500</td>
                              </tr>
                              <tr>
                                  <td>Shad Decker</td>
                                  <td>Regional Director</td>
                                  <td>Edinburgh</td>
                                  <td>51</td>
                                  <td>2008/11/13</td>
                                  <td>$183,000</td>
                              </tr>
                              <tr>
                                  <td>Michael Bruce</td>
                                  <td>Javascript Developer</td>
                                  <td>Singapore</td>
                                  <td>29</td>
                                  <td>2011/06/27</td>
                                  <td>$183,000</td>
                              </tr>
                              <tr>
                                  <td>Donna Snider</td>
                                  <td>Customer Support</td>
                                  <td>New York</td>
                                  <td>27</td>
                                  <td>2011/01/25</td>
                                  <td>$112,000</td>
                              </tr>
                          </tbody>
                          <tfoot>
                              <tr>
                                  <th>Name</th>
                                  <th>Position</th>
                                  <th>Office</th>
                                  <th>Age</th>
                                  <th>Start date</th>
                                  <th>Salary</th>
                              </tr>
                          </tfoot>
                    </table>
                </div>
              </div>
            </div>




          </div>
    <!--- ========================= Footer ================================= -->
          <footer>
            <div class="col-sm-12 sosmed" style="width:100%;">
              <!-- Ikon Sosmed -->
              <div class="posisi-sosmed">
                <ul class="list-inline">
                  <li><a data-toggle="tooltip" title="Facebook" href="https://id-id.facebook.com/muhamadandi.fadilah.1" target="_blank"><img class="ukuran-ikon-sosmed" src="gambar/footer/Icon-facebook.png"></a></li>
                  <li><a data-toggle="tooltip" title="Instagram" href="https://www.instagram.com/im.muanfa/" target="_blank"><img class="ukuran-ikon-sosmed" src="gambar/footer/Icon-instagram.png"></a></li>
                  <li><a data-toggle="tooltip" title="Youtube" href="#" target="_blank"><img class="ukuran-ikon-sosmed" src="gambar/footer/Icon-Youtube.png"></a></li>
                  <li><a data-toggle="tooltip" title="Twiter" href="#" target="_blank"><img class="ukuran-ikon-sosmed" src="gambar/footer/Icon-Twitter.png"></a></li>
                  <li><a data-toggle="tooltip" title="Line" href="#" target="_blank"><img class="ukuran-ikon-sosmed" src="gambar/footer/Icon-Line.png"></a></li>
                </ul>
                <!-- Kata-kata CopyRight -->
              </div >
              <div class="posisi-copyright">
                <strong class="warna-teks-fot">Copyright &copy; 2014-2018 <a class href="" style="color:#33d9b2;">AdminAndi.io</a> All rights reserved.</strong><br><br>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function() {
          $('#asexample').DataTable();
        } );
    </script>


    <script>
      $(document).ready(function(){
          $('[data-toggle="tooltip"]').tooltip();
      });
    </script>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!-- <script src="js/jquery.min.js"></script> -->
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
