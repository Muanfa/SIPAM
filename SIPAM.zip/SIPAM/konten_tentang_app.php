<!-- Isi Konten -->
<h1 class="text-center"><b>Info</b></h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>Tentang App Website</b></h2>
  </div>
  <div class="panel-body">
    <!-- HR -->
    <table style="width:100%;">
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), black)"></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td><p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ&nbsp;اللهِ&nbsp;الرَّحْمَنِ&nbsp;الرَّحِيْمِ</p></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, black, rgba(0,0,0,0.75), rgba(0,0,0,0));"></td>
    </table>

    <img class="img-responsive " src="gambar/ccit.png" alt="gambar CCIT" width="200" height="392" style="float:left;margin-right:;margin-bottom:10px;"/>
    <div class="container-fluid">

      <h1 style="text-align:center;">CEP-CCIT FTUI</h1>
      <hr style="margin:0px;border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), rgba(0,0,0,0));">
      <h3 style="text-align:center;">Fakultas Teknik Universitas Indonesia</h3>

      <address style="margin-left:15%;" >
        <br><br>
        <table style="font-size:20px;text-align:left;">
          <tr style="">
            <td><span class="glyphicon glyphicon-bookmark" style="color:#9c88ff;font-size:30px;"></span></td>
            <td style="width:200px;"><p style="margin-left:10px;margin-top:8px;"><strong>Nama App Website</strong></td>
            <td><p style="margin-top:8px;">: "Sistem Informasi Pembiayaan Akad Murabahah"</p></td>
          </tr>
          <tr>
            <td><span class="glyphicon glyphicon-pushpin" style="color:#4cd137;font-size:30px;"></span></td>
            <td><p style="margin-left:10px;margin-top:8px;"><strong>Studi Kasus</strong></p></td>
            <td><p style="margin-top:8px;">: KSPPS BMT Berkah Madani Kota Depok (BMT)</p></td>
          </tr>
          <tr>
            <td><span class="glyphicon glyphicon-education" style="color:#0097e6;font-size:30px;"></span></td>
            <td><p style="margin-left:10px;margin-top:8px;"><strong>Nama Author</strong></p></td>
            <td><p style="margin-top:8px;">: Muhammad Andi Fadillah</p></td>
          </tr>
          <tr>
            <td><span class="glyphicon glyphicon-user" style="color:#353b48;font-size:30px;"></span></td>
            <td><p style="margin-left:10px;margin-top:8px;"><strong>Pembimbing BIS</strong></p></td>
            <td><p style="margin-top:8px;">: Bpk. Riza Muhammad Nurman, S.Kom</p></td>
          </tr>
          <tr>
            <td><span class="glyphicon glyphicon-user" style="color:#c44569;font-size:30px;"></span></td>
            <td><p style="margin-left:10px;margin-top:8px;"><strong>Pembimbing BMT</strong></p></td>
            <td><p style="margin-top:8px;">: Bpk. Supri Yatno</p></td>
          </tr>
          <tr>
            <td><span class="glyphicon glyphicon-briefcase" style="color:#ff793f;font-size:30px;"></span></td>
            <td><p style="margin-left:10px;margin-top:8px;"><strong>Jurusan</strong></p></td>
            <td><p style="margin-top:8px;">: Teknologi Informasi Perbankan Syariah (TIPS)</p></td>
          </tr>
          <tr>
            <td><span class="glyphicon glyphicon-calendar" style="color:#a5b1c2;font-size:30px;"></span></td>
            <td><p style="margin-left:10px;margin-top:8px;"><strong>Angkatan Tahun</strong></p></td>
            <td><p style="margin-top:8px;">: 2015</p></td>
          </tr>
          <tr>
            <td><span class="glyphicon glyphicon-tag" style="color:#17c0eb;font-size:30px;"></span></td>
            <td><p style="margin-left:10px;margin-top:8px;"><strong>NIM</strong></p></td>
            <td><p style="margin-top:8px;">: 1512020014</p></td>
          </tr>
          <tr>
            <td><span class="glyphicon glyphicon-book" style="color:#574b90;font-size:30px;"></span></td>
            <td><p style="margin-left:10px;margin-top:8px;"><strong>Tugas Akhir</strong></p></td>
            <td><p style="margin-top:8px;">: Sharia Banking Integrated Solution (BIS)</p></td>
          </tr>
          <tr>
            <td><span class="glyphicon glyphicon-info-sign" style="color:#535c68;font-size:30px;"></span></td>
            <td><p style="margin-left:10px;margin-top:8px;"><strong>Versi</strong></p></td>
            <td><p style="margin-top:8px;">: 2.20</p></td>
          </tr>
        </table>
      </address>
    </div>


  </div>
</div>
