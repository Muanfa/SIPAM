<h1 class="text-center"><b>Nasabah</b></h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>Data Rekening</b></h2>
  </div>
  <div class="panel-body">
    <!-- HR -->
    <table style="width:100%;">
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), black)"></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td><p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ&nbsp;اللهِ&nbsp;الرَّحْمَنِ&nbsp;الرَّحِيْمِ</p></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, black, rgba(0,0,0,0.75), rgba(0,0,0,0));"></td>
    </table>

    <div class="container-fluid panel panel-default" style="padding-top:10px;padding-bottom:10px;">
      <table id="asexample" class="table responsive table-striped table-bordered table-hover" style="width:100%">
        <thead>
          <tr>
              <th>No</th>
              <th>Aksi</th>
              <th>Status</th>
              <th>ID Rekening</th>
              <th>Nama</th>
              <th>Tanggal Buka</th>
              <th>Saldo</th>
              <th>Jenis Tabungan</th>
          </tr>
        </thead>
        <tbody>


          <?php
            // Menyembunyikan eror
            error_reporting(0);
            $id_nsb   = $_GET['id'];

            $query = mysqli_query($konek, "SELECT * FROM data_reknasabah WHERE id_nasabah = '$id_nsb'");
            $no = 1;
            while($rows = mysqli_fetch_array($query)){
          ?>

          <tr style="text-align:center;">
            <td><?php echo $no++;?></td>
            <td style="width:180px;">
              <!-- Tambah Saldo -->
              <?php if(isset($_SESSION['admin'])){?>
                <button type='button' onclick="window.location = 'admin_tambah_salnasabah.php?id=<?php echo $rows['id_nasabah'];?>'" class='btn btn-success btn-sm'>Tambah Saldo</button>&#32;
              <?php } ?>

              <!-- Lihat Transaksi -->
              <?php if (isset($_SESSION['manager'])){ ?>
                <button type='button' onclick="window.location = 'manager_lihat_transaksi_reknasabah.php?id=<?php echo $rows['id_nasabah'];?>'" class='btn btn-primary btn-sm'>Lihat Transaksi</button>&#32;
              <?php } else
              if(isset($_SESSION['admin'])){?>
                <button type='button' onclick="window.location = 'admin_lihat_transaksi_reknasabah.php?id=<?php echo $rows['id_nasabah'];?>'" class='btn btn-primary btn-sm'>Lihat Transaksi</button>&#32;
              <?php } ?>

              <!-- CETAK -->
              <button type='button' onclick="window.open('cetak_data_reknasabah.php?id=<?php echo $rows['id_nasabah'];?>','nama_window_pop_up','size=800,height=800,scrollbars=yes,resizeable=no')" class='btn btn-info btn-sm'>Cetak</button>
            </td>
            <td><?php echo $rows['status'];                ?></td>
            <td><?php echo $rows['id_reknasabah'];         ?></td>
            <td><?php echo $rows['nama']                   ?></td>
            <td><?php echo $rows['tanggal_buka'];          ?></td>
            <td><?php echo $rows['saldo'];                 ?></td>
            <td><?php echo $rows['jenis_tabungan'];        ?></td>
          </tr>

          <?php
            }
          ?>
        </tbody>
      </table>
    </div>

  </div>
</div>
