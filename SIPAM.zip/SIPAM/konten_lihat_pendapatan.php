<h1 class="text-center"><b>Laporan Keuangan</b></h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>Data Laporan Pendapatan</b></h2>
  </div>
  <div class="panel-body">
    <!-- HR -->
    <table style="width:100%;">
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), black)"></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td><p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ&nbsp;اللهِ&nbsp;الرَّحْمَنِ&nbsp;الرَّحِيْمِ</p></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, black, rgba(0,0,0,0.75), rgba(0,0,0,0));"></td>
    </table>

    <!-- BUTTON CETAK LAPORAN -->
    <div>
      <button type='button' onclick="window.open('cetak_pendapatan.php?dari_tgl=<?php echo $_POST['dari_tgl'];?>&sampai_tgl=<?php echo $_POST['sampai_tgl'];?>','nama_window_pop_up','width=200,height=200,scrollbars=yes,resizeable=no')" class='btn btn-info btn-lg'>
        <span class="glyphicon glyphicon-print" style="color:black;"></span> Cetak</button>
      <hr>
    </div>

    <h3 align="center"><b>Laporan Data Pendapatan dari <i><?php echo $_POST['dari_tgl'];?></i> hingga <i><?php echo $_POST['sampai_tgl'];?></i></b></h3>
    <?php
      $dari_tgl = $_POST['dari_tgl'];
      $sampai_tgl = $_POST['sampai_tgl'];
      $total = "0";
      $query = mysqli_query($konek, "SELECT * FROM data_laporanpendapatan WHERE tanggal BETWEEN '$dari_tgl' AND '$sampai_tgl' ORDER BY id_pendapatan");
      while($rows2 = mysqli_fetch_array($query)){
        $pdptn = $rows2['debit'];
        $total = $total + $pdptn;
      }
     ?>
    <h4 align="left"><b>Total Pendapatan : Rp. <u><?php echo number_format($total); ?></u></b></h4>
    <div class="container-fluid panel panel-default" style="padding-top:10px;padding-bottom:10px;">
      <table id="asexample" class="table responsive table-striped table-bordered table-hover" style="width:100%">
        <thead>
          <tr>
            <th>No</th>
            <th>ID Pendapatan</th>
            <th>Tanggal</th>
            <th>Debit Rp.</th>
            <th>Kredit Rp.</th>
            <th>Keterangan</th>
            <th>Kode Akun</th>
          </tr>
        </thead>
        <tbody>
          <?php


            $query = mysqli_query($konek, "SELECT * FROM data_laporanpendapatan WHERE tanggal BETWEEN '$dari_tgl' AND '$sampai_tgl' ORDER BY id_pendapatan");
            $no = 1;
            while($rows = mysqli_fetch_array($query)){
           ?>

          <tr style="text-align:center;">
            <td><?php echo $no++;?></td>
            <td><?php echo $rows['id_pendapatan'];             ?></td>
            <td><?php echo $rows['tanggal'];                   ?></td>
            <td><?php echo number_format($rows['debit']);      ?></td>
            <td><?php echo number_format($rows['kredit']);     ?></td>
            <?php if ($rows['kredit'] == '0'){?>
                <td style="text-align:left;border-bottom: 0px solid black;"><?php echo $rows['keterangan'];?></td>
            <?php } else if($rows['debit'] == '0'){ ?>
                <td style="text-align:right;border-bottom: 0px solid black;"><?php echo $rows['keterangan'];?></td>
            <?php } ?>
            <td><?php echo $rows['kode_akun'];                 ?></td>
          </tr>

          <?php
            }
          ?>
        </tbody>
      </table>
    </div>

  </div>
</div>
