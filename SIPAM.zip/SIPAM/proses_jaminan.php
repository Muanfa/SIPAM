<?php
require "koneksi/koneksi.php";

session_start();

if ($_SESSION['accountofficer']) {
  $id_pegawai = $_SESSION['accountofficer'];
} else if ($_SESSION['manager']) {
  $id_pegawai = $_SESSION['manager'];
}

// Mengambil nilai nama pegawai dari data_pegawai, nanti di pindahakan nilai nama pegawai ke data_monitoring
$query      = mysqli_query($konek,"SELECT * FROM data_pegawai WHERE id_pegawai = '$id_pegawai'");
$data       = mysqli_fetch_array($query);
$dpt_nama   = $data['nama_depan'] . " " . $data['nama_belakang'];
$jabatan    = $data['jabatan'];

// Membuat id_monitoring baru
$hasil = mysqli_query($konek,"select max(id_monitoring) as idMaks from data_monitoring");
$data  = mysqli_fetch_array($hasil);
$idMax = $data['idMaks'];
$noUrut =  substr($idMax, 1, 5);
$noUrut++;
$format = "M";
$newID = $format . sprintf("%05s", $noUrut);

// Jika di Tekan tombol ubah (Ubah Pembiayaan) eksekusi code ini
if(isset($_GET['ubah_jaminan']))
{
  // ========== DATA JAMINAN ============
  $id_jaminan	      = $_GET['id_jam'];
  $jenis_jaminan	  = $_GET['jns_jam'];
  $dokumen_jaminan  = $_GET['dok_jam'];
  $lokasi_jaminan   = $_GET['almt_jam'];
  $nilai_jaminan    = $_GET['nilai_jam'];
  $pemilik_jaminan  = $_GET['pmlk_jam'];

  // ======================== Menyimpan Ke Database ============================
  // Memperbarui ke database sipam, dari tabel data_pembiayaan
  $query = mysqli_query($konek, "UPDATE data_jaminan SET
           id_jaminan       ='$id_jaminan',
           jenis_jaminan    ='$jenis_jaminan',
           dokumen_jaminan  ='$dokumen_jaminan',
           lokasi_jaminan   ='$lokasi_jaminan',
           nilai_jaminan    ='$nilai_jaminan',
           pemilik_jaminan  ='$pemilik_jaminan' WHERE id_jaminan = '$id_jaminan'"
  );
  if ($query) {

    // Menyimpan ke database sipam, dari tabel data_monitoring
    $query2 = mysqli_query($konek, "INSERT INTO data_monitoring VALUES(
      '$newID',
      '$jabatan',
      '$dpt_nama',
      'Mengubah Data Jaminan',
      Now(),
      '$id_pegawai')"
    );

    // BERHASIL
    if ($_SESSION['accountofficer']) {
      header('location:ao_ubah_jaminan.php?ok=berhasil');
    } else if ($_SESSION['manager']) {
      header('location:manager_ubah_jaminan.php?ok=berhasil');
    }
  }else {
    // GAGAL
    if ($_SESSION['accountofficer']) {
      header('location:ao_ubah_jaminan.php?ok=gagal');
    } else if ($_SESSION['manager']) {
      header('location:manager_ubah_jaminan.php?ok=gagal');
    }
  }
}
?>
