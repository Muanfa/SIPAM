<h1 class="text-center"><b>Data Pembiayaan</b></h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>Ubah Data Pembiayaan</b></h2>
  </div>
  <div class="panel-body">
    <!-- HR -->
    <table style="width:100%;">
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), black)"></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td><p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ&nbsp;اللهِ&nbsp;الرَّحْمَنِ&nbsp;الرَّحِيْمِ</p></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, black, rgba(0,0,0,0.75), rgba(0,0,0,0));"></td>
    </table>

    <form name='autoSumForm' action="proses_pembiayaan.php" method="get">


      <!-- Pembiayaan Di Ajukan -->
      <div class="col-sm-12" style="border-radius:15px;background-color:#f2f2f2;margin-bottom:5px;">
        <div style="padding:1px 0px 1px 0px;">
          <h2 class="text-center">Pembiayaan yang diajukan</h2>
          <table class="table" border=0>
            <!-- Mengambil Data Pembiayaan -->
            <?php
              // Fungsi ini menyembunyikan eror
              error_reporting(0);

              $id_pmb   = $_GET['id'];
              $query    = mysqli_query($konek, "SELECT * FROM data_pembiayaan WHERE id_pembiayaan ='$id_pmb'");
              $data     = mysqli_fetch_array($query);
             ?>
            <!-- ID Pembiayaan -->
            <tr>
                <th style="border:none;"><label class="control-label" style="margin-top:8px;">ID Pembiayaan :</label></th>
                <td style="border:none;"><input value="<?php echo $data['id_pembiayaan'];?>" name="id_pemb" type="text" class="form-control disabled" placeholder="ID Pembiayaan" readonly></td>
            </tr>
            <!-- Nama Nasabah -->
            <tr>
              <td style="border:none;"><label style="margin-top:8px;">Nama Nasabah :</label></td>
              <td style="border:none;"><input value="<?php echo $data['nama_nasabah'];?>"name="nma_nsb" type="text" class="form-control" placeholder="Nama Nasabah" readonly></td>
            </tr>
            <!-- Tanggal Daftar -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;">Tanggal Daftar :</label></th>
              <td style="border:none;"><input value="<?php echo $data['tgl_daftar'];?>" name="tgl_dft" type="text" class="form-control" placeholder="Tanggal Daftar" readonly></td>
            </tr>
            <!-- Kegunaan -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;">Kegunaan :</label></th>
              <td style="border:none;">
                <select name="kgnaan" class="form-control" id="sel1">
                  <option value="Konsumtif"   <?php if ($data['kegunaan']=="Konsumtif") { echo "selected=\"selected\""; }?>>Konsumtif</option>
                  <option value="Modal Kerja" <?php if ($data['kegunaan']=="Modal Kerja") { echo "selected=\"selected\""; }?>>Modal Kerja</option>
                  <option value="Investasi"   <?php if ($data['kegunaan']=="Investasi") { echo "selected=\"selected\""; }?>>Investasi</option>
                </select>
              </td>
            </tr>
            <!-- Obyek Pembiayaan -->
            <tr>
              <td colspan="2" style="border:none;"><input value="<?php echo $data['obyek_pembiayaan'];?>" name="oby_pemb" type="text" class="form-control" placeholder="Obyek Pembiayaan" required></td>
            </tr>
            <!-- Jenis Pembiayaan -->
            <tr>
              <td style="border:none;"><label style="margin-top:6px;">Jenis Pembiayaan :</label></td>
              <td style="border:none;"><input value="<?php echo $data['jenis_pembiayaan'];?>" name="jns_pemb" type="text" class="form-control" placeholder="Jenis Pembiayaan" readonly></td>
            </tr>
            <!-- Sistem Pembayaran -->
            <tr>
              <td style="border:none;"><label style="margin-top:6px;">Sistem Pembayaran :</label></td>
              <td style="border:none;"><input value="<?php echo $data['sistem_pembayaran'];?>" name="sist_pmbyrn" type="text" class="form-control" placeholder="Sistem Pembayaran" readonly></td>
            </tr>
            <!-- Jumlah Pembiayaan (ke nasabah)-->
            <tr>
              <td style="border:none;"><label style="margin-top:6px;">Jumlah Pembiayaan (ke nasabah):</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input value="<?php echo $data['jumlah_pembiayaan'];?>" style="border-radius:4px;" name="jml_pmbyn" onFocus="startCalc();" onBlur="stopCalc();" type="text" onKeyPress="return angkadanhuruf(event,'0123456789',this)" class="form-control" placeholder="Jumlah Pembiayaan" required>
                </div>
              </td>
            </tr>
            <!-- Margin  -->
            <tr>
              <td style="border:none;"><label style="margin-top:6px;">Margin :</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <!-- <input style="border-radius:4px;" name="margin" onFocus="startCalc();" onBlur="stopCalc();" type="text" onKeyPress="return angkadanhuruf(event,'0123456789.',this)" class="form-control" placeholder="Margin (%)" required> -->
                  <select name="margin" onFocus="startCalc();" onBlur="stopCalc();" class="form-control" id="sel1">
                    <option value="2"   <?php if ($data['margin']=="2") { echo "selected=\"selected\""; }?>>2</option>
                    <option value="2.5" <?php if ($data['margin']=="2.5") { echo "selected=\"selected\""; }?>>2.5</option>
                  </select>
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>%</b></span>
                </div>
                <p style="font-size:12px;margin-bottom:0px;">
                  <b><mark>Catatan</mark>:</b> Margin yang di BMT Berkah Madani hanya 2 atau 2.5 (%).
                </p>
              </td>
            </tr>
            <!-- Jangaka Waktu  -->
            <tr>
              <td style="border:none;"><label style="margin-top:6px;">Jangka Waktu :</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <input value="<?php echo $data['jangka_waktu'];?>" name="jngk_waktu" onFocus="startCalc();" onBlur="stopCalc();" type="text" maxlength="2" onKeyPress="return angkadanhuruf(event,'0123456789',this)" class="form-control" placeholder="Jangka Waktu (Perbulan)" style="border-radius:4px;" required>
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Bulan</b></span>
                </div>
              </td>
            </tr>
            <!-- Kas BMT (di kembalikkan)  -->
            <tr>
              <td style="border:none;"><label style="margin-top:6px;">Kas BMT (di Kembalikan) :</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input value="<?php echo $data['kas_bmt'];?>" style="border-radius:4px;" name="kas_bmt" onchange='tryNumberFormat(this.form.thirdBox);' type="text" class="form-control" placeholder="" readonly>
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>/Bulan</b></span>
                </div>
                <p style="font-size:12px;margin-bottom:0px;">
                  <b><mark>Perhitungan</mark>:</b> Kas BMT = Jumlah Pembiayaan / Jangka Waktu.
                </p>
              </td>
            </tr>
            <!-- Pendapatan Margin  -->
            <tr>
              <td style="border:none;"><label style="margin-top:6px;">Pendapatan Margin :</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input value="<?php echo $data['pendapatan_margin'];?>" name="pndptn_margin" style="border-radius:4px;" onchange='tryNumberFormat(this.form.thirdBox);' type="text" class="form-control" placeholder="" readonly>
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>/Bulan</b></span>
                </div>
                <p style="font-size:12px;margin-bottom:0px;">
                  <b><mark>Perhitungan</mark>:</b> Pendapatan Margin = Jumlah Pembiayaan x Margin.
                </p>
              </td>
            </tr>
            <!-- Total Jumlah Angsuran  -->
            <tr>
              <td style="border:none;"><label style="margin-top:7px;">Total Jumlah Angsuran :</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;"><script></script>
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input value="<?php echo $data['jumlah_angsuran'];?>" name="jml_angs" style="border-radius:4px;" onchange='tryNumberFormat(this.form.thirdBox)' type="text" class="form-control" placeholder="" readonly>
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>/Bulan</b></span>
                </div>
                <p style="font-size:12px;margin-bottom:0px;">
                  <b><mark>Perhitungan</mark>:</b> Total Jumlah Angsuran = Kas BMT + Pendapatan Margin.
                </p>
              </td>
            </tr>
            <!-- Total Jumlah Margin  -->
            <tr>
              <td style="border:none;"><label style="margin-top:6px;">Total Jumlah Margin :</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input value="<?php echo $data['total_margin']; ?>" name="total_margin" style="border-radius:4px;" onchange='tryNumberFormat(this.form.thirdBox);' type="text" class="form-control" placeholder="" readonly>
                </div>
                <p style="font-size:12px;margin-bottom:0px;">
                  <b><mark>Perhitungan</mark>:</b> Total Jumlah Margin = Pendapatan Margin x Jangka Waktu.
                </p>
              </td>
            </tr>
            <!-- Total Jumlah Pembiayaan  -->
            <tr>
              <td><label class="panel panel-default" style="margin-top:6px;margin-bottom:0px;">&nbsp;Total Jumlah Pembiayaan :&#160;</label></td>
              <td>
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input value="<?php echo $data['total_pembiayaan']; ?>" name="total_pmbyaan" style="border-radius:4px;" onchange='tryNumberFormat(this.form.thirdBox);' type="text" class="form-control" placeholder="" readonly>
                </div>
                <p style="font-size:12px;margin-bottom:0px;">
                  <b><mark>Perhitungan</mark>:</b> Sisa Setoran = Total Jumlah Pembiayaan + Total Jumlah Margin.
                </p>
              </td>
            </tr>
            <!-- Sisa Setoran  -->
            <tr>
              <td style="border:none;"><label style="margin-top:7px;">Sisa Setoran :</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input value="<?php echo $data['sisa_setoran'];?>" name="sisa_setoran" style="border-radius:4px;"  onchange='tryNumberFormat(this.form.thirdBox);' type="text" class="form-control" placeholder="" readonly>
                </div>
              </td>
            </tr>
          </table>
        </div>
      </div>


      <!-- Tombol Simpan -->
      <div class="col-sm-12">
        <div style="text-align:center;">
          <input class="btn btn-success" type="submit" value="SIMPAN" name="ubah_pembiayaan" style="margin-top:15px;" readonly></input>
        </div>
        <!-- Untuk Info Jika Simpan Berhasil / Gagal -->
        <?php
          if (isset($_GET['ok'])){
            $error=$_GET['ok'];
          }else{
            $error="";
          }

          $pesan="";
          if ($error=="berhasil"){
                // BERHASIL
                if ($_SESSION['accountofficer']) {
                  $pesan=  "<script>
                              swal('Berhasil!', 'Data Telah Diubah!', 'success')
                              .then((value) => {
                                window.location.href='ao_data_pembiayaan.php';
                              });
                            </script>";
                } else if ($_SESSION['manager']) {
                  $pesan=  "<script>
                              swal('Berhasil!', 'Data Telah Diubah!', 'success')
                              .then((value) => {
                                window.location.href='manager_data_pembiayaan.php';
                              });
                            </script>";
                }
          } else if ($error=="gagal") {
                // GAGAL
                if ($_SESSION['accountofficer']) {
                  $pesan=  "<script>
                              swal('Gagal!', 'Data Gagal Diubah Di Database!', 'error')
                              .then((value) => {
                                swal('Info!', 'Coba Periksa Di File proses_pembiayaan.php / kode halaman ini', 'info')
                                .then((value) => {
                                  window.location.href='ao_ubah_pembiayaan.php';
                                })
                              });
                            </script>";
                } else if ($_SESSION['manager']) {
                  $pesan=  "<script>
                              swal('Gagal!', 'Data Gagal Diubah Di Database!', 'error')
                              .then((value) => {
                                swal('Info!', 'Coba Periksa Di File proses_pembiayaan.php / kode halaman ini', 'info')
                                .then((value) => {
                                  window.location.href='manager_ubah_pembiayaan.php';
                                })
                              });
                            </script>";
                }
          }
          // Tampil Hasil Pesan
          echo "$pesan";
         ?>
      </div>
    </form>
  </div>
</div>
