<div class="judul-web">
  <div class="jarak-judul" >
    <h1 style="font-size:32px;">
      <a href="index.php" title="berkahmadani.co.id" class="dideketin2">berkahmadani<span style="color:#884dff;">.co.id</span></a>
    </h1>
  </div>
</div>
