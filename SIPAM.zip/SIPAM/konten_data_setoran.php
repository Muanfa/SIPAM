<h1 class="text-center"><b>Transaksi Setoran</b></h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>Data Transaksi Setoran</b></h2>
  </div>
  <div class="panel-body">
    <!-- HR -->
    <table style="width:100%;">
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), black)"></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td><p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ&nbsp;اللهِ&nbsp;الرَّحْمَنِ&nbsp;الرَّحِيْمِ</p></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, black, rgba(0,0,0,0.75), rgba(0,0,0,0));"></td>
    </table>

          <!-- MENAMPILKAN DATA TRANSAKSI -->
          <?php
            // Fungsi ini menyembunyikan eror
            error_reporting(0);
            $id_pembiayaan = $_GET['id'];

            // Mengambil nilai id, dari form manager_tambah_transksi.php setelah SELESAI UBAH
            $query = mysqli_query($konek, "SELECT * FROM data_transaksi WHERE id_pembiayaan = '$id_pembiayaan'");
            // $no = 1;
            $data = mysqli_fetch_array($query);
            $ambil_nama = $data['nama_nasabah'];

            // PESAN JIKA INFO LUNAS
            if (isset($_GET['info'])){
              $info = $_GET['info'];

              if ($info=="lunas"){
                    // LUNAS
                    if ($_SESSION['accountofficer']) {
                      $pesan  = "<script>
                                  swal('Berhasil!', 'Akad pembiayaan dari nasabah $ambil_nama Telah Lunas!', 'success')
                                  .then((value) => {
                                    window.location.href='ao_data_setoran.php?id=$id_pembiayaan';
                                  });
                                </script>";
                    } else if ($_SESSION['manager']) {
                      $pesan  = "<script>
                                  swal('Berhasil!', 'Akad pembiayaan dari nasabah $ambil_nama Telah Lunas!', 'success')
                                  .then((value) => {
                                    window.location.href='manager_data_setoran.php?id=$id_pembiayaan';
                                  });
                                </script>";
                    }
              }
              // Tampil Hasil Pesan
              echo "$pesan";
            }
           ?>
    <!-- Tombol Cetak -->
    <div>
      <button type='button' onclick="window.open('cetak_transaksi.php?id=<?php echo $data['id_pembiayaan'];?>','nama_window_pop_up','size=800,height=800,scrollbars=yes,resizeable=no')" class='btn btn-info btn-lg'>
        <span class="glyphicon glyphicon-print" style="color:black;"></span> Cetak</button>
      <hr>
    </td>

    <div class="container-fluid panel panel-default" style="padding-top:10px;padding-bottom:10px;">
      <table id="asexample" class="table responsive table-striped table-bordered table-hover" style="width:100%">
        <thead>
          <tr>
              <th>No</th>
              <th>ID Transaksi</th>
              <th>Nama Penyetor</th>
              <th>Nominal Nyetor</th>
              <th>Nama Nasabah</th>
              <th>Tanggal Setor</th>
              <th>Sisa Setor</th>
              <th>Pendapatan</th>
              <th>Obyek Pembiayaan</th>
              <th>ID Pembiayaan</th>
              <th>Total Pembiayaan</th>
          </tr>
        </thead>
        <tbody>

          <!-- Koddingan Lanjutan dari atas  -->
          <?php
            $query2 = mysqli_query($konek, "SELECT * FROM data_transaksi WHERE id_pembiayaan = '$id_pembiayaan'");
            $no = 1;
            while($rows = mysqli_fetch_array($query2)){
          ?>

          <tr style="text-align:center;">
            <td><?php echo $no++;?></td>
            <td><?php echo $rows['id_transaksi'];              ?></td>
            <td><?php echo $rows['nama_penyetor'];             ?></td>
            <td><?php echo $rows['nominal_nyetor'];            ?></td>
            <td><?php echo $rows['nama_nasabah'];              ?></td>
            <td><?php echo $rows['tanggal_setor'];             ?></td>
            <td><?php echo $rows['sisa_setor'];                ?></td>
            <td><?php echo $rows['pendapatan_bmt'];            ?></td>
            <td><?php echo $rows['obyek_pembiayaan'];          ?></td>
            <td><?php echo $rows['id_pembiayaan'];             ?></td>
            <td><?php echo $rows['total_pembiayaan'];          ?></td>
          </tr>

          <?php
            }
          ?>
        </tbody>
      </table>
      </div>
    </div>

  </div>
</div>
