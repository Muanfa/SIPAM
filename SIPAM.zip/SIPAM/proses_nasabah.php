<?php
require "koneksi/koneksi.php";

session_start();

if ($_SESSION['admin']) {
  $id_pegawai = $_SESSION['admin'];
} else if ($_SESSION['manager']) {
  $id_pegawai = $_SESSION['manager'];
}


// Membuat id_monitoring baru
$hasil = mysqli_query($konek,"select max(id_monitoring) as idMaks from data_monitoring");
$data  = mysqli_fetch_array($hasil);
$idMax = $data['idMaks'];
$noUrut =  substr($idMax, 1, 5);
$noUrut++;
$format = "M";
$newID = $format . sprintf("%05s", $noUrut);

// validasi umur
$tanggal_lahir    = $_GET['tgl_lhr'];
$tanggal_dipilih  = substr($tanggal_lahir, 6, 4);
$tanggal_sekarang = date('Y');
$selisih = $tanggal_sekarang - $tanggal_dipilih;


// Jika di Tekan tombol simpan (Tambah Nasabah) eksekusi code ini
if(isset($_GET['tambah_nasabah']))
{
  if ($selisih < 20) { // validasi umur
    if ($_SESSION['admin']) {
      header('location:admin_tambah_nasabah.php?ok=gagalumur');
    } else if ($_SESSION['manager']) {
      header('location:manager_tambah_nasabah.php?ok=gagalumur');
    }
  }else {
    // Mengambil nilai dari form manager_tambah_nasabah.php
    // ========= DATA NASABAH =========
    $id_nasabah		  	= $_GET['id_nas'];
    $nama_lengkap		  = $_GET['nama_lkp'];
    $alamat         	= $_GET['almt'];
    $no_telepon   		= $_GET['no_telp'];
    $jenis_kelamin    = $_GET['jk'];
    $tgl_lahir		  	= $_GET['tgl_lhr'];
    $identitas_diri   = $_GET['ident'];
    $email  	      	= $_GET['email'];
    $tgl_daftar  	  	= $_GET['tgl_dft'];
    $pekerjaan   	  	= $_GET['pkrjn'];
    $perusahaan		  	= $_GET['prshn'];
    $bidang_usaha   	= $_GET['bdng_usha'];
    $alamat_usaha	  	= $_GET['almt_prshn'];
    $nama_istri_suami = $_GET['nma_issu'];
    // Bikin Kondisi Jika TextBox yang nama istri suami tidak disi maka menjadi "Belum Menikah"
    if ($nama_istri_suami == "") {
      $hasil = "Belum Menikah";
    } else {
      $hasil = $nama_istri_suami;
    }

    $id_reknasabah  	= $_GET['id_reknsb'];
    $nama		          = $_GET['pmlk_rek'];
    $tanggal_buka     = $_GET['tgl_buka'];
    $saldo   		      = $_GET['nilai_jam'];
    $jenis_tabungan   = $_GET['jns_tbng'];
    $status		  	    = $_GET['status'];

    // =============== Menyimpan ke Database =====================================
    // ========= DATA NASABAH =========
    $query = mysqli_query($konek, "INSERT INTO data_nasabah VALUES(
      '$id_nasabah',
      '$nama_lengkap',
      '$alamat',
      '$no_telepon',
      '$jenis_kelamin',
      '$tgl_lahir',
      '$identitas_diri',
      '$email',
      '$tgl_daftar',
      '$pekerjaan',
      '$perusahaan',
      '$bidang_usaha',
      '$alamat_usaha',
      '$hasil',
      '$id_pegawai')"
    );

    // ========= DATA REKENING =========
    $query2 = mysqli_query($konek, "INSERT INTO data_reknasabah VALUES(
      '$id_reknasabah',
      '$nama',
      '$tanggal_buka',
      '$saldo',
      '$jenis_tabungan',
      '$status',
      '$id_nasabah')"
    );

    if ($query == $query2) {
      // Mengambil nilai nama pegawai dari data_pegawai, nanti di pindahakan nilai nama pegawai ke data_monitoring
      $query3     = mysqli_query($konek,"SELECT * FROM data_pegawai WHERE id_pegawai = '$id_pegawai'");
      $data       = mysqli_fetch_array($query3);
      $dpt_nama   = $data['nama_depan'] . " " . $data['nama_belakang'];
      $jabatan    = $data['jabatan'];

      // Menyimpan ke database sipam, dari tabel data_monitoring
      $query4 = mysqli_query($konek, "INSERT INTO data_monitoring VALUES(
      '$newID',
      '$jabatan',
      '$dpt_nama',
      'Daftar Nasabah Baru',
      Now(),
      '$id_pegawai')"
      );
      // BERHASIL
      if ($_SESSION['admin']) {
        header('location:admin_tambah_nasabah.php?ok=berhasil');
      } else if ($_SESSION['manager']) {
        header('location:manager_tambah_nasabah.php?ok=berhasil');
      }
    }else {
      // GAGAL
      if ($_SESSION['admin']) {
        header('location:admin_tambah_nasabah.php?ok=gagal');
      } else if ($_SESSION['manager']) {
        header('location:manager_tambah_nasabah.php?ok=gagal');
      }
    }
  }
}

// Jika di Tekan tombol ubah (Ubah Pegawai) eksekusi code ini
if(isset($_GET['ubah_nasabah']))
{
  // Mengambil nilai dari form manager_ubah_nasabah.php
  // ========= DATA NASABAH =========
  $id_nasabah		  	= $_GET['id_nas'];
  $nama_lengkap		  = $_GET['nama_lkp'];
  $alamat         	= $_GET['almt'];
  $no_telepon   		= $_GET['no_telp'];
  $jenis_kelamin    = $_GET['jk'];
  $tgl_lahir		  	= $_GET['tgl_lhr'];
  $identitas_diri   = $_GET['ident'];
  $email  	      	= $_GET['email'];
  $tgl_daftar  	  	= $_GET['tgl_dft'];
  $pekerjaan   	  	= $_GET['pkrjn'];
  $perusahaan		  	= $_GET['prshn'];
  $bidang_usaha   	= $_GET['bdng_usha'];
  $alamat_usaha	  	= $_GET['almt_prshn'];
  $nama_istri_suami = $_GET['nma_issu'];

  if ($nama_istri_suami == "") {
    $hasil = "Belum Menikah";
  } else {
    $hasil = $nama_istri_suami;
  }

  // ======================== Menyimpan Ke Database ============================
  // Memperbarui ke database sipam, dari tabel data_nasabah
  $query = mysqli_query($konek, "UPDATE data_nasabah SET
           id_nasabah       ='$id_nasabah',
           nama             ='$nama_lengkap',
           alamat           ='$alamat',
           no_telp          ='$no_telepon',
           jenis_kelamin    ='$jenis_kelamin',
           tanggal_lahir    ='$tgl_lahir',
           identitas_diri   ='$identitas_diri',
           email            ='$email',
           tanggal_daftar   ='$tgl_daftar',
           pekerjaan        ='$pekerjaan',
           perusahaan       ='$perusahaan',
           bidang_usaha     ='$bidang_usaha',
           alamat_usaha     ='$alamat_usaha',
           nama_istri_suami ='$hasil',
           id_pegawai       ='$id_pegawai' WHERE id_nasabah='$id_nasabah'"
  );
  if ($query) {
    // Mengambil nilai nama pegawai dari data_pegawai, nanti di pindahakan nilai nama pegawai ke data_monitoring
    $query2     = mysqli_query($konek,"SELECT * FROM data_pegawai WHERE id_pegawai = '$id_pegawai'");
    $data       = mysqli_fetch_array($query2);
    $dpt_nama   = $data['nama_depan'] . " " . $data['nama_belakang'];
    $jabatan    = $data['jabatan'];

    // Menyimpan ke database sipam, dari tabel data_monitoring
    $query3 = mysqli_query($konek, "INSERT INTO data_monitoring VALUES(
      '$newID',
      '$jabatan',
      '$dpt_nama',
      'Mengubah Data Nasabah',
      Now(),
      '$id_pegawai')"
    );

    // BERHASIL
    if ($_SESSION['admin']) {
      header('location:admin_ubah_nasabah.php?ok=berhasil');
    } else if ($_SESSION['manager']) {
      header('location:manager_ubah_nasabah.php?ok=berhasil');
    }
  }else {
    // GAGAL
    if ($_SESSION['admin']) {
      header('location:admin_ubah_nasabah.php?ok=gagal');
    } else if ($_SESSION['manager']) {
      header('location:manager_ubah_nasabah.php?ok=gagal');
    }
  }
}

// Jika di Tekan tombol ubah (Ubah Rekening) eksekusi code ini
if(isset($_GET['ubah_reknasabah']))
{
  // Mengambil nilai dari form manager_ubah_rekening.php
  $id_reknasabah  	= $_GET['id_reknsb'];
  $nama		          = $_GET['pmlk_rek'];
  $tanggal_buka     = $_GET['tgl_buka'];
  $saldo   		      = $_GET['nilai_jam'];
  $jenis_tabungan   = $_GET['jns_tbng'];
  $status		  	    = $_GET['status'];
  $id_nasabah  	    = $_GET['id_nsb'];

  // ======================== Menyimpan Ke Database ============================
  // Memperbarui ke database sipam, dari tabel data_nasabah
  $query = mysqli_query($konek, "UPDATE data_reknasabah SET
           id_reknasabah    ='$id_nasabah',
           nama             ='$nama_lengkap',
           tanggal_buka     ='$alamat',
           saldo            ='$no_telepon',
           jenis_tabungan   ='$jenis_kelamin',
           status           ='$tgl_lahir',
           id_nasabah       ='$id_nasabah' WHERE $id_reknasabah='$id_reknasabah'"
  );

  if ($query) {
    // Mengambil nilai nama pegawai dari data_pegawai, nanti di pindahakan nilai nama pegawai ke data_monitoring
    $query2     = mysqli_query($konek,"SELECT * FROM data_pegawai WHERE id_pegawai = '$id_pegawai'");
    $data       = mysqli_fetch_array($query2);
    $dpt_nama   = $data['nama_depan'] . " " . $data['nama_belakang'];
    $jabatan    = $data['jabatan'];

    // Menyimpan ke database sipam, dari tabel data_monitoring
    $query3 = mysqli_query($konek, "INSERT INTO data_monitoring VALUES(
      '$newID',
      '$jabatan',
      '$dpt_nama',
      'Mengubah Data Rekening',
      Now(),
      '$id_pegawai')"
    );

    // BERHASIL
    if ($_SESSION['admin']) {
      header('location:admin_ubah_reknasabah.php?ok=berhasil');
    } else if ($_SESSION['manager']) {
      header('location:manager_ubah_reknasabah.php?ok=berhasil');
    }
  }else {
    // GAGAL
    if ($_SESSION['admin']) {
      header('location:admin_ubah_reknasabah.php?ok=gagal');
    } else if ($_SESSION['manager']) {
      header('location:manager_ubah_reknasabah.php?ok=gagal');
    }
  }
}
?>
