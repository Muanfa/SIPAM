<?php
  require "koneksi/koneksi.php";

  session_start();
  ob_start();
 ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Nama Title -->
    <title>Berkah Madani</title>
    <!-- Ikon Gambar Title -->
    <link rel="icon" href="gambar/logo_BM.png" type="png">
  </head>
  <body>
    <!-- Header Cetak -->
    <table style="margin-top:20px;">
      <tr>
        <td style="width:500px;">
          <img src="gambar/Logo_BM1.png" alt="" style="float:left;"/>
          <p style="margin-top:-1px;padding-left:10px;">Koperasi Jasa Keuangan Syariah</p>
          <p style="margin-top:-25px;padding-left:10px;"><b>Berkah</b> Madani</p>
          <p style="margin-top:-15px;">Berkah Madani</p>
        </td>
        <td>
          <p style="font-family:Agency FB;text-align:right;"><b>Aplikasi Pembiayaan</b></p>
        </td>
      </tr>
      <tr style="padding:0px;margin-top:-40px;">
        <hr>
      </tr>
    </table>

    <!-- Isi Konten Cetak -->
    <?php
      $id_nas = $_GET['id'];
      $query  = mysqli_query($konek, "SELECT * FROM data_jaminan WHERE id_nasabah = '$id_nas'");
      $data   = mysqli_fetch_array($query);
     ?>

    <div style="margin-top:-80px;">
      <h3 style="text-align:center;">Data Jaminan</h3>
    </div>

    <table border="0" style="margin-left:50px;margin-top:-30px;">
        <tr>
          <td>Pemilik Jaminan</td>
          <td>:</td>
          <td><?php echo $data['pemilik_jaminan']; ?></td>
        </tr>
        <tr>
          <td>Jenis Jaminan</td>
          <td>:</td>
          <td><?php echo $data['jenis_jaminan']; ?></td>
        </tr>
        <tr>
          <td>Dokumen Jaminan</td>
          <td>:</td>
          <td><?php echo $data['dokumen_jaminan']; ?></td>
        </tr>
         <tr>
          <td>Lokasi Jaminan</td>
          <td>:</td>
          <td><?php echo $data['lokasi_jaminan']; ?></td>
        </tr>
        <tr>
          <td>Nilai Jaminan</td>
          <td>:</td>
          <td>Rp. <?php echo number_format($data['nilai_jaminan']); ?></td>
        </tr>
    </table>


    <p>Data yang tertera di atas adalah Data Jaminan dari Nasabah : <u><?php echo $data['pemilik_jaminan']; ?></u>, di KSPPS BMT Berkah Madani ini.</p>
      <?php
        // Mengambil Tanggal Sekarang
        // $hari = date('d');
        // $hari = $hari - 1;
        // $tgl = date('-m-Y');
        // $hari_ini = $hari . $tgl;
        $tgl = date('d-m-Y');

        echo "<p align='right'>Depok, ".$tgl."
        <img src='gambar/bm_ttd.png' width='120' style='pointer-events:none;'>
        ( Berkah Madani )</p>";
       ?>
  </body>
</html>

<?php
  $filename="jmn_".$data['pemilik_jaminan'].".pdf"; //ubah untuk menentukan nama file pdf yang dihasilkan nantinya
  //==========================================================================================================
  //Copy dan paste langsung script dibawah ini,untuk mengetahui lebih jelas tentang fungsinya silahkan baca-baca tutorial tentang HTML2PDF
  //==========================================================================================================
  $content = ob_get_clean();
  $content = '<page style="font-family: ">'.nl2br($content).'</page>';
   require_once(dirname(__FILE__).'/html2pdf/html2pdf.class.php');
   try
   {
    $html2pdf = new HTML2PDF('P','A4','en', false, 'ISO-8859-15', array(20, -10, 20, -1000));
    $html2pdf->setDefaultFont('Arial');
    $html2pdf->writeHTML($content, isset($_GET['vuehtml']));
    $html2pdf->Output($filename);
   }
   catch(HTML2PDF_exception $e) { echo $e; }
?>
