<h1 class="text-center"><b>Pegawai</b></h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>Ubah Data Pegawai</b></h2>
  </div>
  <div class="panel-body">
    <!-- HR -->
    <table style="width:100%;">
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), black)"></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td><p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ&nbsp;اللهِ&nbsp;الرَّحْمَنِ&nbsp;الرَّحِيْمِ</p></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, black, rgba(0,0,0,0.75), rgba(0,0,0,0));"></td>
    </table>

    <form action="proses_pegawai.php" method="get">
      <div class="" style="border-radius:15px;background-color: #f2f2f2;}">
        <div class="col-sm-12" >


          <table class="table" border=0>
            <?php
              // Fungsi ini menyembunyikan eror
              error_reporting(0);
              // Mengambil nilai id, dari form manager_data_pegawai.php dari tombol UBAH
              $id	  	= $_GET['id'];
              $query	= mysqli_query($konek,"SELECT * FROM data_pegawai WHERE id_pegawai='$id'");
              $data	  = mysqli_fetch_array($query);
            ?>
            <!-- ID Pegawai -->
            <tr>
                <th style="border:none;"><label class="control-label" style="margin-top:8px;">ID Pegawai :</label></th>
                <td style="border:none;"><input name="id_peg" type="text" class="form-control disabled" placeholder="ID Pegawai" readonly value="<?php echo $data['id_pegawai'];?>"></td>
            </tr>
            <!-- Nama Depan -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;" >Nama Depan :</label></th>
              <td style="border:none;"><input name="nama_dpn" type="text" class="form-control" placeholder="Nama Depan" required value="<?php echo $data['nama_depan'];?>"></td>
            </tr>
            <!-- Nama Belakang -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;" >Nama Belakang :</label></th>
              <td style="border:none;"><input name="nama_blkng" type="text" class="form-control" placeholder="Nama Belakang" required value="<?php echo $data['nama_belakang'];?>"></td>
            </tr>
            <!-- Jenis Kelamin -->
            <tr>
                <th style="border:none;">Jenis Kelamin :</td>
                <td style="border:none;">
                  <label class="radio-inline" style="text-align:right;">
                    <input type="radio" name="jk" value="Pria" <?php if ($data['jenis_kelamin']=="Pria") { echo "checked=\"checked\""; } ?>>Pria
                  </label>
                  <label class="radio-inline" >
                    <input type="radio" name="jk" value="Wanita" <?php if ($data['jenis_kelamin']=="Wanita") { echo "checked=\"checked\""; } ?> style="text-align:right;">Wanita
                  </label>
                </td>
            </tr>
            <!-- Identitas Diri -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;" >Identitas Diri :</label></th>
              <td style="border:none;">
                <select name="ident" class="form-control" id="sel1">
                  <option value="KTP"     <?php if ($data['identitas_diri']=="KTP") { echo "selected=\"selected\""; } ?>>KTP</option>
                  <option value="SIM"     <?php if ($data['identitas_diri']=="SIM") { echo "selected=\"selected\""; } ?>>SIM</option>
                  <option value="Paspor"  <?php if ($data['identitas_diri']=="Paspor") { echo "selected=\"selected\""; } ?>>Paspor</option>
                  <option value="Lainnya" <?php if ($data['identitas_diri']=="Lainnya") { echo "selected=\"selected\""; } ?>>Lainnya</option>
                </select>
              </td>
            </tr>
            <!-- Tanggal Lahir -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;" >Tanggal Lahir :</label></th>
              <td style="border:none;">
                <div class="form-group" style="width:100%;margin-bottom:2px;">
                  <div class='input-group date' id='datetimepicker2'>
                    <input type='text' name="tgl_lhr" value="<?php echo $data['tanggal_lahir'];?>" class="form-control" style="pointer-events: none;" placeholder="Tanggal Lahir" required>
                    <span class="input-group-addon">
                      <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                  </div>
                </div>
              </td>
            </tr>
            <!-- Alamat -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;" >Alamat :</label></th>
              <td style="border:none;"><textarea name="almt" class="form-control" rows="5" style="resize:none;" placeholder="Alamat" required><?php echo $data['alamat'] ?></textarea></td>
            </tr>
            <!-- No Telpon -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;" >No Telp :</label></th>
              <td style="border:none;"><input name="no_telp" value="<?php echo $data['nomer_telepon'];?>" type="number" min="0" maxlength="8" class="form-control" placeholder="Nomer Telepon" required></td>
            </tr>
            <!-- Email -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;" >Email :</label></th>
              <td style="border:none;"><input name="email" value="<?php echo $data['email'];?>" type="email" id="email"  class="form-control" placeholder="Email" required></td>
            </tr>
            <!-- Tanggal Daftar -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;">Tanggal Daftar :</label></th>
              <td style="border:none;"><input name="tgl_dft" value="<?php echo $data['tanggal_daftar'];?>" type="text" class="form-control" placeholder="Tanggal Daftar" readonly></td>
            </tr>
            <!-- Jabatan -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;" >Jabatan :</label></th>
              <td style="border:none;">
                <select name="jbt" class="form-control" id="sel1">
                  <option value="Admin"   <?php if ($data['jabatan']=="Admin") { echo "selected=\"selected\""; } ?>>Admin</option>
                  <option value="Account Officer" <?php if ($data['jabatan']=="Account Officer") { echo "selected=\"selected\""; } ?>>Pegawai</option>
                  <option value="Manager" <?php if ($data['jabatan']=="Manager") { echo "selected=\"selected\""; } ?>>Manager</option>
                </select>
              </td>
            </tr>
            <!-- Username -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;" >Username :</label></th>
              <td style="border:none;"><input name="usr" value="<?php echo $data['username'];?>" type="text" onKeyPress="return angkadanhuruf(event,'abcdefghijklmnopqrstuvwxyz0123456789',this)" class="form-control" placeholder="Username Baru" required></td>
            </tr>
            <!-- Password -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;" >Password :</label></th>
              <td style="border:none;"><input name="pwd" value="<?php echo $data['deskripsi'];?>" type="text" onKeyPress="return angkadanhuruf(event,'abcdefghijklmnopqrstuvwxyz0123456789',this)" maxlength="8" minlength="3" class="form-control" placeholder="Password Baru (Max 8)" required>
              <p style="font-size:12px;margin-left:10px;">
                <strong>Catatan:</strong> Password Minimal 3 Karakter
              </p></td>
            </tr>
          </table>
        </div>
        <!-- Tombol Simpan -->
        <div class=""style="text-align:center;">
          <input class="btn btn-success" type="submit" value="UBAH" name="ubah_pegawai" readonly></input>
        </div><br>
        <!-- Untuk Info Jika Simpan Berhasil atau Gagal-->
        <?php
          if (isset($_GET['ok'])){
            $error=$_GET['ok'];
          }else{
            $error="";
          }

          $pesan="";
          if ($error=="berhasil"){
                // BERHASIL
                if ($_SESSION['admin']) {
                  $pesan=  "<script>
                              swal('Berhasil!', 'Data Telah Diubah!', 'success')
                              .then((value) => {
                                window.location.href='admin_data_pegawai.php';
                              });
                            </script>";
                } else if ($_SESSION['manager']) {
                  $pesan=  "<script>
                              swal('Berhasil!', 'Data Telah Diubah!', 'success')
                              .then((value) => {
                                window.location.href='manager_data_pegawai.php';
                              });
                            </script>";
                }
          }else if ($error=="gagal") {
                if ($_SESSION['admin']) {
                  $pesan=  "<script>
                              swal('Gagal!', 'Data Gagal Diubah Di Database!', 'error')
                              .then((value) => {
                                swal('Info!', 'Coba Periksa Di File proses_pegawai.php', 'info')
                                .then((value) => {
                                  window.location.href='admin_ubah_pegawai.php';
                                })
                              });
                            </script>";
                } else if ($_SESSION['manager']) {
                  $pesan=  "<script>
                              swal('Gagal!', 'Data Gagal Diubah Di Database!', 'error')
                              .then((value) => {
                                swal('Info!', 'Coba Periksa Di File proses_pegawai.php', 'info')
                                .then((value) => {
                                  window.location.href='manager_ubah_pegawai.php';
                                })
                              });
                            </script>";
                }
          }
        ?>
        <?php
          echo "$pesan";
        ?>
      </div>
    </form>
  </div>
</div>
