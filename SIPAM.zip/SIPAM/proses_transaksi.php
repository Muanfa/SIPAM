<?php
require "koneksi/koneksi.php";

session_start();

if ($_SESSION['accountofficer']) {
  $id_pegawai = $_SESSION['accountofficer'];
} else if ($_SESSION['manager']) {
  $id_pegawai = $_SESSION['manager'];
}

// Mengambil nilai nama pegawai dari data_pegawai, nanti di pindahakan nilai nama pegawai ke data_monitoring
$query      = mysqli_query($konek, "SELECT * FROM data_pegawai WHERE id_pegawai = '$id_pegawai'");
$ambil      = mysqli_fetch_array($query);
$dpt_nama   = $ambil['nama_depan'] . " " . $ambil['nama_belakang'];
$jabatan    = $ambil['jabatan'];

// Membuat id_monitoring baru
$qry              = mysqli_query($konek, "SELECT max(id_monitoring) AS idMaks FROM data_monitoring");
$data             = mysqli_fetch_array($qry);
$idMax            = $data['idMaks'];
$noUrut           = substr($idMax, 1, 5);
$noUrut++;
$format           = "M";
$newID_monitoring = $format . sprintf("%05s", $noUrut);

// Membuat id_aruskas baru
$qry           = mysqli_query($konek, "SELECT max(id_aruskas) AS idMaks FROM data_laporanaruskas");
$data          = mysqli_fetch_array($qry);
$idMax         = $data['idMaks'];
$noUrut        = substr($idMax, 1, 5);
$noUrut++;
$format        = "A";
$newID_aruskas = $format . sprintf("%05s", $noUrut);
$noUrut        = substr($newID_aruskas, 1, 5);
$noUrut++;
$format         = "A";
$newID_aruskas2 = $format . sprintf("%05s", $noUrut);
$noUrut        = substr($newID_aruskas2, 1, 5);
$noUrut++;
$format         = "A";
$newID_aruskas3 = $format . sprintf("%05s", $noUrut);

// Membuat id_tranrek baru
$qry           = mysqli_query($konek, "SELECT max(id_tranrek) AS idMaks FROM data_laporanreknasabah");
$data          = mysqli_fetch_array($qry);
$idMax         = $data['idMaks'];
$noUrut        = substr($idMax, 1, 5);
$noUrut++;
$format        = "T";
$newID_Reknsb  = $format . sprintf("%05s", $noUrut);

// Membuat id_pendapatan baru
$qry              = mysqli_query($konek, "SELECT max(id_pendapatan) AS idMaks FROM data_laporanpendapatan");
$data             = mysqli_fetch_array($qry);
$idMax            = $data['idMaks'];
$noUrut           = substr($idMax, 1, 5);
$noUrut++;
$format           = "P";
$newID_pendapatan = $format . sprintf("%05s", $noUrut);
$noUrut           = substr($newID_pendapatan, 1, 5);
$noUrut++;
$format            = "P";
$newID_pendapatan2 = $format . sprintf("%05s", $noUrut);



// Jika di Tekan tombol simpan (Tambah Pegawai) eksekusi code ini
if(isset($_GET['tambah_transaksi']))
{
  // Mengambil nilai dari form manager_tambah_transaksi.php
  $id_transaksi	     = $_GET['id_trnsk'];
  $nominal_nyetor    = $_GET['no_set'];
  $nama_penyetor     = $_GET['nama_pen'];
  $tanggal_setor     = $_GET['tgl_set'];
  $sisa_setor        = $_GET['sisa_set'];
  $obyek_pembiayaan  = $_GET['oby_pmb'];
  $nama_nasabah 		 = $_GET['nama_nas'];
  $pendapatan_bmt    = $_GET['pnd_mrg'];
  $total_pembiayaan  = $_GET['ttl_pmb'];
  $id_pembiayaan	   = $_GET['id_pmb'];
  $id_nasabah   	   = $_GET['id_nsb'];

  $kas_bmt   	       = $_GET['kas_bmt'];

  // Mengurangi Nominal Saldo Rekening Nasabah
  $query       = mysqli_query($konek, "SELECT * FROM data_reknasabah WHERE id_nasabah = '$id_nasabah'");
  $data        = mysqli_fetch_array($query);
  $saldo       = $data['saldo'];
  $total_saldo = $saldo - $nominal_nyetor;

  // Apakah Sisa Saldo masih tersisa Rp 50rb, jika saldo dibawah 50rb maka lakukan transaksi
  if ($total_saldo <= 50000) {
    if ($_SESSION['accountofficer']) {
      header('location:ao_tambah_transaksi.php?ok=gagal&info=saldo&id='.$id_pembiayaan);
    } else if ($_SESSION['manager']) {
      header('location:manager_tambah_transaksi.php?ok=gagal&info=saldo&id='.$id_pembiayaan);
    }
  }else{
    // ========================== Menyimpan ke Database ==========================
    // Menyimpan ke data_transaksi
    $query = mysqli_query($konek, "INSERT INTO data_transaksi VALUES (
      '$id_transaksi',
      '$nominal_nyetor',
      '$nama_penyetor',
      '$tanggal_setor',
      '$sisa_setor',
      '$obyek_pembiayaan',
      '$nama_nasabah',
      '$pendapatan_bmt',
      '$total_pembiayaan',
      '$id_pembiayaan',
      '$id_nasabah')"
    );

    if ($query) {
      // Memperbarui ke database sipam, dari tabel data_reknasabah
      $query1 = mysqli_query($konek, "UPDATE data_reknasabah SET saldo = '$total_saldo' WHERE id_nasabah = '$id_nasabah'");

      // Memperbarui(mengurangi) Sisa Setoran
      $query2 = mysqli_query($konek, "UPDATE data_pembiayaan SET sisa_setoran = '$sisa_setor' WHERE id_pembiayaan = '$id_pembiayaan'");

      // Mengubah Status Menjadi "Lunas" jika sudah habis sisa setorannya
      if($sisa_setor == '0'){
        $query3 = mysqli_query($konek, "UPDATE data_pembiayaan SET status = 'Lunas' WHERE id_pembiayaan = '$id_pembiayaan'");
      }

      // Menyimpan ke Laporan Rekening Nasabah
      $query4 = mysqli_query($konek, "INSERT INTO data_laporanreknasabah VALUES (
        '$newID_Reknsb',
        '$tanggal_setor',
        '0',
        '$nominal_nyetor',
        'Melakukan Setoran $obyek_pembiayaan',
        '$total_saldo',
        '$id_nasabah')"
      );


      // Menyimpan ke Laporan Arus Kas
      $query4 = mysqli_query($konek, "INSERT INTO data_laporanaruskas VALUES (
        '$newID_aruskas',
        '$tanggal_setor',
        '$kas_bmt',
        '0',
        'Kas BMT BM',
        '1-1101',
        '$id_pembiayaan',
        '$id_transaksi')"
        );
        $query4 = mysqli_query($konek, "INSERT INTO data_laporanaruskas VALUES (
        '$newID_aruskas2',
        '$tanggal_setor',
        '$pendapatan_bmt',
        '0',
        'Pendapatan Murabahah',
        '1-1201',
        '$id_pembiayaan',
        '$id_transaksi')"
        );
        $query5 = mysqli_query($konek, "INSERT INTO data_laporanaruskas VALUES (
        '$newID_aruskas3',
        '$tanggal_setor',
        '0',
        '$nominal_nyetor',
        'Piutang Murabahah',
        '1-1201',
        '$id_pembiayaan',
        '$id_transaksi')"
        );

        // Menyimpan ke Laporan Pendapatan
        $query6 = mysqli_query($konek, "INSERT INTO data_laporanpendapatan VALUES (
        '$newID_pendapatan',
        '$tanggal_setor',
        '$pendapatan_bmt',
        '0',
        'Kas BMT BM',
        '5-1001',
        '$id_transaksi')"
        );
        $query7 = mysqli_query($konek, "INSERT INTO data_laporanpendapatan VALUES (
        '$newID_pendapatan2',
        '$tanggal_setor',
        '0',
        '$pendapatan_bmt',
        'Pendapatan Murabahah',
        '1-1201',
        '$id_transaksi')"
        );

        // Menyimpan ke database sipam, dari tabel data_monitoring
        $query8 = mysqli_query($konek, "INSERT INTO data_monitoring VALUES (
        '$newID_monitoring',
        '$jabatan',
        '$dpt_nama',
        'Buat Transaksi Setoran Baru',
        Now(),
        '$id_pegawai')"
        );

        // BERHASIL
        // Validasi jika setoran 0
        if($sisa_setor == '0'){ //Info Berhasil & Lunas
          if ($_SESSION['accountofficer']) {
            header('location:ao_tambah_transaksi.php?ok=berhasil&info=lunas');
          } else if ($_SESSION['manager']) {
            header('location:manager_tambah_transaksi.php?ok=berhasil&info=lunas');
          }
        }else { // Info Berhasil
          if ($_SESSION['accountofficer']) {
            header('location:ao_tambah_transaksi.php?ok=berhasil');
          } else if ($_SESSION['manager']) {
            header('location:manager_tambah_transaksi.php?ok=berhasil');
          }
        }
      } else {
        // GAGAL
        if ($_SESSION['accountofficer']) {
          header('location:ao_tambah_transaksi.php?ok=gagal');
        } else if ($_SESSION['manager']) {
          header('location:manager_tambah_transaksi.php?ok=gagal');
        }
      }
  }
}

?>
