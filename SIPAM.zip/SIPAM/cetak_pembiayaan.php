<?php
  require "koneksi/koneksi.php";

  session_start();
  ob_start();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Nama Title -->
    <title>Berkah Madani</title>
    <!-- Ikon Gambar Title -->
    <link rel="icon" href="gambar/logo_BM.png" type="png">
  </head>
  <body>
    <!-- Header Cetak -->
    <table style="margin-top:20px;">
      <tr>
        <td style="width:500px;">
          <img src="gambar/Logo_BM1.png" alt="" style="float:left;"/>
          <p style="margin-top:-1px;padding-left:10px;">Koperasi Jasa Keuangan Syariah</p>
          <p style="margin-top:-25px;padding-left:10px;"><b>Berkah</b> Madani</p>
          <p style="margin-top:-15px;">Berkah Madani</p>
        </td>
        <td>
          <p style="font-family:Agency FB;text-align:right;"><b>Aplikasi Pembiayaan</b></p>
        </td>
      </tr>
      <tr style="padding:0px;margin-top:-40px;">
        <hr>
      </tr>
    </table>

    <!-- Isi Konten Cetak -->
    <?php
      $id_nas = $_GET['id'];
      $query  = mysqli_query($konek, "SELECT * FROM data_pembiayaan WHERE id_pembiayaan = '$id_nas'");
      $data  = mysqli_fetch_array($query);
     ?>

     <div style="margin-top:-80px;">
       <h3 style="text-align:center;">Data Pembiayaan</h3>
     </div>

    <table border="0" style="margin-left:50px;margin-top:-30px;">
        <tr>
          <td>Nama Nasabah</td>
          <td>:</td>
          <td><?php echo $data['nama_nasabah']; ?></td>
        </tr>
        <tr>
          <td>Tangal Daftar</td>
          <td>:</td>
          <td><?php echo $data['tgl_daftar']; ?></td>
        </tr>
        <tr>
          <td>Kegunaan</td>
          <td>:</td>
          <td><?php echo $data['kegunaan']; ?></td>
        </tr>
         <tr>
          <td>Obyek Pembiayaan</td>
          <td>:</td>
          <td><?php echo $data['obyek_pembiayaan']; ?></td>
        </tr>
        <tr>
          <td>Jenis Pembiayaan</td>
          <td>:</td>
          <td><?php echo $data['jenis_pembiayaan']; ?></td>
        </tr>
        <tr>
          <td>Sistem Pembayaran</td>
          <td>:</td>
          <td><?php echo $data['sistem_pembayaran']; ?></td>

        </tr>
        <tr>
          <td>Jumlah Pembiayaan</td>
          <td>:</td>
          <td>Rp. <?php echo number_format($data['jumlah_pembiayaan']); ?></td>
        </tr>
        <tr>
          <td>Margin</td>
          <td>:</td>
          <td><?php echo $data['margin']; ?> %</td>
        </tr>
        <tr>
          <td>Jangka Waktu</td>
          <td>:</td>
          <td><?php echo $data['jangka_waktu']; ?></td>
        </tr>
        <tr>
          <td>Kas BMT (di keluarkan)</td>
          <td>:</td>
          <td>Rp. <?php echo number_format($data['kas_bmt']); ?></td>
        </tr>
        <tr>
          <td>Pendapatan Margin</td>
          <td>:</td>
          <td>Rp. <?php echo number_format($data['pendapatan_margin']); ?></td>
        </tr>
        <tr>
          <td><b><u>Jumlah Angsuran</u></b></td>
          <td>:</td>
          <td>Rp. <?php echo number_format($data['jumlah_angsuran']); ?> /Bulan</td>
        </tr>
        <tr>
          <td>Total Jumlah Margin</td>
          <td>:</td>
          <td>Rp. <?php echo number_format($data['total_margin']); ?></td>
        </tr>
        <tr>
          <td>Total Jumlah Pembiayaan (di kembalikan)</td>
          <td>:</td>
          <td>Rp. <?php echo number_format($data['total_pembiayaan']); ?></td>
        </tr>
        <tr>
          <td>Sisa Setoran</td>
          <td>:</td>
          <td>Rp. <?php echo number_format($data['sisa_setoran']); ?></td>
        </tr>
        <tr>
          <td>Status</td>
          <td>:</td>
          <td><?php echo $data['status']; ?></td>
        </tr>
    </table>

    <p>
      <b>*Catatan :</b>  Margin yang di BMT Berkah Madani hanya 2 atau 2.5 (%).
    </p>

    <h5 style="margin-top:-30px;">*Perhitungan :</h5>
    <ul style="margin-top:-45px;">
      <li>Kas BMT = Jumlah Pembiayaan / Jangka Waktu.</li>
      <li>Pendapatan Margin = Jumlah Pembiayaan x Margin.</li>
      <li>Total Jumlah Angsuran = Kas BMT + Pendapatan Margin.</li>
      <li>Total Jumlah Margin = Pendapatan Margin x Jangka Waktu.</li>
      <li>Total Jumlah Pembiayaan = Jumlah Pembiayaan + Total Jumlah Margin.</li>
    </ul>


    <p>Data yang tertera di atas adalah Data Pembiayaan dari Nasabah : <u><?php echo $data['nama_nasabah']; ?></u>, di KSPPS BMT Berkah Madani ini.</p>
      <?php
      // Mengambil Tanggal Sekarang
      // $hari = date('d');
      // $hari = $hari - 1;
      // $tgl = date('-m-Y');
      // $hari_ini = $hari . $tgl;
      $tgl = date('d-m-Y');

      echo "<p align='right'>Depok, ".$tgl."
      <img src='gambar/bm_ttd.png' width='120' style='pointer-events:none;'>
      ( Berkah Madani )</p>";
      ?>
  </body>
</html>

<?php
  $filename="pmb_".$data['nama_nasabah'].".pdf"; //ubah untuk menentukan nama file pdf yang dihasilkan nantinya
  //==========================================================================================================
  //Copy dan paste langsung script dibawah ini,untuk mengetahui lebih jelas tentang fungsinya silahkan baca-baca tutorial tentang HTML2PDF
  //==========================================================================================================
  $content = ob_get_clean();
  $content = '<page style="font-family: ">'.nl2br($content).'</page>';
   require_once(dirname(__FILE__).'/html2pdf/html2pdf.class.php');
   try
   {
    $html2pdf = new HTML2PDF('P','A4','en', false, 'ISO-8859-15', array(20, -10, 20, -1000));
    $html2pdf->setDefaultFont('Arial');
    $html2pdf->writeHTML($content, isset($_GET['vuehtml']));
    $html2pdf->Output($filename);
   }
   catch(HTML2PDF_exception $e) { echo $e; }
?>
