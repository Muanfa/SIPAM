<nav class="navbar-inverse" data-spy="affix" data-offset-top="197" style="background-color:#596275;">
  <div class="container-fluid">
    <div class="navbar-header ">
      <!-- Button Naviagasi Kanan (Saat Layar Chrome dikecil) -->
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar" style="background-color:black;" onmouseover="this.style='background-color:gray;'" onmouseout="this.style='background-color:black;'">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <!-- Tombol LINK KIRI (Saat Layar Chrome dikecil)-->
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar2" style="float:left;margin-left:10px;background-color:black;" onmouseover="this.style='background-color:gray;float:left;margin-left:10px;'" onmouseout="this.style='background-color:black;float:left;margin-left:10px;'">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <div class="beranda">
        <a href="admin_home.php" title="Home" class="navbar-brand glyphicon glyphicon-home"  style="color:white;font-size:20px" onmouseover="this.style='text-decoration:none;color:#303952;font-size:20px'" onmouseout="this.style='color:white;font-size:20px'"></a>
      </div>
    </div>
    <!-- Tombol NAVIGASI ATAS -->
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="admin_sejarah.php" class="huruf-nav" title="Sejarah" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><b>Sejarah</b></a></li>
        <li><a href="admin_visi_misi.php" class="huruf-nav" title="Visi Misi" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><b>Visi Misi</b></a></li>
        <li><a href="admin_murabahah.php" class="huruf-nav" title="Murabahah" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><b>Murabahah</b></a></li>
        <li><a href="admin_hubungi_kami.php" class="huruf-nav" title="Hubungi Kami" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><b>Hubungi Kami</b></a></li>
      </ul>
      <!-- TOMBOL LOGIN -->
      <ul class="nav navbar-nav" style="float:right;">
        <li class="dropdown" ><a href="#" title="Login" class="huruf-nav dropdown-toggle" data-toggle="dropdown" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><span class="glyphicon glyphicon-log-in" style="font-size:16px;color:#4bcffa;"></span><b> Login</b></a>
          <div class="dropdown-menu">
            <form id="formLogin" action="proses_login.php" method="get" class="form container-fluid">
              <div class="form-group">
                <label for="email">Username:</label>
                <input name="username" id="email" type="text" class="form-control"  placeholder="Username" required>
              </div>
              <div class="form-group">
                <label for="pwd">Password:</label>
                <input name="password" id="password" type="password" class="form-control form-password"  placeholder="Password" required>
              </div>
              <div class="checkbox">
                <label><input type="checkbox" class="form-checkbox" name="remember">Tampilkan Password</label>
              </div>
              <button name="login_didalam" type="submit" id="btnLogin" class="btn btn-block" style="background-color:#3399ff;color:white;" onmouseover="this.style='background-color:#0080ff;color:white;'" onmouseout="this.style='background-color:#3399ff;color:white;'" >Login</button><br>
            </form>
          </div>
        </li>
        <!-- <li><a href="Login.html" title="Sign Up" style="color:white;" onmouseover="this.style='text-decoration:none;background-color:#303952;'" onmouseout="this.style='color:white;'"><span class="glyphicon glyphicon-user" style="font-size:16px;"></span><b> Logout</b></a></li> -->
        <li>
          <!-- TOMBOL LOGOUT -->
          <button type="button" class="btn navbar-btn" onclick="swal('Terima Kasih!', 'Telah menggunakan aplikasi berkahmadani.co.id', 'success').then((value) => {window.location.href='proses_logout.php';});" style="background-color:#ff3838;color:white;margin-left:8%;" onmouseover="this.style='background-color:#ee5253;color:white;margin-left:8%;'" onmouseout="this.style='background-color:#ff3838;color:white;margin-left:8%;'">
            <span class="glyphicon glyphicon-off" style="color:black;"></span><b> Logout</b>
          </button>
        </li>
      </ul>
    </div>
  </div>
</nav>
