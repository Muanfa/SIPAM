<h1 class="text-center"><b>Rekening</b></h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>Tambah Saldo Rekening Nasabah</b></h2>
  </div>
  <div class="panel-body">
    <!-- HR -->
    <table style="width:100%;">
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), black)"></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td><p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ&nbsp;اللهِ&nbsp;الرَّحْمَنِ&nbsp;الرَّحِيْمِ</p></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, black, rgba(0,0,0,0.75), rgba(0,0,0,0));"></td>
    </table>

    <form name='autoSumForm' action="proses_reknasabah.php" method="get">

      <!-- Data Rekening -->
      <div class="col-sm-12" style="border-radius:15px;background-color:#f2f2f2;">
        <div style="padding:1px 0px 1px 0px;">
          <h2 class="text-center">Rekening</h2>
          <table class="table" border=0>
            <!-- ID Rekening -->
            <tr>
              <?php
                // Fungsi ini menyembunyikan eror
                error_reporting(0);
                // Mengambil nilai id, dari form manager_data_pegawai.php dari tombol UBAH
                $id	  	= $_GET['id'];
                $query	= mysqli_query($konek,"SELECT * FROM data_reknasabah WHERE id_nasabah='$id'");
                $data	  = mysqli_fetch_array($query);
                $id_nsb = $data['id_nasabah'];
               ?>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;">ID Rekening :</label></th>
              <td style="border:none;"><input name="id_reknsb" type="text" class="form-control" value="<?php echo $data['id_reknasabah'];?>" readonly></td>
            </tr>
            <!-- Pemilik Rekening -->
            <tr>
              <td style="border:none;"><label style="margin-top:8px;">Pemilik Rekening :</label></td>
              <td style="border:none;"><input name="pmlk_rek" type="text" class="form-control" placeholder="Pemilik Rekening" value="<?php echo $data['nama'];?>" readonly></td>
            </tr>
            <!-- Tanggal Buka -->
            <tr>
              <th style="border:none;"><label style="margin-top:8px;">Tanggal Buka :</label></th>
              <td style="border:none;"><input name="tgl_buka" value="<?php echo $data['tanggal_buka'];?>" type="text" class="form-control" readonly></td>
            </tr>
            <!-- Saldo -->
            <tr>
              <td style="border:none;"><label style="margin-top:8px;">Saldo saat ini:</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input style="border-radius:4px;" name="saldo" type="text" onFocus="startCalc();" onBlur="stopCalc();" class="form-control" placeholder="Saldo saat ini" value="<?php echo $data['saldo'];?>" readonly>
                </div>
              </td>
            </tr>
            <!-- Tambah Jumlah Saldo -->
            <tr>
              <td style="border:none;"><label style="margin-top:8px;">Tambah Jumlah Saldo:</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input style="border-radius:4px;" name="tambah_saldo" onFocus="startCalc();" onBlur="stopCalc();" type="text" onKeyPress="return angkadanhuruf(event,'0123456789',this)" class="form-control" placeholder="Nilai Saldo" required>
                </div>
              </td>
            </tr>
            <!-- Total Saldo -->
            <tr>
              <td style="border:none;"><label style="margin-top:8px;">Total Saldo:</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input style="border-radius:4px;" name="total_saldo" onchange='tryNumberFormat(this.form.thirdBox);' type="text" class="form-control" placeholder="Total Saldo" readonly>
                </div>
              </td>
            </tr>
            <!-- Jenis Tabungan -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;">Jenis Tabungan :</label></th>
              <td style="border:none;"><input name="jns_tbng" type="text" class="form-control" value="<?php echo $data['jenis_tabungan'];?>" readonly></td>
            </tr>
            <!-- Status -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;">Status :</label></th>
              <td style="border:none;"><input name="status" type="text" class="form-control" value="<?php echo $data['status'];?>" readonly></td>
            </tr>
            <!-- Tanggal Tambah Saldo -->
            <tr>
              <?php
                $hari = date('d');
                $hari = $hari - 1;
                $no = array(
                  '1' => '01',
                  '2' => '02',
                  '3' => '03',
                  '4' => '04',
                  '5' => '05',
                  '6' => '06',
                  '7' => '07',
                  '8' => '08',
                  '9' => '09'
                );
                if ($hari < "10") {
                    $hari = $no[$hari];
                }
                $tgl = date('-m-Y');
                // $tgl_sekarang = date('d-m-Y');
              ?>

              <th style="border:none;"><label class="control-label" style="margin-top:8px;">Tanggal Daftar :</label></th>
              <td style="border:none;"><input name="tgl_tmbsld" value=<?php if (date('d') > $hari) { echo "$hari" . "$tgl";} else {echo "$tgl_sekarang";}?> type="text" class="form-control" readonly></td>
              <!-- <td style="border:none;"><input name="tgl_tmbsld" value=<?php echo "$tgl_sekarang";?> type="text" class="form-control" readonly></td> -->
            </tr>
            <!-- Id Nasabah -->
            <tr >
              <td colspan="2" style="border:none;"><input name="id_nsb" type="hidden" class="form-control" value="<?php echo $data['id_nasabah'];?>" readonly></td>
            </tr>
          </table>
        </div>
      </div>


      <!-- Tombol Simpan -->
      <div class="col-sm-12">
        <div style="text-align:center;">
          <input class="btn btn-success" type="submit" value="SIMPAN" name="tambah_nasabah" style="margin-top:15px;" readonly></input>
        </div>
        <!-- Untuk Info Jika Simpan Berhasil / Gagal -->
        <?php
          if (isset($_GET['ok'])){
            $error=$_GET['ok'];
          }else{
            $error="";
          }

          $pesan="";
          if ($error=="berhasil"){
                if ($_SESSION['admin']) {
                  $pesan=  "<script>
                              swal('Berhasil!', 'Data Telah Tersimpan!', 'success')
                              .then((value) => {
                                window.location.href='admin_data_reknasabah.php?&id=$id_nsb';
                              });
                            </script>";
                } else if ($_SESSION['manager']) {
                  $pesan=  "<script>
                              swal('Berhasil!', 'Data Telah Tersimpan!', 'success')
                              .then((value) => {
                                window.location.href='manager_data_reknasabah.php?&id=$id_nsb';
                              });
                            </script>";
                }
          } else if ($error=="gagal") {
                if ($_SESSION['admin']) {
                  $pesan=  "<script>
                              swal('Gagal!', 'Data Gagal Disimpan Di Database!', 'error')
                              .then((value) => {
                                swal('Info!', 'Coba Periksa Di File proses_nasabah.php / kode halaman ini', 'info')
                                .then((value) => {
                                  window.location.href='admin_lihat_reknasabah.php';
                                })
                              });
                            </script>";
                } else if ($_SESSION['manager']) {
                  $pesan=  "<script>
                              swal('Gagal!', 'Data Gagal Disimpan Di Database!', 'error')
                              .then((value) => {
                                swal('Info!', 'Coba Periksa Di File proses_nasabah.php / kode halaman ini', 'info')
                                .then((value) => {
                                  window.location.href='manager_lihat_reknasabah.php';
                                })
                              });
                            </script>";
                }
          }
          // Tampil Hasil Pesan
          echo "$pesan";
        ?>
      </div>
    </form>
  </div>
</div>
