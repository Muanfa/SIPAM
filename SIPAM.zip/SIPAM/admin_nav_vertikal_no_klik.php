<div id="myNavbar2" class="atur-link collapse navbar-collapse navbar-inverse" data-spy="affix" data-offset-top="197" style="height:900px;">
  <div class="scroll-link" id="accordion" style="height:600px;">
    <!-- Gambar Admin -->
    <div class="panel" style="margin:2%;background-color:#706fd3;" >
      <div class="panel-heading" onmouseover="this.style='text-decoration:none;background-color:#574b90;'" onmouseout="this.style='color:white;background-color:#706fd3;'">
        <div class="" style="height:50px;" >
          <div class="gambar-profil">
            <img src="gambar/Logo_BM1.png" class="img-circle img-responsive" alt="gambar berkah madani" width="50" height="50" style="margin-top:8px;">
          </div>
          <div class="profil">
            <div class="nama-profil responsive">
              BMT Berkah Madani
            </div>
            <div class="drop-status">
              <div class="status-bullet">
                <b><span>&bull;</span></b>
              </div>
              <div class="status-online">
                <b>Online</b>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Alur Akad Pembiayaan Murabahah -->
    <div class="panel panel-info" style="margin-left:2%;margin-bottom:2%;margin-right:2%;">
      <div class="panel-heading">
        <ul class="nav nav-pills nav-stacked panel panel-default" style="margin-left:-4%;margin-top:-2%;margin-right:-4%;margin-bottom:-2%;">
          <li><a href="admin_alur_akad.php" tabindex="-1"><span class="glyphicon glyphicon-bookmark" style="font-size:15px;color:#9c88ff;"></span><b style="font-size:13px;"> Alur Pembiayaan Akad Murabahah</b></a></li>
        </ul>
      </div>
    </div>
    <!-- Pegawai -->
    <div class="panel panel-info" style="margin-left:2%;margin-bottom:2%;margin-right:2%;">
      <div class="panel-heading">
        <ul class="nav nav-stacked panel panel-default" style="margin-left:-4%;margin-top:-2%;margin-right:-4%;margin-bottom:-2%;">
          <li><a tabindex="-1" class="huruf-link" data-toggle="collapse" data-parent="#accordion" data-target="#collapse-0"><span class="glyphicon glyphicon-user" style="font-size:15px;color:black;"></span><b> Pegawai</b><span class="glyphicon glyphicon-chevron-down" style="float:right;font-size:17px;margin-top:1.5%;"></span></a></li>
        </ul>
      </div>
      <div id="collapse-0" class="panel-collapse collapse">
        <div class="panel-body">
          <ul class="nav nav-pills nav-stacked">
            <li><a href="admin_tambah_pegawai.php" tabindex="-1" ><span class="glyphicon glyphicon-triangle-right"></span>
              <b>Daftar Pegawai</b> <span class="panel panel-default" style="padding:2px;background-color:#fffa65;color:red;">Baru</span></a></li>
            <li><a href="admin_data_pegawai.php" tabindex="-1"><span class="glyphicon glyphicon-triangle-right"></span> <b>Data Pegawai</b></a></li>
          </ul>
        </div>
      </div>
    </div>
    <!-- Nasabah -->
    <div class="panel panel-info" style="margin-left:2%;margin-bottom:2%;margin-right:2%;">
      <div class="panel-heading">
        <ul class="nav nav-stacked panel panel-default" style="margin-left:-4%;margin-top:-2%;margin-right:-4%;margin-bottom:-2%;">
          <li><a tabindex="-1" class="huruf-link" data-toggle="collapse" data-parent="#accordion" data-target="#collapse-1"><span class="glyphicon glyphicon-user" style="font-size:15px;color:#6ab04c;"></span><b> Nasabah</b><span class="glyphicon glyphicon-chevron-down" style="float:right;font-size:17px;margin-top:1.5%;"></span></a></li>
        </ul>
      </div>
      <div id="collapse-1" class="panel-collapse collapse">
        <div class="panel-body">
          <ul class="nav nav-pills nav-stacked">
            <li><a href="admin_tambah_nasabah.php" tabindex="-1" ><span class="glyphicon glyphicon-triangle-right"></span>
              <b>Daftar Nasabah</b> <span class="panel panel-default" style="padding:2px;background-color:#fffa65;color:red;">Baru</span></a></li>
            <li><a href="admin_data_nasabah.php" tabindex="-1"><span class="glyphicon glyphicon-triangle-right"></span> <b>Data Nasabah</b></a></li>
            <li><a href="admin_lihat_reknasabah.php" tabindex="-1" ><span class="glyphicon glyphicon-triangle-right"></span> <b>Data Rekening</b></a></li>
          </ul>
        </div>
      </div>
    </div>
    <!-- Monitoring -->
    <div class="panel panel-info" style="margin-left:2%;margin-bottom:2%;margin-right:2%;">
      <div class="panel-heading">
        <ul class="nav nav-pills nav-stacked panel panel-default" style="margin-left:-4%;margin-top:-2%;margin-right:-4%;margin-bottom:-2%;">
          <li><a href="admin_data_monitoring.php" class="huruf-link" tabindex="-1"><span class="glyphicon glyphicon-eye-open" style="font-size:15px;color:#30336b;"></span><b> Monitoring</b></a></li>
        </ul>
      </div>
    </div>
    <!-- Info -->
    <div class="panel panel-info" style="margin-left:2%;margin-bottom:2%;margin-right:2%;">
      <div class="panel-heading">
        <ul class="nav nav-stacked panel panel-default" style="margin-left:-4%;margin-top:-2%;margin-right:-4%;margin-bottom:-2%;">
          <li><a tabindex="-1" class="huruf-link" data-toggle="collapse" data-parent="#accordion" data-target="#collapse-5"><span class="glyphicon glyphicon-info-sign" style="font-size:15px;color:blue;"></span><b> Info</b><span class="glyphicon glyphicon-chevron-down" style="float:right;font-size:17px;margin-top:1.5%;"></span></a></li>
          <!-- <li><a href="#" tabindex="-1" data-toggle="collapse" data-target="#collapse-1"><b>Link 2</b><span class="glyphicon glyphicon-chevron-down" style="float:right;font-size:13px;"></span></a></li> -->
        </ul>
      </div>
      <div id="collapse-5" class="panel-collapse collapse">
        <div class="panel-body">
          <ul class="nav nav-pills nav-stacked">
            <!-- Kalau misalnya lagi dibagian ini, mau di waranain tingal ubah style background-color -->
            <li><a href="admin_tentang_app.php" tabindex="-1"><span class="glyphicon glyphicon-triangle-right"></span> <b>Tentang App Website</b></a></li>
          </ul>
        </div>
      </div>
    </div>
    <hr>
  </div>
</div>
