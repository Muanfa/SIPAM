<h1 class="text-center"><b>Nasabah</b></h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>Daftar Nasabah Baru</b></h2>
  </div>
  <div class="panel-body">
    <!-- HR -->
    <table style="width:100%;">
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), black)"></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td><p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ&nbsp;اللهِ&nbsp;الرَّحْمَنِ&nbsp;الرَّحِيْمِ</p></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, black, rgba(0,0,0,0.75), rgba(0,0,0,0));"></td>
    </table>

    <form name='autoSumForm' action="proses_nasabah.php" method="get">

      <!-- Data Nasabah -->
      <div class="col-sm-12" style="border-radius:15px;background-color:#f2f2f2;margin-bottom:5px;">
        <div style="padding:1px 0px 1px 0px;">
          <h2 class="text-center">Data Pemohon</h2>
          <table class="table" border=0>
            <!-- Membuat ID Baru untuk nasabah -->
            <?php
              $hasil = mysqli_query($konek,"select max(id_nasabah) as idMaks from data_nasabah");
              $data  = mysqli_fetch_array($hasil);
              $idMax = $data['idMaks'];
              $noUrut = substr($idMax, 1, 5);
              $noUrut++;
              $format = "N";
              $newID = $format . sprintf("%05s", $noUrut);
            ?>
            <!-- ID Nasabah -->
            <tr>
                <th style="border:none;"><label class="control-label" style="margin-top:8px;">ID Nasabah :</label></th>
                <td style="border:none;"><input name="id_nas" type="text" class="form-control disabled" value=<?php echo "$newID"; ?> readonly></td>
            </tr>
            <!-- Nama Lengkap -->
            <tr>
              <td colspan="2" style="border:none;"><input name="nama_lkp" id="txtFirst" onkeyup="copytextbox();" type="text" class="form-control" placeholder="Nama Lengkap" required></td>
            </tr>
            <!-- Alamat -->
            <tr>
              <td colspan="2"style="border:none;"><textarea name="almt" class="form-control" rows="5" style="resize:none;" placeholder="Alamat Tempat Tinggal" required></textarea></td>
            </tr>
            <!-- No Telepon -->
            <tr>
              <td colspan="2" style="border:none;"><input name="no_telp" type="text" onKeyPress="return angkadanhuruf(event,'0123456789',this)" class="form-control" placeholder="Nomer Telepon" required></td>
            </tr>
            <!-- Jenis Kelamin -->
            <tr>
              <th style="border:none;">Jenis Kelamin :</td>
              <td style="border:none;">
                <label class="radio-inline" style="text-align:right;">
                  <input type="radio" name="jk" value="Pria" checked>Pria
                </label>
                <label class="radio-inline" >
                  <input type="radio" name="jk" value="Wanita" style="text-align:right;">Wanita
                </label>
              </td>
            </tr>
            <!-- Tanggal Lahir -->
            <tr>
              <td colspan="2" style="border:none;">
                <div class="form-group" style="width:100%;margin-bottom:2px;">
                  <div class='input-group date' id='datetimepicker2'>
                    <input type='text' name="tgl_lhr" class="form-control"  style="pointer-events:none;" placeholder="Tanggal Lahir" required>
                    <span class="input-group-addon">
                      <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                  </div>
                </div>
              </td>
            </tr>
            <!-- Identitas Diri -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;" >Identitas Diri :</label></th>
              <td style="border:none;">
                <select name="ident" class="form-control" id="sel1">
                  <option value="KTP" selected>KTP</option>
                  <option value="SIM">SIM</option>
                  <option value="Paspor">Paspor</option>
                  <option value="Lainnya">Lainnya</option>
                </select>
              </td>
            </tr>
            <!-- Email -->
            <tr>
              <td colspan="2" style="border:none;"><input name="email" type="email" id="email" class="form-control" placeholder="Email" required></td>
            </tr>
            <!-- Tanggal Daftar -->
            <tr>
              <?php
                // $hari = date('d');
                // $hari = $hari - 1;
                // $no = array(
                //   '1' => '01',
                //   '2' => '02',
                //   '3' => '03',
                //   '4' => '04',
                //   '5' => '05',
                //   '6' => '06',
                //   '7' => '07',
                //   '8' => '08',
                //   '9' => '09'
                // );
                // if ($hari < "10") {
                //     $hari = $no[$hari];
                // }
                // $tgl = date('-m-Y');
                $tgl_sekarang = date('d-m-Y');
              ?>

              <th style="border:none;"><label class="control-label" style="margin-top:8px;">Tanggal Daftar :</label></th>
              <!-- <td style="border:none;"><input name="tgl_dft" value=<?php if (date('d') > $hari) { echo "$hari" . "$tgl";} else {echo "$tgl_sekarang";}?> type="text" class="form-control" readonly></td> -->
              <td style="border:none;"><input id="txtFirst2" onkeyup="copytextbox();" name="tgl_dft" value=<?php echo "$tgl_sekarang";?> type="text" class="form-control" readonly></td>
            </tr>
            <!-- Pekerjaan -->
            <tr>
              <td colspan="2" style="border:none;"><input name="pkrjn" type="text" class="form-control" placeholder="Pekerjaan" required></td>
            </tr>
            <!-- Perusahaan -->
            <tr>
              <td colspan="2" style="border:none;"><input name="prshn" type="text" class="form-control" placeholder="Perusahaan" required></td>
            </tr>
            <!-- Bidang Usaha -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;">Bidang Usaha :</label></th>
              <td style="border:none;">
                <select name="bdng_usha" class="form-control" id="sel1">
                  <option value="Produksi" selected>Produksi</option>
                  <option value="Jasa">Jasa</option>
                  <option value="Perdagangan">Perdagangan</option>
                  <option value="Pertanian">Pertanian</option>
                  <option value="Perternakan">Perternakan</option>
                </select>
              </td>
            </tr>
            <!-- Alamat Perusahaan -->
            <tr>
              <td colspan="2" style="border:none;"><textarea name="almt_prshn" class="form-control" rows="5" style="resize:none;" placeholder="Alamat Perusahaan" required></textarea></td>
            </tr>
            <!-- Nama Istri/Suami -->
            <tr>
              <td colspan="2" style="border:none;"><input name="nma_issu" type="text" class="form-control" placeholder="Nama Istri/Suami" >
                <p style="font-size:12px;margin-left:10px;">
                  <strong>Catatan:</strong> Belum menikah kosongkan saja
                </p>
              </td>
            </tr>
          </table>
        </div>
      </div>

      <!-- Data Rekening -->
      <div class="col-sm-12" style="border-radius:15px;background-color:#f2f2f2;">
        <div style="padding:1px 0px 1px 0px;">
          <h2 class="text-center">Rekening</h2>
          <table class="table" border=0>
            <!-- ID Rekening -->
            <tr>
              <!-- Membuat ID Rekening BARU -->
              <?php
                $hasil = mysqli_query($konek,"SELECT max(id_reknasabah) AS idMaks FROM data_reknasabah");
                $data  = mysqli_fetch_array($hasil);
                $idMax = $data['idMaks'];
                $noUrut =  substr($idMax, 1, 5);
                $noUrut++;
                $format = "R";
                $newID2 = $format . sprintf("%05s", $noUrut);
               ?>
              <th style="border:none;width-min:300px;"><label class="control-label" style="margin-top:8px;">ID Rekening :</label></th>
              <td style="border:none;"><input name="id_reknsb" type="text" class="form-control" value=<?php echo "$newID2";?> readonly></td>
            </tr>
            <!-- Pemilik Rekening -->
            <tr>
              <td style="border:none;"><label style="margin-top:8px;">Pemilik Rekening :</label></td>
              <td style="border:none;"><input id="txtSecond1" name="pmlk_rek" type="text" class="form-control" placeholder="Pemilik Rekening" readonly></td>
            </tr>
            <!-- Tanggal Buka -->
            <tr>
              <th style="border:none;"><label style="margin-top:8px;">Tanggal Buka :</label></th>
              <!-- <td style="border:none;"><input name="tgl_dft" value=<?php if (date('d') > $hari) { echo "$hari" . "$tgl";} else {echo "$tgl_sekarang";}?> type="text" class="form-control" readonly></td> -->
              <td style="border:none;"><input name="tgl_buka" value=<?php echo "$tgl_sekarang";?> type="text" class="form-control" readonly></td>
            </tr>
            <!-- Saldo -->
            <tr>
              <td style="border:none;"><label style="margin-top:8px;">Saldo :</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input style="border-radius:4px;" name="nilai_jam" type="text" onKeyPress="return angkadanhuruf(event,'0123456789',this)" class="form-control" placeholder="Nilai Saldo" required>
                </div>
              </td>
            </tr>
            <!-- Jenis Tabungan -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;">Jenis Tabungan :</label></th>
              <td style="border:none;"><input name="jns_tbng" type="text" class="form-control" value="Berkah Hasil" readonly></td>
            </tr>
            <!-- Status -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;">Status :</label></th>
              <td style="border:none;"><input name="status" type="text" class="form-control" value="Aktif" readonly></td>
            </tr>
          </table>
        </div>
      </div>


      <!-- Tombol Simpan -->
      <div class="col-sm-12">
        <div style="text-align:center;">
          <input class="btn btn-success" type="submit" value="SIMPAN" name="tambah_nasabah" style="margin-top:15px;" readonly></input>
        </div>
        <!-- Untuk Info Jika Simpan Berhasil / Gagal -->
        <?php
          if (isset($_GET['ok'])){
            $error=$_GET['ok'];
          }else{
            $error="";
          }

          $pesan="";
          if ($error=="berhasil"){
                if ($_SESSION['admin']) {
                  $pesan=  "<script>
                              swal('Berhasil!', 'Data Telah Tersimpan!', 'success')
                              .then((value) => {
                                window.location.href='admin_data_nasabah.php';
                              });
                            </script>";
                } else if ($_SESSION['manager']) {
                  $pesan=  "<script>
                              swal('Berhasil!', 'Data Telah Tersimpan!', 'success')
                              .then((value) => {
                                window.location.href='manager_data_nasabah.php';
                              });
                            </script>";
                }
          } else if ($error=="gagal") {
                if ($_SESSION['admin']) {
                  $pesan=  "<script>
                              swal('Gagal!', 'Data Gagal Disimpan Di Database!', 'error')
                              .then((value) => {
                                swal('Info!', 'Coba Periksa Di File proses_nasabah.php / kode halaman ini', 'info')
                                .then((value) => {
                                  window.location.href='admin_tambah_nasabah.php';
                                })
                              });
                            </script>";
                } else if ($_SESSION['manager']) {
                  $pesan=  "<script>
                              swal('Gagal!', 'Data Gagal Disimpan Di Database!', 'error')
                              .then((value) => {
                                swal('Info!', 'Coba Periksa Di File proses_nasabah.php / kode halaman ini', 'info')
                                .then((value) => {
                                  window.location.href='manager_tambah_nasabah.php';
                                })
                              });
                            </script>";
                }
          }else if ($error == "gagalumur") {
                  if ($_SESSION['admin']) {
                    $pesan=  "<script>
                                swal('Gagal!', 'Data Gagal Disimpan Di Database!', 'error')
                                .then((value) => {
                                  swal('Info!', 'Umur anda tidak cukup', 'info')
                                  .then((value) => {
                                    window.location.href='admin_tambah_nasabah.php';
                                  })
                                });
                              </script>";
                  } else if ($_SESSION['manager']) {
                    $pesan=  "<script>
                                swal('Gagal!', 'Data Gagal Disimpan Di Database!', 'error')
                                .then((value) => {
                                  swal('Info!', 'Coba Periksa Di File proses_pegawai.php', 'info')
                                  .then((value) => {
                                    window.location.href='manager_tambah_nasabah.php';
                                  })
                                });
                              </script>";
                  }
            }
          // Tampil Hasil Pesan
          echo "$pesan";
        ?>
      </div>
    </form>
  </div>
</div>
