<?php
require "koneksi/koneksi.php";

session_start();

if ($_SESSION['accountofficer']) {
  $id_pegawai = $_SESSION['accountofficer'];
} else if ($_SESSION['manager']) {
  $id_pegawai = $_SESSION['manager'];
}

// Mengambil nilai nama pegawai dari data_pegawai, nanti di pindahakan nilai nama pegawai ke data_monitoring
$query     = mysqli_query($konek,"SELECT * FROM data_pegawai WHERE id_pegawai = '$id_pegawai'");
$data       = mysqli_fetch_array($query);
$dpt_nama   = $data['nama_depan'] . " " . $data['nama_belakang'];
$jabatan    = $data['jabatan'];

// Membuat id_monitoring baru
$hasil = mysqli_query($konek,"select max(id_monitoring) as idMaks from data_monitoring");
$data  = mysqli_fetch_array($hasil);
$idMax = $data['idMaks'];
$noUrut =  substr($idMax, 1, 5);
$noUrut++;
$format = "M";
$newID = $format . sprintf("%05s", $noUrut);

// Membuat transaksi baru
$hasil            = mysqli_query($konek,"SELECT max(id_transaksi) AS idMaks FROM data_transaksi");
$data             = mysqli_fetch_array($hasil);
$idMax            = $data['idMaks'];
$noUrut           =  substr($idMax, 1, 5);
$noUrut++;
$format           = "T";
$newID_transaksi  = $format . sprintf("%05s", $noUrut);

// Membuat id_aruskas baru
$qry2          = mysqli_query($konek, "SELECT max(id_aruskas) AS idMaks2 FROM data_laporanaruskas");
$data2         = mysqli_fetch_array($qry2);
$idMax2        = $data2['idMaks2'];
$noUrut2       = substr($idMax2, 1, 5);
$noUrut2++;
$format2       = "A";
$newID_aruskas = $format2 . sprintf("%05s", $noUrut2);
// Ke Dua
$noUrut2       = substr($newID_aruskas, 1, 5);
$noUrut2++;
$format2       = "A";
$newID_aruskas2 = $format2 . sprintf("%05s", $noUrut2);
// Ke Tiga
$noUrut2       = substr($newID_aruskas2, 1, 5);
$noUrut2++;
$format2       = "A";
$newID_aruskas3 = $format2 . sprintf("%05s", $noUrut2);


// Pengecekan apakah status pembiayaan ada yang proses
if(isset($_GET['cek'])){
  $id_nsb       = $_GET['id'];
  $qry          = mysqli_query($konek, "SELECT * FROM data_pembiayaan WHERE id_nasabah = '$id_nsb'");
  while($data = mysqli_fetch_array($qry)){
    $status      = $data['status'];
  }
  
  echo "$status";
  if($status == "Proses"){
    // BERHASIL
    if ($_SESSION['accountofficer']) {
      header('location:ao_data_tambah_pembiayaan.php?ok=gagal');
    } else if ($_SESSION['manager']) {
      header('location:manager_data_tambah_pembiayaan.php?ok=');
    }
  }
  else{
    // BERHASIL
    if ($_SESSION['accountofficer']) {
      header('location:ao_tambah_pembiayaan.php?id='.$id_nsb);
    } else if ($_SESSION['manager']) {
      header('location:manager_tambah_pembiayaan.php?id='.$id_nsb);
    }
  }
}


// Jika di Tekan tombol simpan (Tambah Pembiayaan) eksekusi code ini
if(isset($_GET['tambah_pembiayaan']))
{
  // ========== DATA PEMBIAYAAN ==========
  $id_pembiayaan	   = $_GET['id_pemb'];
  $nama_nasabah  	   = $_GET['nma_nsb'];
  $tgl_daftar    	   = $_GET['tgl_dft'];
  $kegunaan	         = $_GET['kgnaan'];
  $obyek_pembiayaan  = $_GET['oby_pemb'];
  $jenis_pembiayaan  = $_GET['jns_pemb'];
  $sistem_pembayaran = $_GET['sist_pmbyrn'];
  $jumlah_pembiayaan = $_GET['jml_pmbyn'];
  $margin            = $_GET['margin'];
  $jangka_waktu      = $_GET['jngk_waktu'];
  $kas_bmt           = $_GET['kas_bmt'];
  $pendapatan_margin = $_GET['pndptn_margin'];
  $jumlah_angsuran	 = $_GET['jml_angs'];
  $total_margin 	   = $_GET['total_margin'];
  $total_pembiayaan  = $_GET['total_pmbyaan'];
  $sisa_setoran      = $_GET['sisa_setoran'];

  // ========== DATA JAMINAN ============
  $id_jaminan	      = $_GET['id_jam'];
  $jenis_jaminan	  = $_GET['jns_jam'];
  $dokumen_jaminan  = $_GET['dok_jam'];
  $lokasi_jaminan   = $_GET['almt_jam'];
  $nilai_jaminan    = $_GET['nilai_jam'];
  $pemilik_jaminan  = $_GET['pmlk_jam'];

  // ID pembiayaan
  $id_nasabah	   = $_GET['id_nsb'];

  

  // =============== Menyimpan ke Database =====================================
  // ========== DATA PEMBIAYAAN ==========
  $query = mysqli_query($konek, "INSERT INTO data_pembiayaan VALUES(
           '$id_pembiayaan',
           '$nama_nasabah',
           '$tgl_daftar',
           '$kegunaan',
           '$obyek_pembiayaan',
           '$jenis_pembiayaan',
           '$sistem_pembayaran',
           '$jumlah_pembiayaan',
           '$margin',
           '$jangka_waktu',
           '$kas_bmt',
           '$pendapatan_margin',
           '$jumlah_angsuran',
           '$total_margin',
           '$total_pembiayaan',
           '$sisa_setoran',
           'Proses',
           '$id_nasabah')"
  );

  // ========== DATA JAMINAN ==========
  $query2 = mysqli_query($konek, "INSERT INTO data_jaminan VALUES(
           '$id_jaminan',
           '$jenis_jaminan',
           '$dokumen_jaminan',
           '$lokasi_jaminan',
           '$nilai_jaminan',
           '$pemilik_jaminan',
           '$id_nasabah',
           '$id_pembiayaan')"
  );
  // ========== DATA TRANSAKSI ==========
  $nominal_nyetor = $jumlah_pembiayaan;
  $nama_penyetor  = $dpt_nama;
  $tanggal_setor  = $tgl_daftar;
  $sisa_setoran   = $total_pembiayaan;
  $pendapatan_bmt = $total_margin;
  $query3 = mysqli_query($konek, "INSERT INTO data_transaksi VALUES (
           '$newID_transaksi',
           '$nominal_nyetor',
           '$nama_penyetor',
           '$tanggal_setor',
           '-',
           '$obyek_pembiayaan',
           '$nama_nasabah',
           '$pendapatan_bmt',
           '$total_pembiayaan',
           '$id_pembiayaan',
           '$id_nasabah')"
  );



  if ($query3) {
    // Menyimpan ke Laporan Arus Kas
    $query4 = mysqli_query($konek, "INSERT INTO data_laporanaruskas VALUES (
      '$newID_aruskas',
      '$tgl_daftar',
      '$sisa_setoran',
      '0',
      'Piutang Murabahah',
      '1-1201',
      '$id_pembiayaan',
      '$newID_transaksi')"
    );
    $query5 = mysqli_query($konek, "INSERT INTO data_laporanaruskas VALUES (
      '$newID_aruskas2',
      '$tgl_daftar',
      '0',
      '$jumlah_pembiayaan',
      'Kas BMT BM',
      '1-1101',
      '$id_pembiayaan',
      '$newID_transaksi')"
    );
    $query6 = mysqli_query($konek, "INSERT INTO data_laporanaruskas VALUES (
      '$newID_aruskas3',
      '$tgl_daftar',
      '0',
      '$total_margin',
      'Keuntungan Murabahah Tangguh',
      '1-1103',
      '$id_pembiayaan',
      '$newID_transaksi')"
    );



    // Menyimpan ke database sipam, dari tabel data_monitoring
    $query7 = mysqli_query($konek, "INSERT INTO data_monitoring VALUES(
      '$newID',
      '$jabatan',
      '$dpt_nama',
      'Daftar pembiayaan Baru',
      Now(),
      '$id_pegawai')"
    );

    // BERHASIL
    if ($_SESSION['accountofficer']) {
      header('location:ao_tambah_pembiayaan.php?ok=berhasil');
    } else if ($_SESSION['manager']) {
      header('location:manager_tambah_pembiayaan.php?ok=berhasil');
    }
  }else {
    // GAGAL
    if ($_SESSION['accountofficer']) {
      header('location:ao_tambah_pembiayaan.php?ok=gagal');
    } else if ($_SESSION['manager']) {
      header('location:manager_tambah_pembiayaan.php?ok=gagal');
    }
  }
}



// Jika di Tekan tombol ubah (Ubah Pembiayaan) eksekusi code ini
if(isset($_GET['ubah_pembiayaan']))
{
  // Mengambil nilai dari form manager_ubah_pembiayaan.php
  // ========== DATA PEMBIAYAAN ==========
  $id_pembiayaan	   = $_GET['id_pemb'];
  $nama_nasabah  	   = $_GET['nma_nsb'];
  $tgl_daftar    	   = $_GET['tgl_dft'];
  $kegunaan	         = $_GET['kgnaan'];
  $obyek_pembiayaan  = $_GET['oby_pemb'];
  $jenis_pembiayaan  = $_GET['jns_pemb'];
  $sistem_pembayaran = $_GET['sist_pmbyrn'];
  $jumlah_pembiayaan = $_GET['jml_pmbyn'];
  $margin            = $_GET['margin'];
  $jangka_waktu      = $_GET['jngk_waktu'];
  $kas_bmt           = $_GET['kas_bmt'];
  $pendapatan_margin = $_GET['pndptn_margin'];
  $jumlah_angsuran	 = $_GET['jml_angs'];
  $total_margin 	   = $_GET['total_margin'];
  $total_pembiayaan  = $_GET['total_pmbyaan'];
  $sisa_setoran      = $_GET['sisa_setoran'];

  // ======================== Menyimpan Ke Database ============================
  // Memperbarui ke database sipam, dari tabel data_pembiayaan
  $query = mysqli_query($konek, "UPDATE data_pembiayaan SET
           id_pembiayaan     ='$id_pembiayaan',
           nama_nasabah      ='$nama_nasabah',
           tgl_daftar        ='$tgl_daftar',
           kegunaan          ='$kegunaan',
           obyek_pembiayaan  ='$obyek_pembiayaan',
           jenis_pembiayaan  ='$jenis_pembiayaan',
           sistem_pembayaran ='$sistem_pembayaran',
           jumlah_pembiayaan ='$jumlah_pembiayaan',
           margin            ='$margin',
           jangka_waktu      ='$jangka_waktu',
           kas_bmt           ='$kas_bmt',
           pendapatan_margin ='$pendapatan_margin',
           jumlah_angsuran   ='$jumlah_angsuran',
           total_margin      ='$total_margin',
           total_pembiayaan  ='$total_pembiayaan',
           sisa_setoran      ='$sisa_setoran' WHERE id_pembiayaan = '$id_pembiayaan'"
  );
  if ($query) {

    // Menyimpan ke database sipam, dari tabel data_monitoring
    $query3 = mysqli_query($konek, "INSERT INTO data_monitoring VALUES(
      '$newID',
      '$jabatan',
      '$dpt_nama',
      'Mengubah Data Pembiayaan',
      Now(),
      '$id_pegawai')"
    );

    // BERHASIL
    if ($_SESSION['accountofficer']) {
      header('location:ao_ubah_pembiayaan.php?ok=berhasil');
    } else if ($_SESSION['manager']) {
      header('location:manager_ubah_pembiayaan.php?ok=berhasil');
    }
  }else {
    // GAGAL
    if ($_SESSION['accountofficer']) {
      header('location:ao_ubah_pembiayaan.php?ok=gagal');
    } else if ($_SESSION['manager']) {
      header('location:manager_ubah_pembiayaan.php?ok=gagal');
    }
  }
}
?>
