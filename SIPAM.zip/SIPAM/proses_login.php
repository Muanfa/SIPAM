<?php
  require "koneksi/koneksi.php";

  session_start();

  // Membuat id_monitoring baru
  $hasil = mysqli_query($konek,"select max(id_monitoring) as idMaks from data_monitoring");
  $data  = mysqli_fetch_array($hasil);
  $idMax = $data['idMaks'];
  $noUrut =  substr($idMax, 1, 5);
  $noUrut++;
  $format = "M";
  $newID = $format . sprintf("%05s", $noUrut);
  $noUrut =  substr($newID, 1, 5);
  $noUrut++;
  $format = "M";
  $newID2 = $format . sprintf("%05s", $noUrut);

  if(isset($_GET['login']))
  {
    // Mengambil nilai dari form login.php
    $user  = $_GET['username'];
  	$pass  = md5($_GET['password']);
    // Memanggil ke database, dari data_pegawai
    $query = mysqli_query($konek, "SELECT * FROM data_pegawai WHERE username = '$user' AND password = '$pass'");
	  $data  = mysqli_fetch_array($query);
    $cek   = mysqli_num_rows($query);

    $id_pegawai = $data['id_pegawai'];
    $dpt_nama   = $data['nama_depan'] . " " . $data['nama_belakang'];

    // Pengecekan apakah ada username dan password itu di database
    if ($cek >= 1) {
      // pengecekan jabatan
      if($data['jabatan'] == "Admin"){
        $_SESSION['admin'] = $data['id_pegawai'];
        // Menyimpan ke database sipam, dari tabel data_monitoring
        $query = mysqli_query($konek, "INSERT INTO data_monitoring VALUES(
          '$newID',
          'Admin',
          '$dpt_nama',
          'Pegawai Telah Login',
          Now(),
          '$id_pegawai')"
        );
        // Memberikan lokasi Selanjutnya
        header("location: admin_home.php?ok=berhasil");
      }
      else if($data['jabatan'] == "Account Officer") {
        $_SESSION['accountofficer'] = $data['id_pegawai'];
        $query = mysqli_query($konek, "INSERT INTO data_monitoring VALUES(
          '$newID',
          'Account Officer',
          '$dpt_nama',
          'Pegawai Telah Login',
          Now(),
          '$id_pegawai')"
        );
        header("location: ao_home.php?ok=berhasil");
      }
      else if($data['jabatan'] == "Manager") {
        $_SESSION['manager'] = $data['id_pegawai'];
        $query = mysqli_query($konek, "INSERT INTO data_monitoring VALUES(
          '$newID',
          'Manager',
          '$dpt_nama',
          'Pegawai Telah Login',
          Now(),
          '$id_pegawai')"
        );
        header("location: manager_home.php?ok=berhasil");
      }
    }else{
      // Berpindah ke form Login.php, info gagal login
      header('location:login.php?ok=gagal');
    }
  }

  if(isset($_GET['login_didalam']))
  {
    // pengecekan session untuk mendapatakan ID_PEGAWAI, untuk JABATAN & DAPAT NAMA
    if ($_SESSION['admin']) {
      $id_pegawai = $_SESSION['admin'];
    } else if ($_SESSION['accountofficer']) {
      $id_pegawai = $_SESSION['accountofficer'];
    } else if ($_SESSION['manager']) {
      $id_pegawai = $_SESSION['manager'];
    }

    // Mengmabil data_pegawai
    $query = mysqli_query($konek, "SELECT * FROM data_pegawai WHERE id_pegawai = '$id_pegawai'");
    $data  = mysqli_fetch_array($query);
    $dpt_nama  = $data['nama_depan'] . " " . $data['nama_belakang'];
    $jabatan   = $data['jabatan'];

    // LOGOUT
    $query = mysqli_query($konek, "INSERT INTO data_monitoring VALUES(
      '$newID',
      '$jabatan',
      '$dpt_nama',
      'Pegawai Telah Logout',
      Now(),
      '$id_pegawai')"
    );

    session_destroy();
    session_start();

    // Mengambil nilai dari LOGIN dari NAV HORIZONTAL
    $user  = $_GET['username'];
  	$pass  = md5($_GET['password']);
    // Memanggil ke database, dari data_pegawai
    $query = mysqli_query($konek, "SELECT * FROM data_pegawai WHERE username = '$user' AND password = '$pass'");
	  $data  = mysqli_fetch_array($query);
    $cek   = mysqli_num_rows($query);

    $id_pegawai = $data['id_pegawai'];
    $dpt_nama   = $data['nama_depan'] . " " . $data['nama_belakang'];

    // Pengecekan apakah ada username dan password itu di database
    if ($cek >= 1) {
      // pengecekan jabatan
      if($data['jabatan'] == "Admin"){
        $_SESSION['admin'] = $data['id_pegawai'];
        // Menyimpan ke database sipam, dari tabel data_monitoring
        $query = mysqli_query($konek, "INSERT INTO data_monitoring VALUES(
          '$newID2',
          'Admin',
          '$dpt_nama',
          'Pegawai Telah Login',
          Now(),
          '$id_pegawai')"
        );
        // Memberikan lokasi Selanjutnya
        header("location: admin_home.php?ok=berhasil");
      }
      else if($data['jabatan'] == "Account Officer") {
        $_SESSION['accountofficer'] = $data['id_pegawai'];
        $query = mysqli_query($konek, "INSERT INTO data_monitoring VALUES(
          '$newID2',
          'Account Officer',
          '$dpt_nama',
          'Pegawai Telah Login',
          Now(),
          '$id_pegawai')"
        );
        header("location: ao_home.php?ok=berhasil");
      }
      else if($data['jabatan'] == "Manager") {
        $_SESSION['manager'] = $data['id_pegawai'];
        $query = mysqli_query($konek, "INSERT INTO data_monitoring VALUES(
          '$newID2',
          'Manager',
          '$dpt_nama',
          'Pegawai Telah Login',
          Now(),
          '$id_pegawai')"
        );
        header("location: manager_home.php?ok=berhasil");
      }
    }else{
      // Berpindah ke form Login.php, info gagal login
      header('location:login.php?ok=gagal');
    }
  }
 ?>
