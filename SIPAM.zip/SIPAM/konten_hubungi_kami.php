<h1 class="text-center"><b>Hubungi Kami</b></h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>KSPPS BMT Berkah Madani</b></h2>
  </div>
  <div class="panel-body">
    <img class="img-responsive img-thumbnail" src="gambar/BMT-Berkah-Madani-2.jpg" alt="gambar BMT Berkah Madani" width="400" height="592" style="float:left;margin-right:30px;margin-bottom:10px;"/>
    <div class="container-fluid">
      <address>
        <br>

        <span class="glyphicon glyphicon-map-marker" style="color:#eb4d4b;"></span>
        <strong> Alamat</strong> : Jl. Komjen M Jasin No.9, RT.002/RW.009, Tugu, Cimanggis, Kota Depok, Jawa Barat 16451 <br><br>
        <span class="glyphicon glyphicon-bullhorn" style="color:#535c68;"></span>
        <strong>Jam Buka</strong> : 08:00 s/d 16:00 WIB <br><br>
        <span class="glyphicon glyphicon-bullhorn" style="color:#535c68;"></span>
        <strong>Tutup Pukul : 17:00 WIB</strong><br><br>

        <span class="glyphicon glyphicon-phone-alt" style="color:#686de0;"></span>
        <strong>Telepon</strong> : (021) 87720325 <br><br>

        <span class="glyphicon glyphicon-earphone" style="color:#6ab04c;"></span>
        <strong>WA </strong> : 081384183633
      </address>
      <blockquote>
        <footer>From <a href="https://berkahmadani.co.id" target="_blank">BMT Berkah Madani</a> website</footer>
      </blockquote>
    </div>
  </div>
</div>
