<h1 class="text-center"><b>Sejarah</b> </h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>KSPPS BMT Berkah Madani</b></h2>
  </div>
  <div class="panel-body">
    <img class="img-responsive img-thumbnail" src="gambar/BMT-Berkah-Madani-1.png" alt="gambar BMT Berkah Madani" width="640" height="250" style="float:left;margin-right:30px;"/>
    <p class="paragraf-kedalam">
      Pada tahun 2005 kebutuhan akan lembaga keuangan akan akses permodalan pembiayaan
      sesuai dengan kebutuhan bagi kalangan usaha mikro Begitu sulit bagi usaha mikro
      untuk melakukan transaksi di perbankan baik pembiayaan maupun pinjaman. Banyak
      sekali persyaratan yang harus dipenuhi sehingga usaha mikro pada saat itu tidak
      dapat berjalan dengan baik.menengah masih sangtlah sulit, dikarenakan untuk melakukan
      pinjaman di bank sendiri memiliki prosedur yang lebih sulit dan minimal pinjaman yang
      ditentukan diluar kemampuan para nasabah. bagi para anggota atau nasabah perbankan
      hanya memberikan pinjaman kepada para pemodal besar.
    </p><br>
    <p class="paragraf-kedalam">
      Kemudian hadirlah beberapa Koperasi Syariah yang dahulu dikenal dengan
      BMT (Baitul Mal wa Tanwil) sebagai lembaga Keuangan Syariah yang menaungi sebagai
      alternatif lain lembaga pembiayaan untuk usaha mikro dan multiguna. Itulah yang menjadi
      salah satu diantarnya landasan terbentuknya koperasi syariah ini. Sebenarnya koperasi
      ini lebih lebih familiar dikenal masyarakat dan anggota dengan nama BMT Berkah Madani
      lembaga keuangan yang  berbasiskan syariah.  Seiring berjalannya waktu BMT Berkah Madani
      berganti nama  karena tuntutan izin birokrasi yang harus dipatuhi sebagai peraturan
      Undang Undang Perkoperasian dari kementerian koperasi dan kecil menengah .
    </p><br>
    <p class="paragraf-kedalam">
      Lembaga Keuangan Syariah Berkah Madani adalah lembaga keuangan mikro yang beroperasi
      dengan prinsip syariah. Fungsi dari lembaga keuangan adalah sebagai lembaga intermediasi
      antara pihak yang memiliki surplus dana dengan pihak lain yang membutuhkan modal. Koperasi
      Jasa Keuangan Syariah Berkah Madani didirikan di Depok pada tanggal 19 Oktober 2004 bertepatan
      dengan tanggal 5 Ramadhan 1424 H.. Mulai beroperasi pada tanggal 10 Februari 2005 bertepatan
      dengan 1 Muharram 1425 H berdasarkan Akta no. 62 dari Notaris B. Wirastuti Puntaraksma,
      SH . Koperasi Jasa Keuangan Syariah Berkah Madani telah mendapat status Hukum Koperasi
      berdasarkan surat Keputusan Menteri Negara Koperasi dan Usaha Kecil dan Menengah
      No. 486/BH/MENEG.I/V/2006. Peresmian dilakukan oleh Bapak Ir. Aburizal Bakrie & Bpk. Soegiharto
      selaku Anggota Luar Biasa Koperasi Jasa Keuangan Syariah Berkah Madani.
    </p>
    <blockquote>
      <footer>From <a href="https://berkahmadani.co.id" target="_blank">BMT Berkah Madani</a> website</footer>
    </blockquote>
  </div>
</div>
