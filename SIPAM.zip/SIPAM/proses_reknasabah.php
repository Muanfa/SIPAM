<?php
require "koneksi/koneksi.php";

session_start();

if ($_SESSION['admin']) {
  $id_pegawai = $_SESSION['admin'];
} else if ($_SESSION['manager']) {
  $id_pegawai = $_SESSION['manager'];
}


// Membuat id_monitoring baru
$hasil  = mysqli_query($konek,"SELECT max(id_monitoring) AS idMaks FROM data_monitoring");
$data   = mysqli_fetch_array($hasil);
$idMax  = $data['idMaks'];
$noUrut =  substr($idMax, 1, 5);
$noUrut++;
$format = "M";
$newID  = $format . sprintf("%05s", $noUrut);

// Membuat id_tranrek baru
$qry           = mysqli_query($konek, "SELECT max(id_tranrek) AS idMaks FROM data_laporanreknasabah");
$data          = mysqli_fetch_array($qry);
$idMax         = $data['idMaks'];
$noUrut        = substr($idMax, 1, 5);
$noUrut++;
$format        = "T";
$newID_Reknsb  = $format . sprintf("%05s", $noUrut);

// Jika di Tekan tombol simpan (Tambah Nasabah) eksekusi code ini
if(isset($_GET['tambah_saldo']))
{
  // Mengambil nilai dari form manager_tambah_nasabah.php
  $id_reknasabah  	= $_GET['id_reknsb'];
  $nama		          = $_GET['pmlk_rek'];
  $tanggal_buka     = $_GET['tgl_buka'];
  $saldo_sekarang   = $_GET['saldo'];
  $tambah_saldo     = $_GET['tambah_saldo'];
  $total_saldo   		= $_GET['total_saldo'];
  $jenis_tabungan   = $_GET['jns_tbng'];
  $status		  	    = $_GET['status'];
  $status		  	    = $_GET['status'];
  $tgl_tmbsaldo     = $_GET['tgl_tmbsld'];
  $id_nsb		  	    = $_GET['id_nsb'];

  // =============== Menyimpan ke Database =====================================
  // ========= DATA REKENING =========
  $query = mysqli_query($konek, "UPDATE data_reknasabah SET
           saldo = '$total_saldo' WHERE id_nasabah = '$id_nsb'"
  );

  if ($query) {
    // Menyimpan ke Laporan Rekening Nasabah
    $query4 = mysqli_query($konek, "INSERT INTO data_laporanreknasabah VALUES (
      '$newID_Reknsb',
      '$tgl_tmbsaldo',
      '$tambah_saldo',
      '0',
      'Menambah Saldo',
      '$total_saldo',
      '$id_nsb')"
    );

    // Mengambil nilai nama pegawai dari data_pegawai, nanti di pindahakan nilai nama pegawai ke data_monitoring
    $query2     = mysqli_query($konek,"SELECT * FROM data_pegawai WHERE id_pegawai = '$id_pegawai'");
    $data       = mysqli_fetch_array($query2);
    $dpt_nama   = $data['nama_depan'] . " " . $data['nama_belakang'];
    $jabatan    = $data['jabatan'];

    // Menyimpan ke database sipam, dari tabel data_monitoring
    $query4 = mysqli_query($konek, "INSERT INTO data_monitoring VALUES(
    '$newID',
    '$jabatan',
    '$dpt_nama',
    'Tambah Saldo Nasabah',
    Now(),
    '$id_pegawai')"
    );


        // BERHASIL
        if ($_SESSION['admin']) {
          header('location:admin_tambah_salnasabah.php?ok=berhasil&id='.$id_nsb);
        } else if ($_SESSION['manager']) {
          header('location:manager_tambah_salnasabah.php?ok=berhasil&id='.$id_nsb);
        }
  } else {
        // GAGAL
        if ($_SESSION['admin']) {
          header('location:admin_tambah_reknasabah.php?ok=gagal');
        } else if ($_SESSION['manager']) {
          header('location:manager_tambah_reknasabah.php?ok=gagal');
        }
  }
}
?>
