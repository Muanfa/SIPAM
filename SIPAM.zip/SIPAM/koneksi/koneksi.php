<?php
// $server		= "localhost:3307";
$server		= "localhost";
$username	= "root";
$password	= "";
$db			  = "project_native_sipam";

$konek		= new mysqli($server,$username,$password,$db) or die (mysql_error());
?>
