<h1 class="text-center"><b>Data Jaminan Nasabah</b></h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>Ubah Jaminan Nasabah</b></h2>
  </div>
  <div class="panel-body">
    <!-- HR -->
    <table style="width:100%;">
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), black)"></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td><p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ&nbsp;اللهِ&nbsp;الرَّحْمَنِ&nbsp;الرَّحِيْمِ</p></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, black, rgba(0,0,0,0.75), rgba(0,0,0,0));"></td>
    </table>

    <form name='autoSumForm' action="proses_jaminan.php" method="get">

      <!-- Data Jaminan -->
      <div class="col-sm-12" style="border-radius:15px;background-color:#f2f2f2;">
        <div style="padding:1px 0px 1px 0px;">
          <h2 class="text-center">Jaminan</h2>
          <table class="table" border=0>
            <!-- Mengambil Data Jaminan -->
            <?php
              // Fungsi ini menyembunyikan eror
              error_reporting(0);

              $id_nsb   = $_GET['id'];
              $query    = mysqli_query($konek, "SELECT * FROM data_jaminan WHERE id_nasabah ='$id_nsb'");
              $data     = mysqli_fetch_array($query);
             ?>
            <!-- ID Jaminan -->
            <tr>
                <th style="border:none;"><label class="control-label" style="margin-top:8px;">ID Jaminan :</label></th>
                <td style="border:none;"><input value="<?php echo $data['id_jaminan'];?>" name="id_jam" type="text" class="form-control" placeholder="ID Jaminan" readonly></td>
            </tr>
            <!-- Jenis Jaminan -->
            <tr>
              <th style="border:none;"><label class="control-label" style="margin-top:8px;" >Jenis Jaminan :</label></th>
              <td style="border:none;">
                <select name="jns_jam" class="form-control" id="sel1">
                  <option value="Tanah/Pembangunan" <?php if ($data['jenis_jaminan']=="Tanah/Pembangunan") { echo "selected=\"selected\""; }?>>Tanah/Pembangunan</option>
                  <option value="Kios/Toko"         <?php if ($data['jenis_jaminan']=="Kios/Toko") { echo "selected=\"selected\""; }?>>Kios/Toko</option>
                  <option value="Kendaraan"         <?php if ($data['jenis_jaminan']=="Kendaraan") { echo "selected=\"selected\""; }?>>Kendaraan</option>
                  <option value="Lainnya"           <?php if ($data['jenis_jaminan']=="Lainnya") { echo "selected=\"selected\""; }?>>Lainnya</option>
                </select>
              </td>
            </tr>
            <!-- Dokumen Jaminan -->
            <tr>
              <td style="border:none;"><label style="margin-top:8px;">Dokumen Jaminan :</label></td>
              <td style="border:none;"><input value="<?php echo $data['dokumen_jaminan'];?>" name="dok_jam" type="text" class="form-control" placeholder="Dokumen Jaminan" required></td>
            </tr>
            <!-- Lokasi Jaminan  -->
            <tr>
              <td colspan="2"style="border:none;"><textarea name="almt_jam" class="form-control" rows="5" style="resize:none;" placeholder="Lokasi Jaminan" required><?php echo $data['lokasi_jaminan'];?></textarea></td>
            </tr>
            <!-- Nilai Jaminan -->
            <tr>
              <td style="border:none;"><label style="margin-top:8px;">Nilai Jaminan :</label></td>
              <td style="border:none;">
                <div class="form-group input-group" style="margin:0px;">
                  <span class="input-group-addon" style="border:none;background-color:#f2f2f2;"><b>Rp.</b></span>
                  <input value="<?php echo $data['nilai_jaminan'];?>" style="border-radius:4px;" name="nilai_jam" type="text" onKeyPress="return angkadanhuruf(event,'0123456789',this)" class="form-control" placeholder="Nilai Jaminan" required>
                </div>
                <p style="font-size:12px;margin-bottom:0px;">
                  <b><mark>Catatan</mark>:</b> Nilai Jaminan harus lebih tinggi dari Total Jumlah Pembiayaan.
                </p>
              </td>
            </tr>
            <!-- Pemilik Jaminan -->
            <tr>
              <td style="border:none;"><label style="margin-top:8px;">Pemilik Jaminan :</label></td>
              <td style="border:none;"><input value="<?php echo $data['pemilik_jaminan'];?>" name="pmlk_jam" type="text" class="form-control" placeholder="Pemilik Jaminan" value="<?php echo "$nama_nsb"; ?>" readonly></td>
            </tr>
            <!-- id nsb -->
            <tr>
              <td colspan="2" style="border:none;"><input value="<?php echo $data['id_nasabah'];?>" name="id_nsb" type="hidden" class="form-control" placeholder="Pemilik Jaminan" readonly></td>
            </tr>
          </table>
        </div>
      </div>

      <!-- Tombol Simpan -->
      <div class="col-sm-12">
        <div style="text-align:center;">
          <input class="btn btn-success" type="submit" value="SIMPAN" name="ubah_jaminan" style="margin-top:15px;" readonly></input>
        </div>
        <!-- Untuk Info Jika Simpan Berhasil / Gagal -->
        <?php
          if (isset($_GET['ok'])){
            $error=$_GET['ok'];
          }else{
            $error="";
          }

          $pesan="";
          if ($error=="berhasil"){
                // BERHASIL
                if ($_SESSION['accountofficer']) {
                  $pesan=  "<script>
                              swal('Berhasil!', 'Data Telah Diubah!', 'success')
                              .then((value) => {
                                window.location.href='ao_data_jaminan.php';
                              });
                            </script>";
                } else if ($_SESSION['manager']) {
                  $pesan=  "<script>
                              swal('Berhasil!', 'Data Telah Diubah!', 'success')
                              .then((value) => {
                                window.location.href='manager_data_jaminan.php';
                              });
                            </script>";
                }
          } else if ($error=="gagal") {
                // GAGAL
                if ($_SESSION['accountofficer']) {
                  $pesan=  "<script>
                              swal('Gagal!', 'Data Gagal Diubah Di Database!', 'error')
                              .then((value) => {
                                swal('Info!', 'Coba Periksa Di File proses_jaminan.php / kode halaman ini', 'info')
                                .then((value) => {
                                  window.location.href='ao_ubah_jaminan.php';
                                })
                              });
                            </script>";
                } else if ($_SESSION['manager']) {
                  $pesan=  "<script>
                              swal('Gagal!', 'Data Gagal Diubah Di Database!', 'error')
                              .then((value) => {
                                swal('Info!', 'Coba Periksa Di File proses_jaminan.php / kode halaman ini', 'info')
                                .then((value) => {
                                  window.location.href='manager_ubah_jaminan.php';
                                })
                              });
                            </script>";
                }
          }
          // Tampil Hasil Pesan
          echo "$pesan";
         ?>
      </div>
    </form>
  </div>
</div>
