<!-- Isi Konten -->
<h1 class="text-center"><b>Laporan Keuangan</b></h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>Data Laporan Arus Kas</b></h2>
  </div>
  <div class="panel-body">
    <!-- HR -->
    <table style="width:100%;">
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), black)"></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td><p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ&nbsp;اللهِ&nbsp;الرَّحْمَنِ&nbsp;الرَّحِيْمِ</p></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, black, rgba(0,0,0,0.75), rgba(0,0,0,0));"></td>
    </table>

    <?php
      $id	  	= $_GET['id'];
      $query  = mysqli_query($konek, "SELECT * FROM data_laporanaruskas WHERE id_pembiayaan = '$id'");
      $data   = mysqli_fetch_array($query)
     ?>

    <!-- BUTTON CETAK LAPORAN -->
    <div>
      <button type='button' onclick="window.open('cetak_aruskas.php?id=<?php echo $data['id_pembiayaan'];?>','nama_window_pop_up','width=200,height=200,scrollbars=yes,resizeable=no')" class='btn btn-info btn-lg'>
        <span class="glyphicon glyphicon-print" style="color:black;"></span> Cetak</button>
      <hr>
    </div>

    <div class="container-fluid panel panel-default" style="padding-top:10px;padding-bottom:10px;">
      <table id="asexample" class="table responsive table-striped table-bordered table-hover" style="width:100%">
        <thead>
          <tr>
              <th>No</th>
              <th>ID Arus Kas</th>
              <th>ID Pembiayaan</th>
              <th>Tanggal</th>
              <th>Debit Rp.</th>
              <th>Kredit Rp.</th>
              <th>Keterangan</th>
              <th>Kode Akun</th>
          </tr>
        </thead>
        <tbody>

          <?php
            // Fungsi ini menyembunyikan eror
            error_reporting(0);
            // Mengambil nilai id, dari form manager_data_pegawai.php dari tombol UBAH
            $query2 = mysqli_query($konek, "SELECT * FROM data_laporanaruskas WHERE id_pembiayaan = '$id'");
            $no     = 1;
            while($rows = mysqli_fetch_array($query2)){
          ?>

          <tr style="text-align:center;">
            <td><?php echo $no++;?></td>
            <td><?php echo $rows['id_aruskas'];                ?></td>
            <td><?php echo $rows['id_pembiayaan'];             ?></td>
            <td><?php echo $rows['tanggal'];                   ?></td>
            <td><?php echo number_format($rows['debit']);                     ?></td>
            <td><?php echo number_format($rows['kredit']);                    ?></td>
            <?php if ($rows['kredit'] == '0'){?>
                <td style="text-align:left;"><?php echo $rows['keterangan'];   ?></td>
            <?php } else if($rows['debit'] == '0'){ ?>
                <td style="text-align:right;"><?php echo $rows['keterangan'];  ?></td>
            <?php } ?>
            <td><?php echo $rows['kode_akun'];                 ?></td>
          </tr>

          <?php } ?>
        </tbody>
      </table>

    </div>

  </div>
</div>
