<h1 class="text-center"><b>Transaksi Setoran</b></h1>
<hr>
<div class="panel panel-default">
  <div class="panel-heading">
    <h2><b>Data Pembiayaan</b></h2>
  </div>
  <div class="panel-body">
    <!-- HR -->
    <table style="width:100%;">
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, rgba(0,0,0,0), rgba(0,0,0,0.75), black)"></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td><p style="font-size:25px;text-align:center;">بِسْــــــــــــــــــمِ&nbsp;اللهِ&nbsp;الرَّحْمَنِ&nbsp;الرَّحِيْمِ</p></td>
      <td>&nbsp;&nbsp;&nbsp;</td>
      <td style="width:33%;"><hr style="border:0;height:1px;background-image: -webkit-linear-gradient(left, black, rgba(0,0,0,0.75), rgba(0,0,0,0));"></td>
    </table>

    <div class="container-fluid panel panel-default" style="padding-top:10px;padding-bottom:10px;">
      <table id="asexample" class="table responsive table-striped table-bordered table-hover" style="width:100%">
        <thead>
          <tr>
            <th>No</th>
            <th>Aksi</th>
            <th>Status</th>
            <th>ID Pembiayaan</th>
            <th>Nama Nasabah</th>
            <th>Kegunaan</th>
            <th>Obyek Pembiayaan</th>
            <th>Jenis Pembiayaan</th>
            <th>Sistem Pembayaran</th>
            <th>Jumlah Pembiayaan Rp.</th>
            <th>Margin</th>
            <th>Jangaka Waktu</th>
            <th>Kas BMT (di kembalikan) Rp.</th>
            <th>Pendapatan Margin Rp.</th>
            <th>Total Margin Rp.</th>
            <th>Total Pembiayaan Rp.</th>
            <th>Jumlah Angsuran Rp.</th>
            <th>Sisa Setoran Rp.</th>
          </tr>
        </thead>
        <tbody>


          <?php
            $query = mysqli_query($konek, "SELECT * FROM data_pembiayaan ORDER BY id_pembiayaan");
            $no = 1;
            while($rows = mysqli_fetch_array($query)){
          ?>

          <tr style="text-align:center;">
            <td><?php echo $no++;?></td>
            <td style="width:10px;">
              <?php
              // NYETOR
              if (isset($_SESSION['manager'])){ ?>
                <button type='button' onclick="window.location = 'manager_data_setoran.php?id=<?php echo $rows['id_pembiayaan'];?>'" class='btn btn-primary btn-sm'>Lihat Transaksi</button>
              <?php } else if(isset($_SESSION['accountofficer'])){?>
                <button type='button' onclick="window.location = 'ao_data_setoran.php?id=<?php echo $rows['id_pembiayaan'];?>'" class='btn btn-primary btn-sm'>Lihat Transaksi</button>
              <?php } ?>
            </td>
            <td>
              <?php
              if ($rows['status'] == 'Proses') {?>
                <button type='button' class='btn btn-danger btn-sm' style="pointer-events:none;">Proses</button>
                <?php
              }else if($rows['status'] == 'Lunas'){?>
                <button type='button' class='btn btn-success btn-sm' style="pointer-events:none;">Lunas</button>
                <?php
              }
              ?>
            </td>
            <td><?php echo $rows['id_pembiayaan'];                    ?></td>
            <td><?php echo $rows['nama_nasabah'];                     ?></td>
            <td><?php echo $rows['kegunaan'];                         ?></td>
            <td><?php echo $rows['obyek_pembiayaan'];                 ?></td>
            <td><?php echo $rows['jenis_pembiayaan'];                 ?></td>
            <td><?php echo $rows['sistem_pembayaran'];                ?></td>
            <td><?php echo number_format($rows['jumlah_pembiayaan'])  ?></td>
            <td><?php echo $rows['margin'];                           ?></td>
            <td><?php echo $rows['jangka_waktu'];                     ?></td>
            <td><?php echo number_format($rows['kas_bmt']);           ?></td>
            <td><?php echo number_format($rows['pendapatan_margin']); ?></td>
            <td><?php echo number_format($rows['total_margin']);      ?></td>
            <td><?php echo number_format($rows['total_pembiayaan']);  ?></td>
            <td><?php echo number_format($rows['jumlah_angsuran']);   ?></td>
            <td><?php echo number_format($rows['sisa_setoran']);      ?></td>
          </tr>

          <?php
            }
          ?>
        </tbody>
      </table>
    </div>

  </div>
</div>
