<?php
  require "koneksi/koneksi.php";

  session_start();
  ob_start();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Nama Title -->
    <title>Berkah Madani</title>
    <!-- Ikon Gambar Title -->
    <link rel="icon" href="gambar/logo_BM.png" type="png">
  </head>
  <body>
    <table style="margin-top:20px;">
      <tr>
        <td style="width:500px;">
          <img src="gambar/Logo_BM1.png" alt="" style="float:left;"/>
          <p style="margin-top:-1px;padding-left:10px;">Koperasi Jasa Keuangan Syariah</p>
          <p style="margin-top:-25px;padding-left:10px;"><b>Berkah</b> Madani</p>
          <p style="margin-top:-15px;">Berkah Madani</p>
        </td>
        <td>
          <p style="font-family:Agency FB;text-align:right;"><b>Aplikasi Pembiayaan</b></p>
        </td>
      </tr>
      <tr style="padding:0px;margin-top:-40px;">
        <hr>
      </tr>
    </table>

    <?php
      $id_nas = $_GET['id']; //kode berita yang akan dikonvert
      // DATA NASABAH
      $query  = mysqli_query($konek,"SELECT * FROM data_nasabah WHERE id_nasabah = '$id_nas'");
      $data   = mysqli_fetch_array($query);
      // DATA PEMBIAYAAN
      $query  = mysqli_query($konek, "SELECT * FROM data_pembiayaan WHERE id_nasabah = '$id_nas'");
      $data2  = mysqli_fetch_array($query);
      // DATA JAMINAN
      $query  = mysqli_query($konek, "SELECT * FROM data_jaminan WHERE id_nasabah = '$id_nas'");
      $data3  = mysqli_fetch_array($query);
    ?>
    <div class="" style="margin-top:-50px;">
      <h3 style="text-align:center;">Pembiayaan Akad Murabah</h3>
    </div>

    <!-- DATA NASABAH -->
    <h5 style="margin-top:-40px;">Data Pemohon :</h5>
    <table border="0" style="margin-left:50px;margin-top:-25px;">
        <tr>
          <td width="150">NAMA</td>
          <td width="10">:</td>
          <td width="250"><?php echo $data['nama']; ?></td>
        </tr>
        <tr>
          <td>Alamat</td>
          <td>:</td>
          <td><?php echo $data['alamat']; ?></td>
        </tr>
        <tr>
          <td>No Telphone</td>
          <td>:</td>
          <td><?php echo $data['no_telp']; ?></td>
        </tr>
         <tr>
          <td>Jenis Kelamin</td>
          <td>:</td>
          <td><?php echo $data['jenis_kelamin']; ?></td>
        </tr>
        <tr>
          <td>Tanggal Lahir</td>
          <td>:</td>
          <td><?php echo $data['tanggal_lahir']; ?></td>
        </tr>
        <tr>
          <td>Identitas Diri</td>
          <td>:</td>
          <td><?php echo $data['identitas_diri']; ?></td>
        </tr>
        <tr>
          <td>Email</td>
          <td>:</td>
          <td><?php echo $data['email']; ?></td>
        </tr>
        <tr>
          <td>Tanggal Daftar</td>
          <td>:</td>
          <td><?php echo $data['tanggal_daftar']; ?></td>
        </tr>
        <tr>
          <td>Pekerjaan</td>
          <td>:</td>
          <td><?php echo $data['pekerjaan']; ?></td>
        </tr>
        <tr>
          <td>Perusahaan</td>
          <td>:</td>
          <td><?php echo $data['perusahaan']; ?></td>
        </tr>
        <tr>
          <td>Bidang Usaha</td>
          <td>:</td>
          <td><?php echo $data['bidang_usaha']; ?></td>
        </tr>
        <tr>
          <td>Alamat Usaha</td>
          <td>:</td>
          <td><?php echo $data['alamat_usaha']; ?></td>
        </tr>
        <tr>
          <td>Nama Istri / Suami</td>
          <td>:</td>
          <td><?php echo $data['nama_istri_suami']; ?></td>
        </tr>
      </table>

    <!-- DATA PEMBIAYAAN -->
    <h5 style="margin-top:-25px;">Data Pembiayaan yang diajukan :</h5>
    <table border="0" style="margin-left:50px;margin-top:-25px;">
        <tr>
          <td>Tangal Daftar</td>
          <td>:</td>
          <td><?php echo $data2['tgl_daftar']; ?></td>
        </tr>
        <tr>
          <td>Kegunaan</td>
          <td>:</td>
          <td><?php echo $data2['kegunaan']; ?></td>
        </tr>
         <tr>
          <td>Obyek Pembiayaan</td>
          <td>:</td>
          <td><?php echo $data2['obyek_pembiayaan']; ?></td>
        </tr>
        <tr>
          <td>Jenis Pembiayaan</td>
          <td>:</td>
          <td><?php echo $data2['jenis_pembiayaan']; ?></td>
        </tr>
        <tr>
          <td>Sistem Pembayaran</td>
          <td>:</td>
          <td><?php echo $data2['sistem_pembayaran']; ?></td>
        </tr>
        <tr>
          <td>Jumlah Pembiayaan</td>
          <td>:</td>
          <td>Rp. <?php echo number_format($data2['jumlah_pembiayaan']); ?></td>
        </tr>
        <tr>
          <td>Margin</td>
          <td>:</td>
          <td><?php echo $data2['margin']; ?> %</td>
        </tr>
        <tr>
          <td>Jangka Waktu</td>
          <td>:</td>
          <td><?php echo $data2['jangka_waktu']; ?></td>
        </tr>
        <tr>
          <td>Kas BMT (di keluarkan)</td>
          <td>:</td>
          <td>Rp. <?php echo number_format($data2['kas_bmt']); ?></td>
        </tr>
        <tr>
          <td>Pendapatan Margin</td>
          <td>:</td>
          <td>Rp. <?php echo number_format($data2['pendapatan_margin']); ?></td>
        </tr>
        <tr>
          <td><b><u>Jumlah Angsuran</u></b></td>
          <td>:</td>
          <td>Rp. <?php echo number_format($data2['jumlah_angsuran']); ?> /Bulan</td>
        </tr>
        <tr>
          <td>Total Jumlah Margin</td>
          <td>:</td>
          <td>Rp. <?php echo number_format($data2['total_margin']); ?></td>
        </tr>
        <tr>
          <td>Total Jumlah Pembiayaan (di kembalikan)</td>
          <td>:</td>
          <td>Rp. <?php echo number_format($data2['total_pembiayaan']); ?></td>
        </tr>
        <tr>
          <td>Sisa Setoran</td>
          <td>:</td>
          <td>Rp. <?php echo number_format($data2['sisa_setoran']); ?></td>
        </tr>
        <tr>
          <td>Status</td>
          <td>:</td>
          <td><?php echo $data2['status']; ?></td>
        </tr>
    </table>

    <!-- DATA JAMINAN -->
    <h5 style="margin-top:-25px;">Data Jamianan :</h5>
    <table border="0" style="margin-left:50px;margin-top:-30px;">
        <tr>
          <td>Pemilik Jaminan</td>
          <td>:</td>
          <td><?php echo $data3['pemilik_jaminan']; ?></td>
        </tr>
        <tr>
          <td>Jenis Jaminan</td>
          <td>:</td>
          <td><?php echo $data3['jenis_jaminan']; ?></td>
        </tr>
        <tr>
          <td>Dokumen Jaminan</td>
          <td>:</td>
          <td><?php echo $data3['dokumen_jaminan']; ?></td>
        </tr>
         <tr>
          <td>Lokasi Jaminan</td>
          <td>:</td>
          <td><?php echo $data3['lokasi_jaminan']; ?></td>
        </tr>
        <tr>
          <td>Nilai Jaminan</td>
          <td>:</td>
          <td>Rp. <?php echo number_format($data3['nilai_jaminan']); ?></td>
        </tr>
    </table>


    <p style="margin-top:-20px;">Data yang tertera di atas adalah Nasabah : <u><?php echo $data['nama']; ?></u> yang melakukan akad pembiayaan murabahah. Beserta Data Pembiayaan & Data Jaminan, di KSPPS BMT Berkah Madani ini.</p>
    <!-- TANDA TANGAN -->
    <?php
      // Mengambil Tanggal Sekarang
      // $hari = date('d');
      // $hari = $hari - 1;
      // $tgl = date('-m-Y');
      // $hari_ini = $hari . $tgl;
      $tgl = date('d-m-Y');

      echo '<p align="right" style="margin-top:-25px;">Depok, '.$tgl.'
      <img src="gambar/bm_ttd.png" width="120" style="pointer-events:none;">
      ( Berkah Madani )</p>';
    ?>
  </body>
</html>

<?php
  $filename="akd_".$data['nama'].".pdf"; //ubah untuk menentukan nama file pdf yang dihasilkan nantinya
  //==========================================================================================================
  //Copy dan paste langsung script dibawah ini,untuk mengetahui lebih jelas tentang fungsinya silahkan baca-baca tutorial tentang HTML2PDF
  //==========================================================================================================
  $content = ob_get_clean();
  $content = '<page style="font-family: ">'.nl2br($content).'</page>';
   require_once(dirname(__FILE__).'/html2pdf/html2pdf.class.php');
   try
   {
    $html2pdf = new HTML2PDF('P','A4','en', false, 'ISO-8859-15', array(20, -10, 20, -1000));
    $html2pdf->setDefaultFont('Arial');
    $html2pdf->writeHTML($content, isset($_GET['vuehtml']));
    $html2pdf->Output($filename);
   }
   catch(HTML2PDF_exception $e) { echo $e; }
?>
